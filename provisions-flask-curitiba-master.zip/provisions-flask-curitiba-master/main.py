from flask import render_template, request, redirect, url_for, flash, session, abort
from flask_login import login_user, logout_user
from app import app, db
from app.models import User, Center, Account
from config import senha
import flask_excel as excel
from openpyxl import load_workbook
import json
from flask_login import current_user
from flask_wtf import FlaskForm
from wtforms import FileField, SubmitField, StringField
from werkzeug.utils import secure_filename
import os

import sqlite3
import pandas as pd
from sqlalchemy import create_engine, inspect
from wtforms.validators import InputRequired
import itertools
from pathlib import Path
import shutil
import webbrowser
from flask_autoindex import AutoIndex

# 1@1

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders

@app.route("/", methods=["GET", "POST"])
def home():
    if request.method == "POST":
        try:
            botao = request.form["botao"]

            if botao == "Logar":
                return redirect(url_for("login"))
            elif botao == "Registrar":
                return redirect(url_for("register"))
            elif botao == "Recuperar":
                return redirect(url_for("recover"))

            else:
                pass
        except:
            pass

        try:
            botaoL = request.form["botaoL"]
            if botaoL == "Visualizar Contas":
                return redirect(url_for("viewaccounts"))
            elif botaoL == "Criar Provisoes":
                return redirect(url_for("createprovissions"))
            elif botaoL == "Editar Provisoes":
                return redirect(url_for("editprovisions"))
            elif botaoL == "Ver Provisoes":
                return redirect(url_for("seeprovisions"))
            elif botaoL == "Minhas Provisoes":
                return redirect(url_for("viewprovisions"))
            elif botaoL == "Desenvolvedor":
                webbrowser.open_new_tab("https://vitor-kaviski.up.railway.app")
                return redirect("/")
            elif botaoL == "Desconectar":
                return redirect(url_for("logout"))
            elif botaoL == "Atualizar Tabelas":
                return redirect(url_for("basetablesupdate"))
            else:
                pass
            if botaoL == "Ajuda":

                fromaddr = "suporteprovisoes"
                toaddr = current_user.email
                msg = MIMEMultipart()

                msg["From"] = fromaddr
                msg["To"] = toaddr
                msg["Subject"] = f"Provisões Brose - Solicitação de Suporte"

                # Abre o arquivo "Brose_Configuracoes.xlsx"
                wb = load_workbook('app/static/Excels/Excel_Bases/Brose_Configuracoes.xlsx')

                # Seleciona a planilha "Configs"
                sheet = wb['Configs']

                # Atribui o valor da célula B2 à variável respfin
                respfin = sheet['B2'].value

                # Atribui o valor da célula B3 à variável respsup
                respsup = sheet['B3'].value

                # Fecha o arquivo
                wb.close()

                # Imprime os valores das variáveis respfin e respsup
                print(respfin)
                print(respsup)

                body = f'Prezado(a) {current_user.name},\n\nEsperamos que você esteja aproveitando ao máximo todas as funcionalidades da nossa plataforma.\n\nSe precisar de ajuda, temos dois canais de atendimento à sua disposição: um dedicado ao suporte técnico ({respsup}), relacionado a dúvidas sugesões ou erros e outro destinado ao suporte da atividade de provisões ({respfin}). Nós valorizamos sua opinião e estamos sempre dispostos a ajudar em questões relacionadas ao uso da nossa plataforma. Por favor, não hesite em nos contatar caso tenha dúvidas, sugestões ou encontre algum problema. Nossa equipe está pronta para atendê-lo(a) e garantir a melhor experiência possível para você.\n\nAgradecemos a sua confiança em nossos serviços.\n\nAtenciosamente,\n\nEquipe Automatizada Brose Provisões Brasil'
                msg.attach(MIMEText(body, "plain"))

                text = msg.as_string()
                # smtp1 = smtplib.SMTP("127.0.0.1")
                # smtp1.sendmail(fromaddr, toaddr, text)
                # smtp1.quit()
                with smtplib.SMTP("127.0.0.1") as smtp1:
                    smtp1.sendmail(fromaddr, toaddr, text)

                flash("Dados para contato Enviados para seu Email!")

                return redirect("/")
            else:
                pass
        except Exception as e:
            print(e)

    return render_template("home.html")


@app.route("/basetablesupdate", methods=["GET", "POST"])
def basetablesupdate():
    if request.method == "POST":
        try:
            uploaded_file = request.files["arquivo0"]
            filename = uploaded_file.filename

            if filename == "" and request.files["arquivo0"] != "":
                flash("Selecione Um Arquivo")
            elif filename != "" and request.files["arquivo0"] != "":
                file_ext = os.path.splitext(filename)[1]
                if (
                    file_ext not in app.config["UPLOAD_EXTENSIONS"]
                    or filename != "Brose_Cadastro_Contas.xlsx"
                ):
                    flash("Formate o Excel com o nome Brose_Cadastro_Contas.xlsx")
                else:
                    uploaded_file.save(
                        os.path.join(
                            os.path.join(
                                app.config["UPLOAD_FOLDER"],
                                secure_filename(uploaded_file.filename),
                            )
                        )
                    )  # Contas

                    contas = []
                    for instance in db.session.query(Account):  # contas
                        x = instance.account
                        contas.append(x)
                    # print(contas)

                    wb = load_workbook(
                        r"app/static/Excels/Excel_Bases/Brose_Cadastro_Contas.xlsx"
                    )
                    planilha = wb["Contas"]
                    primeira_coluna = planilha["A"]

                    y = 0
                    for coluna1 in primeira_coluna:
                        if (
                            (str(coluna1.value) not in contas)
                            and (str(coluna1.value) != "Contas")
                            and (str(coluna1.value) != "None")
                        ):
                            # print(str(coluna1.value))
                            x = str(coluna1.value)
                            accounts = Account(x)
                            db.session.add(accounts)
                            db.session.commit()
                            y = y + 1
                        else:
                            pass

                    contas = []
                    for instance in db.session.query(Account):  # contas
                        x = instance.account
                        contas.append(x)
                    # print(contas)

                    wb2 = load_workbook(
                        r"app/static/Excels/Excel_Registros/Brose_Registros_Contas.xlsx"
                    )
                    planilha = wb2["Contas"]

                    n = 2
                    for conta in contas:
                        if conta != "":
                            planilha[f"A{n}"] = str(conta)
                            n = n + 1
                        else:
                            pass

                    wb2.save(
                        "app/static/Excels/Excel_Registros/Brose_Registros_Contas.xlsx"
                    )

                    wb3 = load_workbook(
                        r"app/static/Excels/Excel_Registros/Brose_Registros_Contas.xlsx"
                    )
                    planilha = wb3["Contas"]

                    primeira_coluna = planilha["A"]

                    valores1 = []

                    for coluna1 in primeira_coluna:
                        if coluna1.value != "Contas" or coluna1.value != "None":
                            valores1.append(
                                f'<tr class="text-center" style="display: table-row;"><td>{coluna1.value}</td></tr>'
                            )
                        else:
                            pass

                    listamodificada = "".join(valores1)
                    listafinal = (
                        listamodificada.replace(",<td>", "<td>")
                        .replace("None", "")
                        .replace(
                            r'"><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr><tr style="display: table-row;"><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr><tr style="display: table-row;',
                            "",
                        )
                        .replace(
                            r"<td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr>",
                            "",
                        )
                        .replace(
                            r'<tr class="text-center" style="display: table-row;"><td>-</td>',
                            "",
                        )
                        .replace(
                            r'<tr class="text-center" style="display: table-row;"><td></td></tr>',
                            "",
                        )
                        .replace(
                            r'<tr class="text-center" style="display: table-row;"><td></td></tr>',
                            "",
                        )
                        .replace(
                            r'<tr class="text-center" style="display: table-row;"><td>Contas</td></tr>',
                            "",
                        )
                    )

                    # print(listafinal)

                    file = open("app/templates/contasexcel.html", "w")

                    file.writelines(listafinal)
                    file.close()

                    contas = []
                    for instance in db.session.query(Account):
                        x = instance.account
                        contas.append(x)
                    # print(contas)

                    wb = load_workbook(
                        "app/static/Excels/Excel_Bases/Brose_Contas_Centros_Permissoes.xlsx"
                    )
                    planilha = wb["Permissoes Contas"]  # Planta, Conta ou Centro Código

                    nac = 2
                    for conta in contas:
                        if conta != "":
                            planilha.cell(column=nac, row=1).value = str(conta)
                            nac = nac + 1
                        else:
                            pass

                    wb.save(
                        r"app/static/Excels/Excel_Bases/Brose_Contas_Centros_Permissoes.xlsx"
                    )

                    flash(f"Foram Cadastradas {y} Novas Contas")
        except:
            pass

    if request.method == "POST":
        try:
            uploaded_file = request.files["arquivo"]
            filename = uploaded_file.filename

            if filename == "" and request.files["arquivo"] != "":
                flash("Selecione Um Arquivo")
            elif filename != "" and request.files["arquivo"] != "":
                file_ext = os.path.splitext(filename)[1]
                if (
                    file_ext not in app.config["UPLOAD_EXTENSIONS"]
                    or filename != "Brose_Cadastro_Centros.xlsx"
                ):
                    flash("Formate o Excel com o nome Brose_Cadastro_Centros.xlsx")
                else:
                    uploaded_file.save(
                        os.path.join(
                            os.path.join(
                                app.config["UPLOAD_FOLDER"],
                                secure_filename(uploaded_file.filename),
                            )
                        )
                    )  # Centros

                    centros = []
                    for instance in db.session.query(Center):  # centros
                        x = instance.center
                        centros.append(x)
                    # print(centros)

                    wb = load_workbook(
                        r"app/static/Excels/Excel_Bases/Brose_Cadastro_Centros.xlsx"
                    )
                    planilha = wb["Centros"]
                    primeira_coluna = planilha["A"]

                    y = 0
                    for coluna1 in primeira_coluna:
                        if (
                            (str(coluna1.value) not in centros)
                            and (str(coluna1.value) != "Centros")
                            and (str(coluna1.value) != "None")
                        ):
                            # print(str(coluna1.value))
                            x = str(coluna1.value)
                            center = Center(x)
                            db.session.add(center)
                            db.session.commit()
                            y = y + 1
                        else:
                            pass

                    centros = []
                    for instance in db.session.query(Center):  # centros
                        x = instance.center
                        centros.append(x)
                    # print(centros)

                    wb2 = load_workbook(
                        r"app/static/Excels/Excel_Registros/Brose_Registros_Centros.xlsx"
                    )
                    planilha = wb2["Centros"]

                    n = 2
                    for centro in centros:
                        if centro != "":
                            planilha[f"A{n}"] = str(centro)
                            n = n + 1
                        else:
                            pass

                    wb2.save(
                        "app/static/Excels/Excel_Registros/Brose_Registros_Centros.xlsx"
                    )

                    wb4 = load_workbook(
                        r"app/static/Excels/Excel_Registros/Brose_Registros_Centros.xlsx"
                    )
                    planilha = wb4["Centros"]

                    primeira_coluna = planilha["A"]

                    valores1 = []

                    for coluna1 in primeira_coluna:
                        if coluna1.value != "Centros" or coluna1.value != "None":
                            valores1.append(
                                f'<tr class="text-center" style="display: table-row;"><td>{coluna1.value}</td></tr>'
                            )
                        else:
                            pass

                    listamodificada = "".join(valores1)
                    listafinal = (
                        listamodificada.replace(",<td>", "<td>")
                        .replace("None", "")
                        .replace(
                            r'"><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr><tr style="display: table-row;"><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr><tr style="display: table-row;',
                            "",
                        )
                        .replace(
                            r"<td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr>",
                            "",
                        )
                        .replace(
                            r'<tr class="text-center" style="display: table-row;"><td>-</td>',
                            "",
                        )
                        .replace(
                            r'<tr class="text-center" style="display: table-row;"><td></td></tr>',
                            "",
                        )
                        .replace(
                            r'<tr class="text-center" style="display: table-row;"><td></td></tr>',
                            "",
                        )
                        .replace(
                            r'<tr class="text-center" style="display: table-row;"><td>Centros</td></tr>',
                            "",
                        )
                    )

                    # print(listafinal)

                    file = open("app/templates/centrosexcel.html", "w")

                    file.writelines(listafinal)
                    file.close()

                    centros = []
                    for instance in db.session.query(Center):  # centros
                        x = instance.center
                        centros.append(x)
                    # print(centros)

                    wb = load_workbook(
                        "app/static/Excels/Excel_Bases/Brose_Contas_Centros_Permissoes.xlsx"
                    )
                    planilha = wb[
                        "Permissoes Centros"
                    ]  # Planta, Conta ou Centro Código

                    ncc = 2
                    for centro in centros:
                        if centro != "":
                            planilha.cell(column=ncc, row=1).value = str(centro)
                            ncc = ncc + 1
                        else:
                            pass

                    wb.save(
                        r"app/static/Excels/Excel_Bases/Brose_Contas_Centros_Permissoes.xlsx"
                    )

                    flash(f"Foram Cadastrados {y} Novos Centros")
        except:
            pass

    if request.method == "POST":
        try:
            botaoLR = request.form["botaoL"]

            if botaoLR == "HVoltar":
                return redirect(url_for("home"))
            elif botaoLR == "HVerProv":
                return redirect(url_for("viewaccounts"))
            elif botaoLR == "HVerProviso":
                return redirect(url_for("viewprovisions"))
            elif botaoLR == "HEditarProv":
                return redirect(url_for("editprovisions"))
            elif botaoLR == "HCriarProv":
                return redirect(url_for("createprovissions"))
            elif botaoLR == "HPermissoes":
                return redirect(url_for("seeprovisions"))
            elif botaoLR == "HDesconectar":
                return redirect(url_for("logout"))

            try:
                if botaoLR == "HPainel":
                    return redirect(url_for("basetablesupdate"))
            except:
                pass

            else:
                pass
        except:
            pass

    if request.method == "POST":
        try:

            botaoR = request.form["botaoR"]

            if botaoR == "ViContas":
                return redirect(url_for("accounts"))

            elif botaoR == "ViUsuarios":
                return redirect(url_for("users"))

            elif botaoR == "ViCentros":
                return redirect(url_for("centers"))

            elif botaoR == "EdPlantas":
                return redirect(url_for("plantspermission"))

            elif botaoR == "EdContas":
                return redirect(url_for("accountspermission"))

            elif botaoR == "EdCentros":
                return redirect(url_for("centerspermission"))

            else:
                pass
        except:
            pass

    if request.method == "POST":
        try:
            conta = request.form["conta"]
            botao = request.form["botaoC"]

            contas = []
            for instance in db.session.query(Account):  # contas
                x = instance.account
                contas.append(x)
            # print(contas)

            if conta in contas:
                flash("Conta Já Cadastrada")
            else:

                if conta == "":
                    flash("Conta em Branco")
                    return redirect(url_for("basetablesupdate"))
                elif botao == "Cadastrar" and conta != "":
                    # print(conta)

                    accounts = Account(conta)
                    db.session.add(accounts)
                    db.session.commit()

                    wb2 = load_workbook(
                        r"app/static/Excels/Excel_Registros/Brose_Registros_Contas.xlsx"
                    )
                    planilha = wb2["Contas"]

                    contas = []
                    for instance in db.session.query(Account):  # contas
                        x = instance.account
                        contas.append(x)
                    # print(contas)

                    n = 2
                    for conta in contas:
                        if conta != "":
                            planilha[f"A{n}"] = str(conta)
                            n = n + 1
                        else:
                            pass

                    wb2.save(
                        "app/static/Excels/Excel_Registros/Brose_Registros_Contas.xlsx"
                    )

                    wb3 = load_workbook(
                        r"app/static/Excels/Excel_Registros/Brose_Registros_Contas.xlsx"
                    )
                    planilha = wb3["Contas"]

                    primeira_coluna = planilha["A"]

                    valores1 = []

                    for coluna1 in primeira_coluna:
                        if coluna1.value != "Contas" or coluna1.value != "None":
                            valores1.append(
                                f'<tr class="text-center" style="display: table-row;"><td>{coluna1.value}</td></tr>'
                            )
                        else:
                            pass

                    listamodificada = "".join(valores1)
                    listafinal = (
                        listamodificada.replace(",<td>", "<td>")
                        .replace("None", "")
                        .replace(
                            r'"><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr><tr style="display: table-row;"><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr><tr style="display: table-row;',
                            "",
                        )
                        .replace(
                            r"<td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr>",
                            "",
                        )
                        .replace(
                            r'<tr class="text-center" style="display: table-row;"><td>-</td>',
                            "",
                        )
                        .replace(
                            r'<tr class="text-center" style="display: table-row;"><td></td></tr>',
                            "",
                        )
                        .replace(
                            r'<tr class="text-center" style="display: table-row;"><td>Contas</td></tr>',
                            "",
                        )
                        .replace(
                            r'<tr class="text-center" style="display: table-row;"><td></td></tr>',
                            "",
                        )
                    )

                    # print(listafinal)

                    file = open("app/templates/contasexcel.html", "w")

                    file.writelines(listafinal)
                    file.close()

                    contas = []
                    for instance in db.session.query(Account):
                        x = instance.account
                        contas.append(x)
                    # print(contas)

                    wb = load_workbook(
                        "app/static/Excels/Excel_Bases/Brose_Contas_Centros_Permissoes.xlsx"
                    )
                    planilha = wb["Permissoes Contas"]  # Planta, Conta ou Centro Código

                    nac = 2
                    for conta in contas:
                        if conta != "":
                            planilha.cell(column=nac, row=1).value = str(conta)
                            nac = nac + 1
                        else:
                            pass

                    wb.save(
                        r"app/static/Excels/Excel_Bases/Brose_Contas_Centros_Permissoes.xlsx"
                    )

                    flash("Conta Cadastrada")
                    return redirect(url_for("basetablesupdate"))
                else:
                    flash("Tente Novamente")
                    return redirect(url_for("basetablesupdate"))
        except:
            pass

    if request.method == "POST":
        try:
            centro = request.form["center"]
            botao = request.form["botao"]

            centros = []
            for instance in db.session.query(Center):  # centros
                x = instance.center
                centros.append(x)
            # print(centros)

            if centro in centros:
                flash("Centro Já Cadastrado")
            else:

                if centro == "":
                    flash("Centro em Branco")
                    return redirect(url_for("basetablesupdate"))
                elif botao == "Cadastrar" and centro != "":
                    # print(centro)

                    center = Center(centro)
                    db.session.add(center)
                    db.session.commit()

                    centros = []
                    for instance in db.session.query(Center):  # centros
                        x = instance.center
                        centros.append(x)
                    # print(centros)

                    wb2 = load_workbook(
                        r"app/static/Excels/Excel_Registros/Brose_Registros_Centros.xlsx"
                    )
                    planilha = wb2["Centros"]

                    n = 2
                    for centro in centros:
                        if centro != "":
                            planilha[f"A{n}"] = str(centro)
                            n = n + 1
                        else:
                            pass

                    wb2.save(
                        "app/static/Excels/Excel_Registros/Brose_Registros_Centros.xlsx"
                    )

                    wb4 = load_workbook(
                        r"app/static/Excels/Excel_Registros/Brose_Registros_Centros.xlsx"
                    )
                    planilha = wb4["Centros"]

                    primeira_coluna = planilha["A"]

                    valores1 = []

                    for coluna1 in primeira_coluna:
                        if coluna1.value != "Centros" or coluna1.value != "None":
                            valores1.append(
                                f'<tr class="text-center" style="display: table-row;"><td>{coluna1.value}</td></tr>'
                            )
                        else:
                            pass

                    listamodificada = "".join(valores1)
                    listafinal = (
                        listamodificada.replace(",<td>", "<td>")
                        .replace("None", "")
                        .replace(
                            r'"><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr><tr style="display: table-row;"><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr><tr style="display: table-row;',
                            "",
                        )
                        .replace(
                            r"<td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr>",
                            "",
                        )
                        .replace(
                            r'<tr class="text-center" style="display: table-row;"><td>-</td>',
                            "",
                        )
                        .replace(
                            r'<tr class="text-center" style="display: table-row;"><td></td></tr>',
                            "",
                        )
                        .replace(
                            r'<tr class="text-center" style="display: table-row;"><td>Centros</td></tr>',
                            "",
                        )
                        .replace(
                            r'<tr class="text-center" style="display: table-row;"><td></td></tr>',
                            "",
                        )
                    )

                    # print(listafinal)

                    file = open("app/templates/centrosexcel.html", "w")

                    file.writelines(listafinal)
                    file.close()

                    centros = []
                    for instance in db.session.query(Center):  # centros
                        x = instance.center
                        centros.append(x)
                    # print(centros)

                    wb = load_workbook(
                        "app/static/Excels/Excel_Bases/Brose_Contas_Centros_Permissoes.xlsx"
                    )
                    planilha = wb[
                        "Permissoes Centros"
                    ]  # Planta, Conta ou Centro Código

                    ncc = 2
                    for centro in centros:
                        if centro != "":
                            planilha.cell(column=ncc, row=1).value = str(centro)
                            ncc = ncc + 1
                        else:
                            pass

                    wb.save(
                        r"app/static/Excels/Excel_Bases/Brose_Contas_Centros_Permissoes.xlsx"
                    )

                    flash("Centro Cadastrado")
                    return redirect(url_for("basetablesupdate"))
                else:
                    flash("Tente Novamente")
                    return redirect(url_for("basetablesupdate"))
        except:
            pass

        y = 0
        w = 0


        if request.method == "POST":
            try:
                uploaded_file = request.files["arquivo11"]
                filename = uploaded_file.filename

                if filename == "" and request.files["arquivo11"] != "":
                    flash("Selecione Um Arquivo")
                elif filename != "" and request.files["arquivo11"] != "":
                    file_ext = os.path.splitext(filename)[1]
                    if (
                        file_ext not in app.config["UPLOAD_EXTENSIONS"]
                        or filename != "Brose_Configuracoes.xlsx"
                    ):
                        flash("Brose_Configuracoes.xlsx")
                    else:
                        uploaded_file.save(
                            os.path.join(
                                os.path.join(
                                    app.config["UPLOAD_FOLDER"],
                                    secure_filename(uploaded_file.filename),
                                )
                            )
                        ) 

                        flash("Configurações Atualizadas Com Sucesso")
            except:
                pass


        if request.method == "POST":
            try:
                uploaded_file = request.files["arquivo1"]
                filename = uploaded_file.filename

                if filename == "" and request.files["arquivo1"] != "":
                    flash("Selecione Um Arquivo")
                elif filename != "" and request.files["arquivo1"] != "":
                    file_ext = os.path.splitext(filename)[1]
                    if (
                        file_ext not in app.config["UPLOAD_EXTENSIONS"]
                        or filename != "Brose_Cadastro_Usuarios.xlsx"
                    ):
                        flash("Formate o Excel com o nome Brose_Cadastro_Usuarios.xlsx")
                    else:
                        uploaded_file.save(
                            os.path.join(
                                os.path.join(
                                    app.config["UPLOAD_FOLDER"],
                                    secure_filename(uploaded_file.filename),
                                )
                            )
                        )  # Contas

                        emails = []
                        for instance in db.session.query(User):
                            x = instance.email
                            emails.append(x)
                        # print(emails)
                        
                        wb = load_workbook(
                            r"app/static/Excels/Excel_Bases/Brose_Cadastro_Usuarios.xlsx"
                        )
                        planilha = wb["Usuarios"]
                        primeira_coluna = planilha["A"]
                        segunda_coluna = planilha["B"]
                        terceira_coluna = planilha["C"]

                        for coluna1, coluna2, coluna3 in zip(
                            primeira_coluna, segunda_coluna, terceira_coluna
                        ):
                            if (
                                str(coluna1.value) == "Nome"
                                and str(coluna2.value) == "Email"
                                and str(coluna3.value) == "Senha"
                            ):
                                pass
                            else:
                                if str(coluna1.value) != "None":
                                    if str(coluna2.value) in emails:

                                        id = str(coluna2.value)
                                        usuario = (
                                            db.session.query(User)
                                            .filter_by(email=id)
                                            .first()
                                        )
                                        # print(usuario.name)
                                        usuario.password = str(coluna3.value)

                                        db.session.commit()
                                        w = w + 1
                                    else:
                                        name = str(coluna1.value)
                                        email = str(coluna2.value)
                                        pwd = str(coluna3.value)

                                        user = User(name, email, pwd)
                                        db.session.add(user)
                                        db.session.commit()
                                        y = y + 1

                                    names = []
                                    for instance in db.session.query(User):
                                        x = instance.name
                                        names.append(x)

                                    emails = []
                                    for instance in db.session.query(User):
                                        x = instance.email
                                        emails.append(x)

                                    passwords = []
                                    for instance in db.session.query(User):
                                        x = instance.password
                                        passwords.append(x)

                                    wb2 = load_workbook(
                                        r"app/static/Excels/Excel_Registros/Brose_Registros_Usuarios.xlsx"
                                    )
                                    planilha = wb2["Usuarios"]

                                    n = 2
                                    for name, email, password in zip(
                                        names, emails, passwords
                                    ):
                                        if name != "":
                                            planilha[f"A{n}"] = str(name)
                                            planilha[f"B{n}"] = str(email)
                                            planilha[f"C{n}"] = str(password)
                                            n = n + 1
                                        else:
                                            pass

                                    wb2.save(
                                        "app/static/Excels/Excel_Registros/Brose_Registros_Usuarios.xlsx"
                                    )

                                    wb4 = load_workbook(
                                        r"app/static/Excels/Excel_Registros/Brose_Registros_Usuarios.xlsx"
                                    )
                                    planilha = wb4["Usuarios"]

                                    primeira_coluna = planilha["A"]
                                    segunda_coluna = planilha["B"]
                                    terceira_coluna = planilha["C"]

                                    valores1 = []
                                    valores2 = []
                                    valores3 = []

                                    for coluna1 in primeira_coluna:
                                        if (
                                            coluna1.value != "Nome"
                                            or coluna1.value != "None"
                                        ):
                                            valores1.append(
                                                f'<tr class="text-center" style="display: table-row;"><td>{coluna1.value}</td>'
                                            )
                                        else:
                                            pass
                                    for coluna2 in segunda_coluna:
                                        if (
                                            coluna2.value != "Email"
                                            or coluna1.value != "None"
                                        ):
                                            valores2.append(f"<td>{coluna2.value}</td>")
                                        else:
                                            pass
                                    for coluna3 in terceira_coluna:
                                        if (
                                            coluna3.value != "Senha"
                                            or coluna1.value != "None"
                                        ):
                                            valores3.append(
                                                f"<td>{coluna3.value}</td></tr>"
                                            )
                                        else:
                                            pass

                                    lista1 = []
                                    for (a, b, c) in zip(valores1, valores2, valores3):
                                        x = f"{a},{b},{c}"
                                        lista1.append(x)

                                    listamodificada = "".join(lista1)
                                    listafinal = (
                                        listamodificada.replace(",<td>", "<td>")
                                        .replace("None", "")
                                        .replace(
                                            r'"><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr><tr style="display: table-row;"><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr><tr style="display: table-row;',
                                            "",
                                        )
                                        .replace(
                                            r"<td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr>",
                                            "",
                                        )
                                        .replace(
                                            r'<tr class="text-center" style="display: table-row;"><td>-</td>',
                                            "",
                                        )
                                        .replace(
                                            r'<tr class="text-center" style="display: table-row;"><td></td></tr>',
                                            "",
                                        )
                                        .replace(
                                            r'<tr class="text-center" style="display: table-row;"><td></td><td></td><td></td></tr>',
                                            "",
                                        )
                                        .replace(
                                            r'<tr class="text-center" style="display: table-row;"><td>Nome</td><td>Email</td><td>Senha</td></tr>',
                                            "",
                                        )
                                    )

                                    # print(listafinal)

                                    file = open("app/templates/usuariosexcel.html", "w")

                                    file.writelines(listafinal)
                                    file.close()

                                    emails = []
                                    for instance in db.session.query(User):
                                        x = instance.email
                                        emails.append(x)

                                    wb = load_workbook(
                                        "app/static/Excels/Excel_Bases/Brose_Contas_Centros_Permissoes.xlsx"
                                    )
                                    planilha = wb[
                                        "Permissoes Plantas"
                                    ]  # Planta, Conta ou Centro Código

                                    nuc = 2

                                    for email in emails:
                                        if email != "":
                                            planilha[f"A{nuc}"] = str(email)
                                            nuc = nuc + 1
                                        else:
                                            pass

                                    planilha2 = wb[
                                        "Permissoes Contas"
                                    ]  # Planta, Conta ou Centro Código

                                    nucc = 2

                                    for email in emails:
                                        if email != "":
                                            planilha2[f"A{nucc}"] = str(email)
                                            nucc = nucc + 1
                                        else:
                                            pass

                                    planilha3 = wb[
                                        "Permissoes Centros"
                                    ]  # Planta, Conta ou Centro Código

                                    nuccc = 2

                                    for email in emails:
                                        if email != "":
                                            planilha3[f"A{nuccc}"] = str(email)
                                            nuccc = nuccc + 1
                                        else:
                                            pass

                                    wb.save(
                                        "app/static/Excels/Excel_Bases/Brose_Contas_Centros_Permissoes.xlsx"
                                    )

                                    flash(
                                        f"Foram Cadastrados {y} Novos Usuários e {w} Senhas Foram Alteradas"
                                    )
                                else:
                                    pass

            except:
                pass

    return render_template("basetablesupdate.html")


@app.route("/accounts", methods=["GET", "POST"])
def accounts():

    if request.method == "POST":
        try:
            botaoLR = request.form["botaoL"]

            if botaoLR == "HVoltar":
                return redirect(url_for("home"))
            elif botaoLR == "HVerProv":
                return redirect(url_for("viewaccounts"))
            elif botaoLR == "HVerProviso":
                return redirect(url_for("viewprovisions"))
            elif botaoLR == "HEditarProv":
                return redirect(url_for("editprovisions"))
            elif botaoLR == "HCriarProv":
                return redirect(url_for("createprovissions"))
            elif botaoLR == "HPermissoes":
                return redirect(url_for("seeprovisions"))
            if botaoLR == "HDesconectar":
                return redirect(url_for("logout"))

            try:
                if botaoLR == "HPainel":
                    return redirect(url_for("basetablesupdate"))
            except:
                pass

            else:
                pass
        except:
            pass

    return render_template("accounts.html")


@app.route("/centers", methods=["GET", "POST"])
def centers():

    if request.method == "POST":
        try:
            botaoLR = request.form["botaoL"]

            if botaoLR == "HVoltar":
                return redirect(url_for("home"))
            elif botaoLR == "HVerProv":
                return redirect(url_for("viewaccounts"))
            elif botaoLR == "HVerProviso":
                return redirect(url_for("viewprovisions"))
            elif botaoLR == "HEditarProv":
                return redirect(url_for("editprovisions"))
            elif botaoLR == "HCriarProv":
                return redirect(url_for("createprovissions"))
            elif botaoLR == "HPermissoes":
                return redirect(url_for("seeprovisions"))
            elif botaoLR == "HDesconectar":
                return redirect(url_for("logout"))

            try:
                if botaoLR == "HPainel":
                    return redirect(url_for("basetablesupdate"))
            except:
                pass

            else:
                pass
        except:
            pass

    return render_template("centers.html")


@app.route("/users", methods=["GET", "POST"])
def users():

    if request.method == "POST":
        try:
            botaoLR = request.form["botaoL"]

            if botaoLR == "HVoltar":
                return redirect(url_for("home"))
            elif botaoLR == "HVerProv":
                return redirect(url_for("viewaccounts"))
            elif botaoLR == "HVerProviso":
                return redirect(url_for("viewprovisions"))
            elif botaoLR == "HEditarProv":
                return redirect(url_for("editprovisions"))
            elif botaoLR == "HCriarProv":
                return redirect(url_for("createprovissions"))
            elif botaoLR == "HPermissoes":
                return redirect(url_for("seeprovisions"))
            elif botaoLR == "HDesconectar":
                return redirect(url_for("logout"))

            try:
                if botaoLR == "HPainel":
                    return redirect(url_for("basetablesupdate"))
            except:
                pass

            else:
                pass
        except:
            pass

    return render_template("users.html")


@app.route("/plantspermission", methods=["GET", "POST"])
def plantspermission():

    if request.method == "POST":
        try:
            botaoLR = request.form["botaoL"]

            if botaoLR == "HVoltar":
                return redirect(url_for("home"))
            elif botaoLR == "HVerProv":
                return redirect(url_for("viewaccounts"))
            elif botaoLR == "HVerProviso":
                return redirect(url_for("viewprovisions"))
            elif botaoLR == "HEditarProv":
                return redirect(url_for("editprovisions"))
            elif botaoLR == "HCriarProv":
                return redirect(url_for("createprovissions"))
            elif botaoLR == "HPermissoes":
                return redirect(url_for("seeprovisions"))
            elif botaoLR == "HDesconectar":
                return redirect(url_for("logout"))

            try:
                if botaoLR == "HPainel":
                    return redirect(url_for("basetablesupdate"))
            except:
                pass

            else:
                pass
        except:
            pass

    if request.method == "POST":
        try:
            uploaded_file = request.files["abase"]
            filename = uploaded_file.filename

            if filename == "" and request.files["abase"] != "":
                flash("Selecione Um Arquivo")
            elif filename != "" and request.files["abase"] != "":
                file_ext = os.path.splitext(filename)[1]
                if (
                    file_ext not in app.config["UPLOAD_EXTENSIONS"]
                    or filename != "Brose_Contas_Centros_Permissoes.xlsx"
                ):
                    flash(
                        "Formate o Excel com o nome Brose_Contas_Centros_Permissoes.xlsx"
                    )
                else:
                    uploaded_file.save(
                        os.path.join(
                            os.path.join(
                                app.config["UPLOAD_FOLDER"],
                                secure_filename(uploaded_file.filename),
                            )
                        )
                    )

                    # print(planilha.cell(column=last_empty_row, row=2).value)

                    wb = load_workbook(
                        r"app/static/Excels/Excel_Bases/Brose_Contas_Centros_Permissoes.xlsx"
                    )

                    linhas = []

                    planilha = wb["Permissoes Plantas"]
                    last_empty_row = len(list(planilha.rows))

                    # print(f'Ultima Linha Ativa:{last_empty_row}')

                    for i in range(last_empty_row - 2):
                        # print(i + 3)
                        x = i + 3
                        linhas.append(x)

                    ultima_coluna_ativa = planilha.cell(
                        column=last_empty_row, row=1
                    ).value

                    # print(ultima_coluna_ativa)

                    # Cabeçario
                    titulos = planilha["1"]

                    # Cabeçario
                    valores0 = []

                    for titulo in titulos:
                        if (
                            titulo.value is None
                            or titulo.value == "Null"
                            or titulo.value == "None"
                            or titulo.value == ""
                        ):
                            pass
                        else:
                            valores0.append(
                                f'<th class="text-center">{titulo.value} </th>'
                            )

                    listaconjunta = "".join(valores0)
                    cabecariofinal = (
                        listaconjunta.replace("<th><th>", "")
                        .replace("<th>None<th>", "")
                        .replace(r'<th class="text-center">None </th>', "")
                        .replace(r'<th class="text-center">None</th>', "")
                    )

                    file = open(
                        "app/templates/cabecariosplantaspermissoesexcel.html", "w"
                    )

                    file.writelines(cabecariofinal)
                    file.close()

                    # Valores #

                    # Coluna 1

                    valores1 = []

                    segunda_linha = planilha["2"]
                    valores1.append(
                        f'<tr class="text-center" style="display: table-row;">'
                    )
                    for linha in segunda_linha:
                        if (
                            linha.value == ""
                            or linha.value == "Null"
                            or linha.value is None
                        ):
                            pass
                        else:
                            valores1.append(f"<td>{linha.value}</td>")
                            # print(linha.value)
                    valores1.append(f"</tr>")

                    for linha in linhas:
                        linhageral = planilha[f"{linha}"]
                        valores1.append(
                            f'<tr class="text-center" style="display: table-row;">'
                        )
                        for linha in linhageral:
                            if (
                                linha.value == ""
                                or linha.value == "Null"
                                or linha.value is None
                            ):
                                pass
                            else:
                                valores1.append(f"<td>{linha.value}</td>")
                                # print(linha.value)
                        valores1.append(f"</tr>")

                    listamodificada = "".join(valores1)
                    listafinal = (
                        listamodificada.replace(",<td>", "<td>")
                        .replace(
                            "<td>S</td>",
                            r'<td style="background-color:#d1ffcc">Autorizado</td>',
                        )
                        .replace(
                            "<td>N</td>",
                            r'<td style="background-color:#dab5b5">Negado</td>',
                        )
                        .replace(r"<td>", r'<td style="background-color:#d8dba9">')
                    )
                    # print(listafinal)

                    file = open("app/templates/plantaspermissoesexcel.html", "w")

                    file.writelines(listafinal)
                    file.close()

                    wb = load_workbook(
                        r"app/static/Excels/Excel_Bases/Brose_Contas_Centros_Permissoes.xlsx"
                    )

                    linhas = []

                    planilha = wb["Permissoes Contas"]
                    last_empty_row = len(list(planilha.rows))

                    # print(f'Ultima Linha Ativa:{last_empty_row}')

                    for i in range(last_empty_row - 2):
                        # print(i + 3)
                        x = i + 3
                        linhas.append(x)

                    ultima_coluna_ativa = planilha.cell(
                        column=last_empty_row, row=1
                    ).value

                    # print(ultima_coluna_ativa)

                    # Cabeçario
                    titulos = planilha["1"]

                    # Cabeçario
                    valores0 = []

                    for titulo in titulos:
                        if (
                            titulo.value is None
                            or titulo.value == "Null"
                            or titulo.value == "None"
                            or titulo.value == ""
                        ):
                            pass
                        else:
                            valores0.append(
                                f'<th class="text-center">{titulo.value} </th>'
                            )

                    listaconjunta = "".join(valores0)
                    cabecariofinal = listaconjunta.replace("<th><th>", "").replace(
                        "<th>None<th>", ""
                    )

                    file = open(
                        "app/templates/cabecarioscontaspermissoesexcel.html", "w"
                    )

                    file.writelines(cabecariofinal)
                    file.close()

                    # Valores #

                    # Coluna 1

                    valores1 = []

                    segunda_linha = planilha["2"]
                    valores1.append(
                        f'<tr class="text-center" style="display: table-row;">'
                    )
                    for linha in segunda_linha:
                        if (
                            linha.value == ""
                            or linha.value == "Null"
                            or linha.value is None
                        ):
                            pass
                        else:
                            valores1.append(f"<td>{linha.value}</td>")
                            # print(linha.value)
                    valores1.append(f"</tr>")

                    for linha in linhas:
                        linhageral = planilha[f"{linha}"]
                        valores1.append(
                            f'<tr class="text-center" style="display: table-row;">'
                        )
                        for linha in linhageral:
                            if (
                                linha.value == ""
                                or linha.value == "Null"
                                or linha.value is None
                            ):
                                pass
                            else:
                                valores1.append(f"<td>{linha.value}</td>")
                                # print(linha.value)
                        valores1.append(f"</tr>")

                    listamodificada = "".join(valores1)
                    listafinal = (
                        listamodificada.replace(",<td>", "<td>")
                        .replace(
                            "<td>S</td>",
                            r'<td style="background-color:#d1ffcc">Autorizado</td>',
                        )
                        .replace(
                            "<td>N</td>",
                            r'<td style="background-color:#dab5b5">Negado</td>',
                        )
                        .replace(r"<td>", r'<td style="background-color:#d8dba9">')
                    )
                    # print(listafinal)

                    file = open("app/templates/contaspermissoesexcel.html", "w")

                    file.writelines(listafinal)
                    file.close()

                    wb = load_workbook(
                        r"app/static/Excels/Excel_Bases/Brose_Contas_Centros_Permissoes.xlsx"
                    )

                    linhas = []

                    planilha = wb["Permissoes Centros"]
                    last_empty_row = len(list(planilha.rows))

                    # print(f'Ultima Linha Ativa:{last_empty_row}')

                    for i in range(last_empty_row - 2):
                        # print(i + 3)
                        x = i + 3
                        linhas.append(x)

                    ultima_coluna_ativa = planilha.cell(
                        column=last_empty_row, row=1
                    ).value

                    # print(ultima_coluna_ativa)

                    # Cabeçario
                    titulos = planilha["1"]

                    # Cabeçario
                    valores0 = []

                    for titulo in titulos:
                        if (
                            titulo.value is None
                            or titulo.value == "Null"
                            or titulo.value == "None"
                            or titulo.value == ""
                        ):
                            pass
                        else:
                            valores0.append(
                                f'<th class="text-center">{titulo.value} </th>'
                            )

                    listaconjunta = "".join(valores0)
                    cabecariofinal = listaconjunta.replace("<th><th>", "").replace(
                        "<th>None<th>", ""
                    )

                    file = open(
                        "app/templates/cabecarioscentrospermissoesexcel.html", "w"
                    )

                    file.writelines(cabecariofinal)
                    file.close()

                    # Valores #

                    # Coluna 1

                    valores1 = []

                    segunda_linha = planilha["2"]
                    valores1.append(
                        f'<tr class="text-center" style="display: table-row;">'
                    )
                    for linha in segunda_linha:
                        if (
                            linha.value == ""
                            or linha.value == "Null"
                            or linha.value is None
                        ):
                            pass
                        else:
                            valores1.append(f"<td>{linha.value}</td>")
                            # print(linha.value)
                    valores1.append(f"</tr>")

                    for linha in linhas:
                        linhageral = planilha[f"{linha}"]
                        valores1.append(
                            f'<tr class="text-center" style="display: table-row;">'
                        )
                        for linha in linhageral:
                            if (
                                linha.value == ""
                                or linha.value == "Null"
                                or linha.value is None
                            ):
                                pass
                            else:
                                valores1.append(f"<td>{linha.value}</td>")
                                # print(linha.value)
                        valores1.append(f"</tr>")

                    listamodificada = "".join(valores1)
                    listafinal = (
                        listamodificada.replace(",<td>", "<td>")
                        .replace(
                            "<td>S</td>",
                            r'<td style="background-color:#d1ffcc">Autorizado</td>',
                        )
                        .replace(
                            "<td>N</td>",
                            r'<td style="background-color:#dab5b5">Negado</td>',
                        )
                        .replace(r"<td>", r'<td style="background-color:#d8dba9">')
                    )
                    # print(listafinal)

                    file = open("app/templates/centrospermissoesexcel.html", "w")

                    file.writelines(listafinal)
                    file.close()

                    wb = load_workbook(
                        "app/static/Excels/Excel_Bases/Brose_Contas_Centros_Permissoes.xlsx",
                        data_only=True,
                    )
                    planilha = wb["Plantas Codigos"]  # Planta, Conta ou Centro Código

                    emails = []
                    for instance in db.session.query(User):
                        x = instance.email
                        emails.append(x)

                    registro_permissoes1 = {}
                    registro_permissoes2 = {}
                    registro_permissoes3 = {}
                    for email in emails:

                        for row in planilha.iter_rows():
                            for cell in row:
                                if cell.value == email:  # Email do Usuário
                                    # print(cell.column, cell.row)
                                    linha = str(cell.row)

                                    # print(cell.row)
                                    permissoes = []

                                    for valor2 in planilha[f"{linha[0]}"]:
                                        if (
                                            str(valor2.value) == str(email)
                                            or valor2.value == ""
                                            or valor2.value == "0"
                                            or valor2.value == "N"
                                            or valor2.value is None
                                        ):
                                            pass
                                        else:
                                            permissoes.append(str(valor2.value))
                                            # print(valor2.value)

                                    permissoes_final = [*set(permissoes)]

                                    # print(permissoes_final)
                                    registro_permissoes1[f"{email}"] = permissoes_final

                    planilha2 = wb["Contas Codigos"]  # Planta, Conta ou Centro Código

                    for email in emails:

                        for row in planilha2.iter_rows():
                            for cell in row:
                                if cell.value == email:  # Email do Usuário
                                    # print(cell.column, cell.row)
                                    linha = str(cell.row)

                                    # print(cell.row)
                                    permissoes = []

                                    for valor2 in planilha2[f"{linha[0]}"]:
                                        if (
                                            str(valor2.value) == str(email)
                                            or valor2.value == ""
                                            or valor2.value == "0"
                                            or valor2.value == "N"
                                            or valor2.value is None
                                        ):
                                            pass
                                        else:
                                            permissoes.append(str(valor2.value))
                                            # print(valor2.value)

                                    permissoes_final = [*set(permissoes)]

                                    # print(permissoes_final)
                                    registro_permissoes2[f"{email}"] = permissoes_final

                    planilha3 = wb["Centros Codigos"]  # Planta, Conta ou Centro Código

                    for email in emails:

                        for row in planilha3.iter_rows():
                            for cell in row:
                                if cell.value == email:  # Email do Usuário
                                    # print(cell.column, cell.row)
                                    linha = str(cell.row)

                                    # print(cell.row)
                                    permissoes = []

                                    for valor2 in planilha3[f"{linha[0]}"]:
                                        if (
                                            str(valor2.value) == str(email)
                                            or valor2.value == ""
                                            or valor2.value == "0"
                                            or valor2.value == "N"
                                            or valor2.value is None
                                        ):
                                            pass
                                        else:
                                            permissoes.append(str(valor2.value))
                                            # print(valor2.value)

                                    permissoes_final = [*set(permissoes)]

                                    # print(permissoes_final)
                                    registro_permissoes3[f"{email}"] = permissoes_final

                    with open(
                        "app/static/Permissoes/autorizacoesplantas.json", "w"
                    ) as data1:
                        json.dump(registro_permissoes1, data1)

                    with open(
                        "app/static/Permissoes/autorizacoesplantas.json", "r"
                    ) as data2:
                        autplanta = json.load(data2)

                    with open(
                        "app/static/Permissoes/autorizacoescontas.json", "w"
                    ) as data3:
                        json.dump(registro_permissoes2, data3)

                    with open(
                        "app/static/Permissoes/autorizacoescontas.json", "r"
                    ) as data4:
                        autconta = json.load(data4)

                    with open(
                        "app/static/Permissoes/autorizacoescentros.json", "w"
                    ) as data5:
                        json.dump(registro_permissoes3, data5)

                    with open(
                        "app/static/Permissoes/autorizacoescentros.json", "r"
                    ) as data6:
                        autcentro = json.load(data6)

                    # print(autplanta)
                    # print(autconta)
                    # print(autcentro)

                    from datetime import datetime

                    mes1 = datetime.now().month
                    if mes1 == 1:
                        mes = "Janeiro"

                    elif mes1 == 2:
                        mes = "Fevereiro"

                    elif mes1 == 3:
                        mes = "Marco"

                    elif mes1 == 4:
                        mes = "Abril"

                    elif mes1 == 5:
                        mes = "Maio"

                    elif mes1 == 6:
                        mes = "Junho"

                    elif mes1 == 7:
                        mes = "Julho"

                    elif mes1 == 8:
                        mes = "Agosto"

                    elif mes1 == 9:
                        mes = "Setembro"

                    elif mes1 == 10:
                        mes = "Outubro"

                    elif mes1 == 11:
                        mes = "Novembro"

                    elif mes1 == 12:
                        mes = "Dezembro"

                    emailsss = []
                    for instance in db.session.query(User):
                        x = instance.email
                        emailsss.append(x)
                    # print(emails)

                    for email in emailsss:

                        with open(
                                "app/static/Permissoes/autorizacoesplantas.json", "r"
                        ) as data2:
                            autplanta = json.load(data2)

                        with open(
                                "app/static/Permissoes/autorizacoescontas.json", "r"
                        ) as data4:
                            autconta = json.load(data4)

                        with open(
                                "app/static/Permissoes/autorizacoescentros.json", "r"
                        ) as data6:
                            autcentro = json.load(data6)

                        pplantas = autplanta[f"{email}"]

                        pcontas = autconta[f"{email}"]

                        pcentro = autcentro[f"{email}"]

                        # print(pplantas,pcontas,pcentro)

                        wb11 = load_workbook(
                            r"app/static/Excels/Excel_Bases/Base_Provisoes.xlsx",
                            data_only=True,
                        )

                        planilhaCC = wb11["Extrato Ano"]

                        for cell in planilhaCC["C"][1:]:
                            # print(cell.value)
                            if str(cell.value) not in str(pcentro):
                                planilhaCC.delete_rows(cell.row)

                        for cell in planilhaCC["D"][1:]:
                            # print(cell.value)
                            if str(cell.value) not in str(pcontas):
                                planilhaCC.delete_rows(cell.row)

                        for cell in planilhaCC["J"][1:]:
                            # print(cell.value)
                            if str(cell.value) not in str(pplantas):
                                planilhaCC.delete_rows(cell.row)

                        planilhaMM = wb11["Mes Atual"]

                        for cell3 in planilhaMM["E"][1:]:
                            # print(cell.value)
                            if str(cell3.value) not in str(pcontas):
                                planilhaMM.delete_rows(cell3.row)

                        for cell3 in planilhaMM['D'][1:]:
                             # print(cell.value)
                             if str(cell3.value) not in str(pcentro):
                                 planilhaMM.delete_rows(cell3.row)

                        planilhaMMT = wb11["Resumo Mes Atual"]

                        pivot = planilhaMMT._pivots[0]
                        pivot.cache.refreshOnLoad = True

                        usuario = db.session.query(User).filter_by(email=email).first()

                        wb11.save(
                            f"app/static/Excels/Excel_Usuarios/Provisoes_id_{str(usuario.id)}_{mes}.xlsx"
                        )

                    flash("Novas Permissões de Acesso Cadastradas Com Sucesso")

        except:
            pass

    return render_template("plantspermission.html")


@app.route("/accountspermission", methods=["GET", "POST"])
def accountspermission():

    if request.method == "POST":
        try:
            botaoLR = request.form["botaoL"]

            if botaoLR == "HVoltar":
                return redirect(url_for("home"))
            elif botaoLR == "HVerProv":
                return redirect(url_for("viewaccounts"))
            elif botaoLR == "HVerProviso":
                return redirect(url_for("viewprovisions"))
            elif botaoLR == "HEditarProv":
                return redirect(url_for("editprovisions"))
            elif botaoLR == "HCriarProv":
                return redirect(url_for("createprovissions"))
            elif botaoLR == "HPermissoes":
                return redirect(url_for("seeprovisions"))
            elif botaoLR == "HDesconectar":
                return redirect(url_for("logout"))

            try:
                if botaoLR == "HPainel":
                    return redirect(url_for("basetablesupdate"))
            except:
                pass

            else:
                pass
        except:
            pass

    if request.method == "POST":
        try:
            uploaded_file = request.files["abase"]
            filename = uploaded_file.filename

            if filename == "" and request.files["abase"] != "":
                flash("Selecione Um Arquivo")
            elif filename != "" and request.files["abase"] != "":
                file_ext = os.path.splitext(filename)[1]
                if (
                    file_ext not in app.config["UPLOAD_EXTENSIONS"]
                    or filename != "Brose_Contas_Centros_Permissoes.xlsx"
                ):
                    flash(
                        "Formate o Excel com o nome Brose_Contas_Centros_Permissoes.xlsx"
                    )
                else:
                    uploaded_file.save(
                        os.path.join(
                            os.path.join(
                                app.config["UPLOAD_FOLDER"],
                                secure_filename(uploaded_file.filename),
                            )
                        )
                    )

                    # print(planilha.cell(column=last_empty_row, row=2).value)

                    wb = load_workbook(
                        r"app/static/Excels/Excel_Bases/Brose_Contas_Centros_Permissoes.xlsx"
                    )

                    linhas = []

                    planilha = wb["Permissoes Plantas"]
                    last_empty_row = len(list(planilha.rows))

                    # print(f'Ultima Linha Ativa:{last_empty_row}')

                    for i in range(last_empty_row - 2):
                        # print(i + 3)
                        x = i + 3
                        linhas.append(x)

                    ultima_coluna_ativa = planilha.cell(
                        column=last_empty_row, row=1
                    ).value

                    # print(ultima_coluna_ativa)

                    # Cabeçario
                    titulos = planilha["1"]

                    # Cabeçario
                    valores0 = []

                    for titulo in titulos:
                        if (
                            titulo.value is None
                            or titulo.value == "Null"
                            or titulo.value == "None"
                            or titulo.value == ""
                        ):
                            pass
                        else:
                            valores0.append(
                                f'<th class="text-center">{titulo.value} </th>'
                            )

                    listaconjunta = "".join(valores0)
                    cabecariofinal = (
                        listaconjunta.replace("<th><th>", "")
                        .replace("<th>None<th>", "")
                        .replace(r'<th class="text-center">None </th>', "")
                        .replace(r'<th class="text-center">None</th>', "")
                    )

                    file = open(
                        "app/templates/cabecariosplantaspermissoesexcel.html", "w"
                    )

                    file.writelines(cabecariofinal)
                    file.close()

                    # Valores #

                    # Coluna 1

                    valores1 = []

                    segunda_linha = planilha["2"]
                    valores1.append(
                        f'<tr class="text-center" style="display: table-row;">'
                    )
                    for linha in segunda_linha:
                        if (
                            linha.value == ""
                            or linha.value == "Null"
                            or linha.value is None
                        ):
                            pass
                        else:
                            valores1.append(f"<td>{linha.value}</td>")
                            # print(linha.value)
                    valores1.append(f"</tr>")

                    for linha in linhas:
                        linhageral = planilha[f"{linha}"]
                        valores1.append(
                            f'<tr class="text-center" style="display: table-row;">'
                        )
                        for linha in linhageral:
                            if (
                                linha.value == ""
                                or linha.value == "Null"
                                or linha.value is None
                            ):
                                pass
                            else:
                                valores1.append(f"<td>{linha.value}</td>")
                                # print(linha.value)
                        valores1.append(f"</tr>")

                    listamodificada = "".join(valores1)
                    listafinal = (
                        listamodificada.replace(",<td>", "<td>")
                        .replace(
                            "<td>S</td>",
                            r'<td style="background-color:#d1ffcc">Autorizado</td>',
                        )
                        .replace(
                            "<td>N</td>",
                            r'<td style="background-color:#dab5b5">Negado</td>',
                        )
                        .replace(r"<td>", r'<td style="background-color:#d8dba9">')
                    )
                    # print(listafinal)

                    file = open("app/templates/plantaspermissoesexcel.html", "w")

                    file.writelines(listafinal)
                    file.close()

                    wb = load_workbook(
                        r"app/static/Excels/Excel_Bases/Brose_Contas_Centros_Permissoes.xlsx"
                    )

                    linhas = []

                    planilha = wb["Permissoes Contas"]
                    last_empty_row = len(list(planilha.rows))

                    ## print(f'Ultima Linha Ativa:{last_empty_row}')

                    for i in range(last_empty_row - 2):
                        # print(i + 3)
                        x = i + 3
                        linhas.append(x)

                    ultima_coluna_ativa = planilha.cell(
                        column=last_empty_row, row=1
                    ).value

                    # print(ultima_coluna_ativa)

                    # Cabeçario
                    titulos = planilha["1"]

                    # Cabeçario
                    valores0 = []

                    for titulo in titulos:
                        if (
                            titulo.value is None
                            or titulo.value == "Null"
                            or titulo.value == "None"
                            or titulo.value == ""
                        ):
                            pass
                        else:
                            valores0.append(
                                f'<th class="text-center">{titulo.value} </th>'
                            )

                    listaconjunta = "".join(valores0)
                    cabecariofinal = listaconjunta.replace("<th><th>", "").replace(
                        "<th>None<th>", ""
                    )

                    file = open(
                        "app/templates/cabecarioscontaspermissoesexcel.html", "w"
                    )

                    file.writelines(cabecariofinal)
                    file.close()

                    # Valores #

                    # Coluna 1

                    valores1 = []

                    segunda_linha = planilha["2"]
                    valores1.append(
                        f'<tr class="text-center" style="display: table-row;">'
                    )
                    for linha in segunda_linha:
                        if (
                            linha.value == ""
                            or linha.value == "Null"
                            or linha.value is None
                        ):
                            pass
                        else:
                            valores1.append(f"<td>{linha.value}</td>")
                            # print(linha.value)
                    valores1.append(f"</tr>")

                    for linha in linhas:
                        linhageral = planilha[f"{linha}"]
                        valores1.append(
                            f'<tr class="text-center" style="display: table-row;">'
                        )
                        for linha in linhageral:
                            if (
                                linha.value == ""
                                or linha.value == "Null"
                                or linha.value is None
                            ):
                                pass
                            else:
                                valores1.append(f"<td>{linha.value}</td>")
                                # print(linha.value)
                        valores1.append(f"</tr>")

                    listamodificada = "".join(valores1)
                    listafinal = (
                        listamodificada.replace(",<td>", "<td>")
                        .replace(
                            "<td>S</td>",
                            r'<td style="background-color:#d1ffcc">Autorizado</td>',
                        )
                        .replace(
                            "<td>N</td>",
                            r'<td style="background-color:#dab5b5">Negado</td>',
                        )
                        .replace(r"<td>", r'<td style="background-color:#d8dba9">')
                    )
                    # print(listafinal)

                    file = open("app/templates/contaspermissoesexcel.html", "w")

                    file.writelines(listafinal)
                    file.close()

                    wb = load_workbook(
                        r"app/static/Excels/Excel_Bases/Brose_Contas_Centros_Permissoes.xlsx"
                    )

                    linhas = []

                    planilha = wb["Permissoes Centros"]
                    last_empty_row = len(list(planilha.rows))

                    # print(f'Ultima Linha Ativa:{last_empty_row}')

                    for i in range(last_empty_row - 2):
                        # print(i + 3)
                        x = i + 3
                        linhas.append(x)

                    ultima_coluna_ativa = planilha.cell(
                        column=last_empty_row, row=1
                    ).value

                    # print(ultima_coluna_ativa)

                    # Cabeçario
                    titulos = planilha["1"]

                    # Cabeçario
                    valores0 = []

                    for titulo in titulos:
                        if (
                            titulo.value is None
                            or titulo.value == "Null"
                            or titulo.value == "None"
                            or titulo.value == ""
                        ):
                            pass
                        else:
                            valores0.append(
                                f'<th class="text-center">{titulo.value} </th>'
                            )

                    listaconjunta = "".join(valores0)
                    cabecariofinal = listaconjunta.replace("<th><th>", "").replace(
                        "<th>None<th>", ""
                    )

                    file = open(
                        "app/templates/cabecarioscentrospermissoesexcel.html", "w"
                    )

                    file.writelines(cabecariofinal)
                    file.close()

                    # Valores #

                    # Coluna 1

                    valores1 = []

                    segunda_linha = planilha["2"]
                    valores1.append(
                        f'<tr class="text-center" style="display: table-row;">'
                    )
                    for linha in segunda_linha:
                        if (
                            linha.value == ""
                            or linha.value == "Null"
                            or linha.value is None
                        ):
                            pass
                        else:
                            valores1.append(f"<td>{linha.value}</td>")
                            # print(linha.value)
                    valores1.append(f"</tr>")

                    for linha in linhas:
                        linhageral = planilha[f"{linha}"]
                        valores1.append(
                            f'<tr class="text-center" style="display: table-row;">'
                        )
                        for linha in linhageral:
                            if (
                                linha.value == ""
                                or linha.value == "Null"
                                or linha.value is None
                            ):
                                pass
                            else:
                                valores1.append(f"<td>{linha.value}</td>")
                                # print(linha.value)
                        valores1.append(f"</tr>")

                    listamodificada = "".join(valores1)
                    listafinal = (
                        listamodificada.replace(",<td>", "<td>")
                        .replace(
                            "<td>S</td>",
                            r'<td style="background-color:#d1ffcc">Autorizado</td>',
                        )
                        .replace(
                            "<td>N</td>",
                            r'<td style="background-color:#dab5b5">Negado</td>',
                        )
                        .replace(r"<td>", r'<td style="background-color:#d8dba9">')
                    )
                    # print(listafinal)

                    file = open("app/templates/centrospermissoesexcel.html", "w")

                    file.writelines(listafinal)
                    file.close()

                    wb = load_workbook(
                        "app/static/Excels/Excel_Bases/Brose_Contas_Centros_Permissoes.xlsx",
                        data_only=True,
                    )
                    planilha = wb["Plantas Codigos"]  # Planta, Conta ou Centro Código

                    emails = []
                    for instance in db.session.query(User):
                        x = instance.email
                        emails.append(x)

                    registro_permissoes1 = {}
                    registro_permissoes2 = {}
                    registro_permissoes3 = {}
                    for email in emails:

                        for row in planilha.iter_rows():
                            for cell in row:
                                if cell.value == email:  # Email do Usuário
                                    # print(cell.column, cell.row)
                                    linha = str(cell.row)

                                    # print(cell.row)
                                    permissoes = []

                                    for valor2 in planilha[f"{linha[0]}"]:
                                        if (
                                            str(valor2.value) == str(email)
                                            or valor2.value == ""
                                            or valor2.value == "0"
                                            or valor2.value == "N"
                                            or valor2.value is None
                                        ):
                                            pass
                                        else:
                                            permissoes.append(str(valor2.value))
                                            # print(valor2.value)

                                    permissoes_final = [*set(permissoes)]

                                    # print(permissoes_final)
                                    registro_permissoes1[f"{email}"] = permissoes_final

                    planilha2 = wb["Contas Codigos"]  # Planta, Conta ou Centro Código

                    for email in emails:

                        for row in planilha2.iter_rows():
                            for cell in row:
                                if cell.value == email:  # Email do Usuário
                                    # print(cell.column, cell.row)
                                    linha = str(cell.row)

                                    # print(cell.row)
                                    permissoes = []

                                    for valor2 in planilha2[f"{linha[0]}"]:
                                        if (
                                            str(valor2.value) == str(email)
                                            or valor2.value == ""
                                            or valor2.value == "0"
                                            or valor2.value == "N"
                                            or valor2.value is None
                                        ):
                                            pass
                                        else:
                                            permissoes.append(str(valor2.value))
                                            # print(valor2.value)

                                    permissoes_final = [*set(permissoes)]

                                    # print(permissoes_final)
                                    registro_permissoes2[f"{email}"] = permissoes_final

                    planilha3 = wb["Centros Codigos"]  # Planta, Conta ou Centro Código

                    for email in emails:

                        for row in planilha3.iter_rows():
                            for cell in row:
                                if cell.value == email:  # Email do Usuário
                                    # print(cell.column, cell.row)
                                    linha = str(cell.row)

                                    # print(cell.row)
                                    permissoes = []

                                    for valor2 in planilha3[f"{linha[0]}"]:
                                        if (
                                            str(valor2.value) == str(email)
                                            or valor2.value == ""
                                            or valor2.value == "0"
                                            or valor2.value == "N"
                                            or valor2.value is None
                                        ):
                                            pass
                                        else:
                                            permissoes.append(str(valor2.value))
                                            # print(valor2.value)

                                    permissoes_final = [*set(permissoes)]

                                    # print(permissoes_final)
                                    registro_permissoes3[f"{email}"] = permissoes_final

                    with open(
                        "app/static/Permissoes/autorizacoesplantas.json", "w"
                    ) as data1:
                        json.dump(registro_permissoes1, data1)

                    with open(
                        "app/static/Permissoes/autorizacoesplantas.json", "r"
                    ) as data2:
                        autplanta = json.load(data2)

                    with open(
                        "app/static/Permissoes/autorizacoescontas.json", "w"
                    ) as data3:
                        json.dump(registro_permissoes2, data3)

                    with open(
                        "app/static/Permissoes/autorizacoescontas.json", "r"
                    ) as data4:
                        autconta = json.load(data4)

                    with open(
                        "app/static/Permissoes/autorizacoescentros.json", "w"
                    ) as data5:
                        json.dump(registro_permissoes3, data5)

                    with open(
                        "app/static/Permissoes/autorizacoescentros.json", "r"
                    ) as data6:
                        autcentro = json.load(data6)

                    # print(autplanta)
                    # print(autconta)
                    # print(autcentro)

                    from datetime import datetime

                    mes1 = datetime.now().month
                    if mes1 == 1:
                        mes = "Janeiro"

                    elif mes1 == 2:
                        mes = "Fevereiro"

                    elif mes1 == 3:
                        mes = "Marco"

                    elif mes1 == 4:
                        mes = "Abril"

                    elif mes1 == 5:
                        mes = "Maio"

                    elif mes1 == 6:
                        mes = "Junho"

                    elif mes1 == 7:
                        mes = "Julho"

                    elif mes1 == 8:
                        mes = "Agosto"

                    elif mes1 == 9:
                        mes = "Setembro"

                    elif mes1 == 10:
                        mes = "Outubro"

                    elif mes1 == 11:
                        mes = "Novembro"

                    elif mes1 == 12:
                        mes = "Dezembro"

                    emailsss = []
                    for instance in db.session.query(User):
                        x = instance.email
                        emailsss.append(x)
                    # print(emails)

                    for email in emailsss:

                        with open(
                            "app/static/Permissoes/autorizacoesplantas.json", "r"
                        ) as data2:
                            autplanta = json.load(data2)

                        with open(
                            "app/static/Permissoes/autorizacoescontas.json", "r"
                        ) as data4:
                            autconta = json.load(data4)

                        with open(
                            "app/static/Permissoes/autorizacoescentros.json", "r"
                        ) as data6:
                            autcentro = json.load(data6)

                        pplantas = autplanta[f"{email}"]

                        pcontas = autconta[f"{email}"]

                        pcentro = autcentro[f"{email}"]

                        # print(pplantas,pcontas,pcentro)

                        wb11 = load_workbook(
                            r"app/static/Excels/Excel_Bases/Base_Provisoes.xlsx",
                            data_only=True,
                        )

                        planilhaCC = wb11["Contas"]

                        for cell in planilhaCC["C"][1:]:
                            # print(cell.value)
                            if str(cell.value) not in str(pcentro):
                                planilhaCC.delete_rows(cell.row)

                        for cell in planilhaCC["D"][1:]:
                            # print(cell.value)
                            if str(cell.value) not in str(pcontas):
                                planilhaCC.delete_rows(cell.row)

                        for cell in planilhaCC["J"][1:]:
                            # print(cell.value)
                            if str(cell.value) not in str(pplantas):
                                planilhaCC.delete_rows(cell.row)

                        planilhaGG = wb11["Geral"]

                        # for cell2 in planilhaGG['B'][1:]:
                        #     # print(cell.value)
                        #     if str(cell2.value) not in str(pcentro) and str(cell2.value) != "Total":
                        #         planilhaGG.delete_rows(cell2.row)

                        for cell2 in planilhaGG["A"][1:]:
                            # print(cell.value)
                            if str(cell2.value) not in str(pcontas):
                                planilhaGG.delete_rows(cell2.row)

                        planilhaMM = wb11["Mes"]

                        # for cell3 in planilhaMM['B'][1:]:
                        #     # print(cell.value)
                        #     if str(cell3.value) not in str(pcentro) and str(cell2.value) != "Total":
                        #         planilhaMM.delete_rows(cell3.row)

                        for cell3 in planilhaMM["A"][1:]:
                            # print(cell.value)
                            if str(cell3.value) not in str(pcontas):
                                planilhaMM.delete_rows(cell3.row)

                        planilhaGGT = wb11["Geral Tabela"]
                        planilhaMMT = wb11["Mes Tabela"]

                        pivot = planilhaGGT._pivots[0]
                        pivot.cache.refreshOnLoad = True

                        pivot = planilhaMMT._pivots[0]
                        pivot.cache.refreshOnLoad = True

                        usuario = db.session.query(User).filter_by(email=email).first()

                        wb11.save(
                            f"app/static/Excels/Excel_Usuarios/Provisoes_id_{str(usuario.id)}_{mes}.xlsx"
                        )

                    flash("Novas Permissões de Acesso Cadastradas Com Sucesso")

        except:
            pass

    return render_template("accountspermission.html")


@app.route("/centerspermission", methods=["GET", "POST"])
def centerspermission():

    if request.method == "POST":
        try:
            botaoLR = request.form["botaoL"]

            if botaoLR == "HVoltar":
                return redirect(url_for("home"))
            elif botaoLR == "HVerProv":
                return redirect(url_for("viewaccounts"))
            elif botaoLR == "HVerProviso":
                return redirect(url_for("viewprovisions"))
            elif botaoLR == "HEditarProv":
                return redirect(url_for("editprovisions"))
            elif botaoLR == "HCriarProv":
                return redirect(url_for("createprovissions"))
            elif botaoLR == "HPermissoes":
                return redirect(url_for("seeprovisions"))
            elif botaoLR == "HDesconectar":
                return redirect(url_for("logout"))

            try:
                if botaoLR == "HPainel":
                    return redirect(url_for("basetablesupdate"))
            except:
                pass

            else:
                pass
        except:
            pass

    if request.method == "POST":
        try:
            uploaded_file = request.files["abase"]
            filename = uploaded_file.filename

            if filename == "" and request.files["abase"] != "":
                flash("Selecione Um Arquivo")
            elif filename != "" and request.files["abase"] != "":
                file_ext = os.path.splitext(filename)[1]
                if (
                    file_ext not in app.config["UPLOAD_EXTENSIONS"]
                    or filename != "Brose_Contas_Centros_Permissoes.xlsx"
                ):
                    flash(
                        "Formate o Excel com o nome Brose_Contas_Centros_Permissoes.xlsx"
                    )
                else:
                    uploaded_file.save(
                        os.path.join(
                            os.path.join(
                                app.config["UPLOAD_FOLDER"],
                                secure_filename(uploaded_file.filename),
                            )
                        )
                    )

                    # print(planilha.cell(column=last_empty_row, row=2).value)

                    wb = load_workbook(
                        r"app/static/Excels/Excel_Bases/Brose_Contas_Centros_Permissoes.xlsx"
                    )

                    linhas = []

                    planilha = wb["Permissoes Plantas"]
                    last_empty_row = len(list(planilha.rows))

                    # print(f'Ultima Linha Ativa:{last_empty_row}')

                    for i in range(last_empty_row - 2):
                        # print(i + 3)
                        x = i + 3
                        linhas.append(x)

                    ultima_coluna_ativa = planilha.cell(
                        column=last_empty_row, row=1
                    ).value

                    # print(ultima_coluna_ativa)

                    # Cabeçario
                    titulos = planilha["1"]

                    # Cabeçario
                    valores0 = []

                    for titulo in titulos:
                        if (
                            titulo.value is None
                            or titulo.value == "Null"
                            or titulo.value == "None"
                            or titulo.value == ""
                        ):
                            pass
                        else:
                            valores0.append(
                                f'<th class="text-center">{titulo.value} </th>'
                            )

                    listaconjunta = "".join(valores0)
                    cabecariofinal = (
                        listaconjunta.replace("<th><th>", "")
                        .replace("<th>None<th>", "")
                        .replace(r'<th class="text-center">None </th>', "")
                        .replace(r'<th class="text-center">None</th>', "")
                    )

                    file = open(
                        "app/templates/cabecariosplantaspermissoesexcel.html", "w"
                    )

                    file.writelines(cabecariofinal)
                    file.close()

                    # Valores #

                    # Coluna 1

                    valores1 = []

                    segunda_linha = planilha["2"]
                    valores1.append(
                        f'<tr class="text-center" style="display: table-row;">'
                    )
                    for linha in segunda_linha:
                        if (
                            linha.value == ""
                            or linha.value == "Null"
                            or linha.value is None
                        ):
                            pass
                        else:
                            valores1.append(f"<td>{linha.value}</td>")
                            # print(linha.value)
                    valores1.append(f"</tr>")

                    for linha in linhas:
                        linhageral = planilha[f"{linha}"]
                        valores1.append(
                            f'<tr class="text-center" style="display: table-row;">'
                        )
                        for linha in linhageral:
                            if (
                                linha.value == ""
                                or linha.value == "Null"
                                or linha.value is None
                            ):
                                pass
                            else:
                                valores1.append(f"<td>{linha.value}</td>")
                                # print(linha.value)
                        valores1.append(f"</tr>")

                    listamodificada = "".join(valores1)
                    listafinal = (
                        listamodificada.replace(",<td>", "<td>")
                        .replace(
                            "<td>S</td>",
                            r'<td style="background-color:#d1ffcc">Autorizado</td>',
                        )
                        .replace(
                            "<td>N</td>",
                            r'<td style="background-color:#dab5b5">Negado</td>',
                        )
                        .replace(r"<td>", r'<td style="background-color:#d8dba9">')
                    )
                    # print(listafinal)

                    file = open("app/templates/plantaspermissoesexcel.html", "w")

                    file.writelines(listafinal)
                    file.close()

                    wb = load_workbook(
                        r"app/static/Excels/Excel_Bases/Brose_Contas_Centros_Permissoes.xlsx"
                    )

                    linhas = []

                    planilha = wb["Permissoes Contas"]
                    last_empty_row = len(list(planilha.rows))

                    # print(f'Ultima Linha Ativa:{last_empty_row}')

                    for i in range(last_empty_row - 2):
                        # print(i + 3)
                        x = i + 3
                        linhas.append(x)

                    ultima_coluna_ativa = planilha.cell(
                        column=last_empty_row, row=1
                    ).value

                    # print(ultima_coluna_ativa)

                    # Cabeçario
                    titulos = planilha["1"]

                    # Cabeçario
                    valores0 = []

                    for titulo in titulos:
                        if (
                            titulo.value is None
                            or titulo.value == "Null"
                            or titulo.value == "None"
                            or titulo.value == ""
                        ):
                            pass
                        else:
                            valores0.append(
                                f'<th class="text-center">{titulo.value} </th>'
                            )

                    listaconjunta = "".join(valores0)
                    cabecariofinal = listaconjunta.replace("<th><th>", "").replace(
                        "<th>None<th>", ""
                    )

                    file = open(
                        "app/templates/cabecarioscontaspermissoesexcel.html", "w"
                    )

                    file.writelines(cabecariofinal)
                    file.close()

                    # Valores #

                    # Coluna 1

                    valores1 = []

                    segunda_linha = planilha["2"]
                    valores1.append(
                        f'<tr class="text-center" style="display: table-row;">'
                    )
                    for linha in segunda_linha:
                        if (
                            linha.value == ""
                            or linha.value == "Null"
                            or linha.value is None
                        ):
                            pass
                        else:
                            valores1.append(f"<td>{linha.value}</td>")
                            # print(linha.value)
                    valores1.append(f"</tr>")

                    for linha in linhas:
                        linhageral = planilha[f"{linha}"]
                        valores1.append(
                            f'<tr class="text-center" style="display: table-row;">'
                        )
                        for linha in linhageral:
                            if (
                                linha.value == ""
                                or linha.value == "Null"
                                or linha.value is None
                            ):
                                pass
                            else:
                                valores1.append(f"<td>{linha.value}</td>")
                                # print(linha.value)
                        valores1.append(f"</tr>")

                    listamodificada = "".join(valores1)
                    listafinal = (
                        listamodificada.replace(",<td>", "<td>")
                        .replace(
                            "<td>S</td>",
                            r'<td style="background-color:#d1ffcc">Autorizado</td>',
                        )
                        .replace(
                            "<td>N</td>",
                            r'<td style="background-color:#dab5b5">Negado</td>',
                        )
                        .replace(r"<td>", r'<td style="background-color:#d8dba9">')
                    )
                    # print(listafinal)

                    file = open("app/templates/contaspermissoesexcel.html", "w")

                    file.writelines(listafinal)
                    file.close()

                    wb = load_workbook(
                        r"app/static/Excels/Excel_Bases/Brose_Contas_Centros_Permissoes.xlsx"
                    )

                    linhas = []

                    planilha = wb["Permissoes Centros"]
                    last_empty_row = len(list(planilha.rows))

                    # print(f'Ultima Linha Ativa:{last_empty_row}')

                    for i in range(last_empty_row - 2):
                        # print(i + 3)
                        x = i + 3
                        linhas.append(x)

                    ultima_coluna_ativa = planilha.cell(
                        column=last_empty_row, row=1
                    ).value

                    # print(ultima_coluna_ativa)

                    # Cabeçario
                    titulos = planilha["1"]

                    # Cabeçario
                    valores0 = []

                    for titulo in titulos:
                        if (
                            titulo.value is None
                            or titulo.value == "Null"
                            or titulo.value == "None"
                            or titulo.value == ""
                        ):
                            pass
                        else:
                            valores0.append(
                                f'<th class="text-center">{titulo.value} </th>'
                            )

                    listaconjunta = "".join(valores0)
                    cabecariofinal = listaconjunta.replace("<th><th>", "").replace(
                        "<th>None<th>", ""
                    )

                    file = open(
                        "app/templates/cabecarioscentrospermissoesexcel.html", "w"
                    )

                    file.writelines(cabecariofinal)
                    file.close()

                    # Valores #

                    # Coluna 1

                    valores1 = []

                    segunda_linha = planilha["2"]
                    valores1.append(
                        f'<tr class="text-center" style="display: table-row;">'
                    )
                    for linha in segunda_linha:
                        if (
                            linha.value == ""
                            or linha.value == "Null"
                            or linha.value is None
                        ):
                            pass
                        else:
                            valores1.append(f"<td>{linha.value}</td>")
                            # print(linha.value)
                    valores1.append(f"</tr>")

                    for linha in linhas:
                        linhageral = planilha[f"{linha}"]
                        valores1.append(
                            f'<tr class="text-center" style="display: table-row;">'
                        )
                        for linha in linhageral:
                            if (
                                linha.value == ""
                                or linha.value == "Null"
                                or linha.value is None
                            ):
                                pass
                            else:
                                valores1.append(f"<td>{linha.value}</td>")
                                # print(linha.value)
                        valores1.append(f"</tr>")

                    listamodificada = "".join(valores1)
                    listafinal = (
                        listamodificada.replace(",<td>", "<td>")
                        .replace(
                            "<td>S</td>",
                            r'<td style="background-color:#d1ffcc">Autorizado</td>',
                        )
                        .replace(
                            "<td>N</td>",
                            r'<td style="background-color:#dab5b5">Negado</td>',
                        )
                        .replace(r"<td>", r'<td style="background-color:#d8dba9">')
                    )
                    # print(listafinal)

                    file = open("app/templates/centrospermissoesexcel.html", "w")

                    file.writelines(listafinal)
                    file.close()

                    wb = load_workbook(
                        "app/static/Excels/Excel_Bases/Brose_Contas_Centros_Permissoes.xlsx",
                        data_only=True,
                    )
                    planilha = wb["Plantas Codigos"]  # Planta, Conta ou Centro Código

                    emails = []
                    for instance in db.session.query(User):
                        x = instance.email
                        emails.append(x)

                    registro_permissoes1 = {}
                    registro_permissoes2 = {}
                    registro_permissoes3 = {}
                    for email in emails:

                        for row in planilha.iter_rows():
                            for cell in row:
                                if cell.value == email:  # Email do Usuário
                                    # print(cell.column, cell.row)
                                    linha = str(cell.row)

                                    # print(cell.row)
                                    permissoes = []

                                    for valor2 in planilha[f"{linha[0]}"]:
                                        if (
                                            str(valor2.value) == str(email)
                                            or valor2.value == ""
                                            or valor2.value == "0"
                                            or valor2.value == "N"
                                            or valor2.value is None
                                        ):
                                            pass
                                        else:
                                            permissoes.append(str(valor2.value))
                                            # print(valor2.value)

                                    permissoes_final = [*set(permissoes)]

                                    # print(permissoes_final)
                                    registro_permissoes1[f"{email}"] = permissoes_final

                    planilha2 = wb["Contas Codigos"]  # Planta, Conta ou Centro Código

                    for email in emails:

                        for row in planilha2.iter_rows():
                            for cell in row:
                                if cell.value == email:  # Email do Usuário
                                    # print(cell.column, cell.row)
                                    linha = str(cell.row)

                                    # print(cell.row)
                                    permissoes = []

                                    for valor2 in planilha2[f"{linha[0]}"]:
                                        if (
                                            str(valor2.value) == str(email)
                                            or valor2.value == ""
                                            or valor2.value == "0"
                                            or valor2.value == "N"
                                            or valor2.value is None
                                        ):
                                            pass
                                        else:
                                            permissoes.append(str(valor2.value))
                                            # print(valor2.value)

                                    permissoes_final = [*set(permissoes)]

                                    # print(permissoes_final)
                                    registro_permissoes2[f"{email}"] = permissoes_final

                    planilha3 = wb["Centros Codigos"]  # Planta, Conta ou Centro Código

                    for email in emails:

                        for row in planilha3.iter_rows():
                            for cell in row:
                                if cell.value == email:  # Email do Usuário
                                    # print(cell.column, cell.row)
                                    linha = str(cell.row)

                                    # print(cell.row)
                                    permissoes = []

                                    for valor2 in planilha3[f"{linha[0]}"]:
                                        if (
                                            str(valor2.value) == str(email)
                                            or valor2.value == ""
                                            or valor2.value == "0"
                                            or valor2.value == "N"
                                            or valor2.value is None
                                        ):
                                            pass
                                        else:
                                            permissoes.append(str(valor2.value))
                                            # print(valor2.value)

                                    permissoes_final = [*set(permissoes)]

                                    # print(permissoes_final)
                                    registro_permissoes3[f"{email}"] = permissoes_final

                    with open(
                        "app/static/Permissoes/autorizacoesplantas.json", "w"
                    ) as data1:
                        json.dump(registro_permissoes1, data1)

                    with open(
                        "app/static/Permissoes/autorizacoesplantas.json", "r"
                    ) as data2:
                        autplanta = json.load(data2)

                    with open(
                        "app/static/Permissoes/autorizacoescontas.json", "w"
                    ) as data3:
                        json.dump(registro_permissoes2, data3)

                    with open(
                        "app/static/Permissoes/autorizacoescontas.json", "r"
                    ) as data4:
                        autconta = json.load(data4)

                    with open(
                        "app/static/Permissoes/autorizacoescentros.json", "w"
                    ) as data5:
                        json.dump(registro_permissoes3, data5)

                    with open(
                        "app/static/Permissoes/autorizacoescentros.json", "r"
                    ) as data6:
                        autcentro = json.load(data6)

                    # print(autplanta)
                    # print(autconta)
                    # print(autcentro)

                    from datetime import datetime

                    mes1 = datetime.now().month
                    if mes1 == 1:
                        mes = "Janeiro"

                    elif mes1 == 2:
                        mes = "Fevereiro"

                    elif mes1 == 3:
                        mes = "Marco"

                    elif mes1 == 4:
                        mes = "Abril"

                    elif mes1 == 5:
                        mes = "Maio"

                    elif mes1 == 6:
                        mes = "Junho"

                    elif mes1 == 7:
                        mes = "Julho"

                    elif mes1 == 8:
                        mes = "Agosto"

                    elif mes1 == 9:
                        mes = "Setembro"

                    elif mes1 == 10:
                        mes = "Outubro"

                    elif mes1 == 11:
                        mes = "Novembro"

                    elif mes1 == 12:
                        mes = "Dezembro"

                    emailsss = []
                    for instance in db.session.query(User):
                        x = instance.email
                        emailsss.append(x)
                    # print(emails)

                    for email in emailsss:

                        with open(
                                "app/static/Permissoes/autorizacoesplantas.json", "r"
                        ) as data2:
                            autplanta = json.load(data2)

                        with open(
                                "app/static/Permissoes/autorizacoescontas.json", "r"
                        ) as data4:
                            autconta = json.load(data4)

                        with open(
                                "app/static/Permissoes/autorizacoescentros.json", "r"
                        ) as data6:
                            autcentro = json.load(data6)

                        pplantas = autplanta[f"{email}"]

                        pcontas = autconta[f"{email}"]

                        pcentro = autcentro[f"{email}"]

                        # print(pplantas,pcontas,pcentro)

                        wb11 = load_workbook(
                            r"app/static/Excels/Excel_Bases/Base_Provisoes.xlsx",
                            data_only=True,
                        )

                        planilhaCC = wb11["Extrato Ano"]

                        for cell in planilhaCC["C"][1:]:
                            # print(cell.value)
                            if str(cell.value) not in str(pcentro):
                                planilhaCC.delete_rows(cell.row)

                        for cell in planilhaCC["D"][1:]:
                            # print(cell.value)
                            if str(cell.value) not in str(pcontas):
                                planilhaCC.delete_rows(cell.row)

                        for cell in planilhaCC["J"][1:]:
                            # print(cell.value)
                            if str(cell.value) not in str(pplantas):
                                planilhaCC.delete_rows(cell.row)

                        planilhaMM = wb11["Mes Atual"]

                        for cell3 in planilhaMM["E"][1:]:
                            # print(cell.value)
                            if str(cell3.value) not in str(pcontas):
                                planilhaMM.delete_rows(cell3.row)

                        for cell3 in planilhaMM['D'][1:]:
                             # print(cell.value)
                             if str(cell3.value) not in str(pcentro):
                                 planilhaMM.delete_rows(cell3.row)

                        planilhaMMT = wb11["Resumo Mes Atual"]

                        pivot = planilhaMMT._pivots[0]
                        pivot.cache.refreshOnLoad = True

                        usuario = db.session.query(User).filter_by(email=email).first()

                        wb11.save(
                            f"app/static/Excels/Excel_Usuarios/Provisoes_id_{str(usuario.id)}_{mes}.xlsx"
                        )

                    flash("Novas Permissões de Acesso Cadastradas Com Sucesso")

        except:
            pass

    return render_template("centerspermission.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        pwd = request.form["password"]

        # print(email)
        # print(pwd)

        user = User.query.filter_by(email=email).first()

        botao = request.form["botao"]

        if botao == "Logar":
            if email == "":
                flash("Email em Branco")
            elif pwd == "":
                flash("Senha em Branco")
            else:
                if not user or not user.verify_password(pwd):
                    flash("Dados Incorretos")
                    return redirect(url_for("login"))

                login_user(user, remember=True)
                # print(user.id)
                if user.id == 1 or user.id == 2 or user.id == 3:
                    return redirect(url_for("basetablesupdate"))
                else:
                    return redirect(url_for("home"))
        if botao == "Voltar":
            # print(flash.__annotations__.popitem())
            return redirect("/")
        else:
            pass

    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form["name"]
        email = request.form["email"]
        pwd = request.form["password"]
        admpwd = request.form["admpassword"]
        botao = request.form["botao"]

        emails = []
        for instance in db.session.query(User):
            x = instance.email
            emails.append(x)

        if botao == "Cadastrar":

            if name == "":
                flash("Nome em Branco")
            elif email == "":
                flash("Email em Branco")
            elif pwd == "":
                flash("Senha em Branco")
            elif admpwd == "":
                flash("Senha Administrativa em Branco")
            elif email in emails:
                flash("Email Já Cadastrado")
            else:

                if admpwd == senha:

                    user = User(name, email, pwd)
                    db.session.add(user)
                    db.session.commit()

                    names = []
                    for instance in db.session.query(User):
                        x = instance.name
                        names.append(x)

                    emails = []
                    for instance in db.session.query(User):
                        x = instance.email
                        emails.append(x)

                    passwords = []
                    for instance in db.session.query(User):
                        x = instance.password
                        passwords.append(x)

                    wb2 = load_workbook(
                        r"app/static/Excels/Excel_Registros/Brose_Registros_Usuarios.xlsx"
                    )
                    planilha = wb2["Usuarios"]

                    n = 2
                    for name, email, password in zip(names, emails, passwords):
                        if name != "":
                            planilha[f"A{n}"] = str(name)
                            planilha[f"B{n}"] = str(email)
                            planilha[f"C{n}"] = str(password)
                            n = n + 1
                        else:
                            pass

                    wb2.save(
                        "app/static/Excels/Excel_Registros/Brose_Registros_Usuarios.xlsx"
                    )

                    wb4 = load_workbook(
                        r"app/static/Excels/Excel_Registros/Brose_Registros_Usuarios.xlsx"
                    )
                    planilha = wb4["Usuarios"]

                    primeira_coluna = planilha["A"]
                    segunda_coluna = planilha["B"]
                    terceira_coluna = planilha["C"]

                    valores1 = []
                    valores2 = []
                    valores3 = []

                    for coluna1 in primeira_coluna:
                        if coluna1.value != "Nome" or coluna1.value != "None":
                            valores1.append(
                                f'<tr class="text-center" style="display: table-row;"><td>{coluna1.value}</td>'
                            )
                        else:
                            pass
                    for coluna2 in segunda_coluna:
                        if coluna2.value != "Email" or coluna1.value != "None":
                            valores2.append(f"<td>{coluna2.value}</td>")
                        else:
                            pass
                    for coluna3 in terceira_coluna:
                        if coluna3.value != "Senha" or coluna1.value != "None":
                            valores3.append(f"<td>{coluna3.value}</td></tr>")
                        else:
                            pass

                    lista1 = []
                    for (a, b, c) in zip(valores1, valores2, valores3):
                        x = f"{a},{b},{c}"
                        lista1.append(x)

                    listamodificada = "".join(lista1)
                    listafinal = (
                        listamodificada.replace(",<td>", "<td>")
                        .replace("None", "")
                        .replace(
                            r'"><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr><tr style="display: table-row;"><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr><tr style="display: table-row;',
                            "",
                        )
                        .replace(
                            r"<td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr>",
                            "",
                        )
                        .replace(
                            r'<tr class="text-center" style="display: table-row;"><td>-</td>',
                            "",
                        )
                        .replace(
                            r'<tr class="text-center" style="display: table-row;"><td></td></tr>',
                            "",
                        )
                        .replace(
                            r'<tr class="text-center" style="display: table-row;"><td></td><td></td><td></td></tr>',
                            "",
                        )
                        .replace(
                            r'<tr class="text-center" style="display: table-row;"><td>Nome</td><td>Email</td><td>Senha</td></tr>',
                            "",
                        )
                    )

                    # print(listafinal)

                    file = open("app/templates/usuariosexcel.html", "w")

                    file.writelines(listafinal)
                    file.close()

                    emails = []
                    for instance in db.session.query(User):
                        x = instance.email
                        emails.append(x)

                    wb = load_workbook(
                        "app/static/Excels/Excel_Bases/Brose_Contas_Centros_Permissoes.xlsx"
                    )
                    planilha = wb[
                        "Permissoes Plantas"
                    ]  # Planta, Conta ou Centro Código

                    nuc = 2

                    for email in emails:
                        if email != "":
                            planilha[f"A{nuc}"] = str(email)
                            nuc = nuc + 1
                        else:
                            pass

                    planilha2 = wb[
                        "Permissoes Contas"
                    ]  # Planta, Conta ou Centro Código

                    nucc = 2

                    for email in emails:
                        if email != "":
                            planilha2[f"A{nucc}"] = str(email)
                            nucc = nucc + 1
                        else:
                            pass

                    planilha3 = wb[
                        "Permissoes Centros"
                    ]  # Planta, Conta ou Centro Código

                    nuccc = 2

                    for email in emails:
                        if email != "":
                            planilha3[f"A{nuccc}"] = str(email)
                            nuccc = nuccc + 1
                        else:
                            pass

                    wb.save(
                        "app/static/Excels/Excel_Bases/Brose_Contas_Centros_Permissoes.xlsx"
                    )

                    flash(f"Usuário Cadastrado Com Sucesso")

                    return redirect(url_for("login"))
                else:
                    flash("Senha Incorreta")
                    return redirect(url_for("register"))

        if botao == "Voltar":
            return redirect("/")

    return render_template("register.html")


@app.route("/recover", methods=["GET", "POST"])
def recover():
    if request.method == "POST":
        name = request.form["name"]
        email = request.form["email"]
        pwd = request.form["password"]
        botao = request.form["botao"]

        emails = []
        for instance in db.session.query(User):
            x = instance.email
            emails.append(x)

        if botao == "Cadastrar":

            if email not in emails:
                flash("Email Não Cadastrado")
            elif name == "":
                flash("Nome em Branco")
            elif email == "":
                flash("Email em Branco")
            elif pwd == "":
                flash("Senha em Branco")

            else:

                from werkzeug.security import generate_password_hash

                novasenha = generate_password_hash(pwd)

                wb = load_workbook(
                    r"app/static/Excels/Excel_Modelos/Brose_Cadastro_Usuarios.xlsx"
                )
                planilha = wb["Usuarios"]

                planilha["A2"] = name
                planilha["B2"] = email
                planilha["C2"] = novasenha

                wb.save(
                    r"app/static/Excels/Excel_Recuperar_Contas/Brose_Cadastro_Usuarios.xlsx"
                )

                # Abre o arquivo "Brose_Configuracoes.xlsx"
                wb = load_workbook('app/static/Excels/Excel_Bases/Brose_Configuracoes.xlsx')

                # Seleciona a planilha "Configs"
                sheet = wb['Configs']

                # Atribui o valor da célula B2 à variável respfin
                respfin = sheet['B2'].value

                # Atribui o valor da célula B3 à variável respsup
                respsup = sheet['B3'].value

                # Fecha o arquivo
                wb.close()

                # Imprime os valores das variáveis respfin e respsup
                print(respfin)
                print(respsup)
                
                fromaddr = "cadastroredefinicaousuarioprovisoes"
                toaddr =  'vitor.kavinski.temp@brose.com' #pedro.cotta@brose.com
                msg = MIMEMultipart()

                msg["From"] = fromaddr
                msg["To"] = toaddr
                msg["Subject"] = f"Provisões Brose - Solicitação de Recuperação de Senha"
                body = f"Prezado Administrador,\n\nO usuário ({name}), que possuí o email ({email}) cadastrado, deseja recupera a senha e substituí-la pela senha criptografada abaixo. Segue em anexo, arquivo xlsx pronto para o envio no menu Usuários, que redefinirá a senha para a solicitada caso seja enviada.\n\nSenha Criptografada: ({novasenha})\n\nAtenciosamente,\n\nEquipe Automatizada Brose Provisões Brasil"
                msg.attach(MIMEText(body, "plain"))
                filename = "Brose_Cadastro_Usuarios.xlsx"
                attachment = open(f"app/static/Excels/Excel_Recuperar_Contas/Brose_Cadastro_Usuarios.xlsx","rb",)
                p = MIMEBase("application", "octet-stream")
                p.set_payload((attachment).read())
                encoders.encode_base64(p)
                p.add_header("Content-Disposition", "attachment; filename= %s" % filename)
                msg.attach(p)

                text = msg.as_string()
                
                # smtp1 = smtplib.SMTP("127.0.0.1")
                # smtp1.sendmail(fromaddr, toaddr, text)
                # smtp1.quit()

                with smtplib.SMTP("127.0.0.1") as smtp1:
                    smtp1.sendmail(fromaddr, toaddr, text)

                flash("Solicitação Enviada. Em Breve Retornaremos!")
                return redirect(url_for("recover"))

        if botao == "Voltar":
            return redirect("/")

    return render_template("recover.html")


@app.route("/logout")
def logout():
    logout_user()
    return redirect(url_for("home"))


@app.route("/viewaccounts", methods=["GET", "POST"])
def viewaccounts():

    if request.method == "POST":

        try:
            uploaded_file = request.files["abase"]
            filename = uploaded_file.filename

            if filename == "" and request.files["abase"] != "":
                flash("Selecione Um Arquivo")
            elif filename != "" and request.files["abase"] != "":
                file_ext = os.path.splitext(filename)[1]
                if file_ext not in app.config["UPLOAD_EXTENSIONS"]:
                    flash("Envie um Arquivo Excel com a Extensão XLSX")

                elif filename == "Base_Provisoes.xlsx":
                    uploaded_file.save(
                        os.path.join(
                            os.path.join(
                                app.config["UPLOAD_FOLDER"],
                                secure_filename(uploaded_file.filename),
                            )
                        )
                    )  # Centros
                    wb = load_workbook(
                        "app/static/Excels/Excel_Bases/Brose_Contas_Centros_Permissoes.xlsx",
                        data_only=True,
                    )
                    planilha = wb["Plantas Codigos"]  # Planta, Conta ou Centro Código

                    emails = []
                    for instance in db.session.query(User):
                        x = instance.email
                        emails.append(x)

                    registro_permissoes1 = {}
                    registro_permissoes2 = {}
                    registro_permissoes3 = {}
                    for email in emails:

                        for row in planilha.iter_rows():
                            for cell in row:
                                if cell.value == email:  # Email do Usuário
                                    # print(cell.column, cell.row)
                                    linha = str(cell.row)

                                    # print(cell.row)
                                    permissoes = []

                                    for valor2 in planilha[f"{linha[0]}"]:
                                        if (
                                            str(valor2.value) == str(email)
                                            or valor2.value == ""
                                            or valor2.value == "0"
                                            or valor2.value == "N"
                                            or valor2.value is None
                                        ):
                                            pass
                                        else:
                                            permissoes.append(str(valor2.value))
                                            # print(valor2.value)

                                    permissoes_final = [*set(permissoes)]

                                    # print(permissoes_final)
                                    registro_permissoes1[f"{email}"] = permissoes_final

                    planilha2 = wb["Contas Codigos"]  # Planta, Conta ou Centro Código

                    for email in emails:

                        for row in planilha2.iter_rows():
                            for cell in row:
                                if cell.value == email:  # Email do Usuário
                                    # print(cell.column, cell.row)
                                    linha = str(cell.row)

                                    # print(cell.row)
                                    permissoes = []

                                    for valor2 in planilha2[f"{linha[0]}"]:
                                        if (
                                            str(valor2.value) == str(email)
                                            or valor2.value == ""
                                            or valor2.value == "0"
                                            or valor2.value == "N"
                                            or valor2.value is None
                                        ):
                                            pass
                                        else:
                                            permissoes.append(str(valor2.value))
                                            # print(valor2.value)

                                    permissoes_final = [*set(permissoes)]

                                    # print(permissoes_final)
                                    registro_permissoes2[f"{email}"] = permissoes_final

                    planilha3 = wb["Centros Codigos"]  # Planta, Conta ou Centro Código

                    for email in emails:

                        for row in planilha3.iter_rows():
                            for cell in row:
                                if cell.value == email:  # Email do Usuário
                                    # print(cell.column, cell.row)
                                    linha = str(cell.row)

                                    # print(cell.row)
                                    permissoes = []

                                    for valor2 in planilha3[f"{linha[0]}"]:
                                        if (
                                            str(valor2.value) == str(email)
                                            or valor2.value == ""
                                            or valor2.value == "0"
                                            or valor2.value == "N"
                                            or valor2.value is None
                                        ):
                                            pass
                                        else:
                                            permissoes.append(str(valor2.value))
                                            # print(valor2.value)

                                    permissoes_final = [*set(permissoes)]

                                    # print(permissoes_final)
                                    registro_permissoes3[f"{email}"] = permissoes_final

                    with open(
                        "app/static/Permissoes/autorizacoesplantas.json", "w"
                    ) as data1:
                        json.dump(registro_permissoes1, data1)

                    with open(
                        "app/static/Permissoes/autorizacoesplantas.json", "r"
                    ) as data2:
                        autplanta = json.load(data2)

                    with open(
                        "app/static/Permissoes/autorizacoescontas.json", "w"
                    ) as data3:
                        json.dump(registro_permissoes2, data3)

                    with open(
                        "app/static/Permissoes/autorizacoescontas.json", "r"
                    ) as data4:
                        autconta = json.load(data4)

                    with open(
                        "app/static/Permissoes/autorizacoescentros.json", "w"
                    ) as data5:
                        json.dump(registro_permissoes3, data5)

                    with open(
                        "app/static/Permissoes/autorizacoescentros.json", "r"
                    ) as data6:
                        autcentro = json.load(data6)

                    # print(autplanta)
                    # print(autconta)
                    # print(autcentro)

                    from datetime import datetime

                    mes1 = datetime.now().month
                    if mes1 == 1:
                        mes = "Janeiro"

                    elif mes1 == 2:
                        mes = "Fevereiro"

                    elif mes1 == 3:
                        mes = "Marco"

                    elif mes1 == 4:
                        mes = "Abril"

                    elif mes1 == 5:
                        mes = "Maio"

                    elif mes1 == 6:
                        mes = "Junho"

                    elif mes1 == 7:
                        mes = "Julho"

                    elif mes1 == 8:
                        mes = "Agosto"

                    elif mes1 == 9:
                        mes = "Setembro"

                    elif mes1 == 10:
                        mes = "Outubro"

                    elif mes1 == 11:
                        mes = "Novembro"

                    elif mes1 == 12:
                        mes = "Dezembro"

                    emailsss = []
                    for instance in db.session.query(User):
                        x = instance.email
                        emailsss.append(x)
                    # print(emails)

                    for email in emailsss:

                        with open(
                                "app/static/Permissoes/autorizacoesplantas.json", "r"
                        ) as data2:
                            autplanta = json.load(data2)

                        with open(
                                "app/static/Permissoes/autorizacoescontas.json", "r"
                        ) as data4:
                            autconta = json.load(data4)

                        with open(
                                "app/static/Permissoes/autorizacoescentros.json", "r"
                        ) as data6:
                            autcentro = json.load(data6)

                        pplantas = autplanta[f"{email}"]

                        pcontas = autconta[f"{email}"]

                        pcentro = autcentro[f"{email}"]

                        # print(pplantas,pcontas,pcentro)

                        wb11 = load_workbook(
                            r"app/static/Excels/Excel_Bases/Base_Provisoes.xlsx",
                            data_only=True,
                        )

                        planilhaCC = wb11["Extrato Ano"]

                        for cell in planilhaCC["C"][1:]:
                            # print(cell.value)
                            if str(cell.value) not in str(pcentro):
                                planilhaCC.delete_rows(cell.row)

                        for cell in planilhaCC["D"][1:]:
                            # print(cell.value)
                            if str(cell.value) not in str(pcontas):
                                planilhaCC.delete_rows(cell.row)

                        for cell in planilhaCC["J"][1:]:
                            # print(cell.value)
                            if str(cell.value) not in str(pplantas):
                                planilhaCC.delete_rows(cell.row)

                        planilhaMM = wb11["Mes Atual"]

                        for cell3 in planilhaMM["E"][1:]:
                            # print(cell.value)
                            if str(cell3.value) not in str(pcontas):
                                planilhaMM.delete_rows(cell3.row)

                        for cell3 in planilhaMM['D'][1:]:
                             # print(cell.value)
                             if str(cell3.value) not in str(pcentro):
                                 planilhaMM.delete_rows(cell3.row)

                        planilhaMMT = wb11["Resumo Mes Atual"]

                        pivot = planilhaMMT._pivots[0]
                        pivot.cache.refreshOnLoad = True

                        usuario = db.session.query(User).filter_by(email=email).first()

                        wb11.save(
                            f"app/static/Excels/Excel_Usuarios/Provisoes_id_{str(usuario.id)}_{mes}.xlsx"
                        )

                    flash(f"Base de Contas Atualizada")

                else:
                    flash(
                        "Formate o Excel com o nome Base_Provisoes.xlsx ou Resumo_Contas.xlsx"
                    )

        except:
            pass

    if request.method == "POST":
        try:
            botaoLR = request.form["botaoL"]

            if botaoLR == "HVoltar":
                return redirect(url_for("home"))
            elif botaoLR == "HVerProv":
                return redirect(url_for("viewaccounts"))
            elif botaoLR == "HVerProviso":
                return redirect(url_for("viewprovisions"))
            elif botaoLR == "HEditarProv":
                return redirect(url_for("editprovisions"))
            elif botaoLR == "HCriarProv":
                return redirect(url_for("createprovissions"))
            elif botaoLR == "HPermissoes":
                return redirect(url_for("seeprovisions"))
            elif botaoLR == "HDesconectar":
                return redirect(url_for("logout"))

            try:
                if botaoLR == "HPainel":
                    return redirect(url_for("basetablesupdate"))
            except:
                pass

            else:
                pass
        except:
            pass

    try:
        xx = str(current_user.id)
    except AttributeError:
        xx = 0

    return render_template("viewaccounts.html", usuario=xx)


@app.route("/viewprovisions", methods=["GET", "POST"])
def viewprovisions():

    if request.method == "POST":
        try:

            uploaded_file = request.files["abase"]
            filename = uploaded_file.filename

            if filename == "" and request.files["abase"] != "":
                flash("Selecione Um Arquivo")
            elif filename != "" and request.files["abase"] != "":
                file_ext = os.path.splitext(filename)[1]
                if (
                    file_ext not in app.config["UPLOAD_EXTENSIONS"]
                    or filename != "Provisoes.xlsx"
                ):
                    flash("Formate o Excel com o nome Provisoes.xlsx")
                else:
                    uploaded_file.save(
                        os.path.join(
                            os.path.join(
                                app.config["UPLOAD_FOLDER"],
                                secure_filename(uploaded_file.filename),
                            )
                        )
                    )  # Centros

                    emailsss = []
                    for instance in db.session.query(User):
                        x = instance.email
                        emailsss.append(x)
                    print(emailsss)
                    

                    for email in emailsss:
                        
                        wb = load_workbook(
                            r"app/static/Excels/Excel_Bases/Provisoes.xlsx",
                            data_only=True,
                        )
                        planilha = wb["Provisoes"]

                        user = usuario = db.session.query(User).filter_by(email=email).first()
                        nome = user.name
                        print(nome)

                        
                        try:
                            x, y = nome.split("_")
                        except:
                            x, y = nome, ""
                        
                        for cell in planilha["G"][1:]:
                            if str(cell.value) != nome and str(cell.value) != y and str(cell.value) != x and str(cell.value) != "":
                                planilha.delete_rows(cell.row, 1)
                        
                        usuario = db.session.query(User).filter_by(email=email).first()
                        print(usuario)

                        wb.save(f"app/static/Excels/Excel_Provisoes_Usuarios/Provisoes_User_id_{str(usuario.id)}.xlsx")

                    ids = []
                    for instance in db.session.query(User):
                        x = instance.id
                        ids.append(x)
                        # print(x)
                    # print(id)

                    for ide in ids:

                        if (
                            ide == 1
                            or ide == 2
                            or ide == 3
                            or ide == "1"
                            or ide == "2"
                            or ide == "3"
                        ):
                            con = sqlite3.connect(
                                f"app/Data_Bases_Usuarios/Provisoes_Editaveis_Usuario_{ide}.db"
                            )
                            df = pd.read_excel(
                                f"app/static/Excels/Excel_Bases/Provisoes.xlsx",
                                sheet_name="Provisoes",
                            )
                            df.to_sql(
                                f"Provisoes_Editaveis_Usuario_{ide}",
                                con,
                                index=False,
                                if_exists="replace",
                            )
                            con.commit()
                            con.close()
                        else:
                            con = sqlite3.connect(
                                f"app/Data_Bases_Usuarios/Provisoes_Editaveis_Usuario_{ide}.db"
                            )
                            df = pd.read_excel(
                                f"app/static/Excels/Excel_Provisoes_Usuarios/Provisoes_User_id_{ide}.xlsx",
                                sheet_name="Provisoes",
                            )
                            df.to_sql(
                                f"Provisoes_Editaveis_Usuario_{ide}",
                                con,
                                index=False,
                                if_exists="replace",
                            )
                            con.commit()
                            con.close()

                    #
                    #
                    #
                    #######

                    path = "app/static/Excels"

                    source = "Excel_Modelos/Brose_Modificacoes_Gerais.xlsx"
                    destination = (
                        "Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx"
                    )

                    sourcePath = path + "/" + source
                    destinationPath = path + "/" + destination

                    if os.path.isdir(destinationPath + "/" + source):
                        print(source, "exists in the destination path!")
                        shutil.rmtree(destinationPath + "/" + source)

                    elif os.path.isfile(destinationPath + "/" + source):
                        os.remove(destinationPath + "/" + source)
                        print(source, "deleted in", destination)

                    dest = shutil.copyfile(sourcePath, destinationPath)

                    #

                    wb = load_workbook(
                        r"app/static/Excels/Excel_Bases/Provisoes.xlsx", data_only=True
                    )
                    planilha = wb["Provisoes"]

                    x1 = str(planilha["A1"].value)

                    x2 = str(planilha["B1"].value)

                    x3 = str(planilha["C1"].value)

                    x4 = str(planilha["D1"].value)

                    x5 = str(planilha["E1"].value)

                    x6 = str(planilha["F1"].value)

                    x7 = str(planilha["G1"].value)

                    x8 = str(planilha["H1"].value)

                    x9 = str(planilha["I1"].value)

                    x10 = str(planilha["J1"].value)

                    wb.close()

                    my_file = Path(
                        f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx"
                    )
                    if my_file.is_file():
                        pass
                    else:
                        shutil.copyfile(
                            "app/static/Excels/Excel_Modelos/Brose_Modificacoes_Gerais.xlsx",
                            f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx",
                        )

                    wb2 = load_workbook(
                        f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx",
                        data_only=True,
                    )
                    planilha2 = wb2["Modificacoes"]

                    print(planilha2["N2"].value)
                    print(x1)
                    planilha2["D2"].value = x1
                    planilha2["E2"].value = x2
                    planilha2["F2"].value = x3
                    planilha2["G2"].value = x4
                    planilha2["H2"].value = x5
                    planilha2["I2"].value = x6
                    planilha2["J2"].value = x7
                    planilha2["K2"].value = x8
                    planilha2["L2"].value = x9
                    planilha2["M2"].value = x10

                    wb2.save(
                        "app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx"
                    )
                    wb2.close()

                    #
                    #
                    #
                    #######

                    flash(f"Provisões Atualizadas")

        except Exception as e:
            print(e)

    if request.method == "POST":
        try:
            botaoLR = request.form["botaoL"]

            if botaoLR == "HVoltar":
                return redirect(url_for("home"))
            elif botaoLR == "HVerProv":
                return redirect(url_for("viewaccounts"))
            elif botaoLR == "HVerProviso":
                return redirect(url_for("viewprovisions"))
            elif botaoLR == "HEditarProv":
                return redirect(url_for("editprovisions"))
            elif botaoLR == "HCriarProv":
                return redirect(url_for("createprovissions"))
            elif botaoLR == "HPermissoes":
                return redirect(url_for("seeprovisions"))
            elif botaoLR == "HDesconectar":
                return redirect(url_for("logout"))

            try:
                if botaoLR == "HPainel":
                    return redirect(url_for("basetablesupdate"))
            except:
                pass

            else:
                pass
        except:
            pass

    try:
        x = str(current_user.id)
    except AttributeError:
        x = 0

    try:
        inspector = inspect(db.engine)
        if (
            inspector.has_table(f"Provisoes_Editaveis_Usuario_{str(current_user.id)}")
            == True
        ):
            con = sqlite3.connect(
                f"app/Data_Bases_Usuarios/Provisoes_Editaveis_Usuario_{str(current_user.id)}.db"
            )
            wb = pd.ExcelFile(
                f"app/static/Excels/Excel_Provisoes_Usuarios/Provisoes_User_id_{str(current_user.id)}.xlsx"
            )
            df = pd.read_excel(
                f"app/static/Excels/Excel_Provisoes_Usuarios/Provisoes_User_id_{str(current_user.id)}.xlsx",
                sheet_name="Provisoes",
            )
            df.to_sql(
                f"Provisoes_Editaveis_Usuario_{str(current_user.id)}",
                con,
                index=False,
                if_exists="replace",
            )
            con.commit()
            con.close()
        else:
            pass

    except:
        pass

    from app.models import create_models

    x = str(current_user.id)
    PlanilhaUsuario = create_models(x, x)

    try:
        from app.models import create_models

        x = str(current_user.id)
        PlanilhaUsuario = create_models(x, x)
        from app.models import PlanilhaUsuario

        yw = PlanilhaUsuario.query.all()
        # print(PlanilhaUsuario.query.all())
        # ids = []
        # for instance in db.session.query(PlanilhaUsuario):
        #     x = instance.V1
        #     ids.append(x)
        # print(f'IDS = {ids}')
    except Exception as e:
        print(e)

    xx = str(current_user.id)

    try:
        wb = load_workbook(
            r"app/static/Excels/Excel_Bases/Provisoes.xlsx", data_only=True
        )
        planilha = wb["Provisoes"]

        primeira_linha = planilha["1"]

        titulos = []
        for valor in primeira_linha:
            if valor.value == "" or valor.value == "Null" or valor.value is None:
                pass
            else:
                titulos.append(valor.value)
    except:
        pass

    try:
        return render_template(
            "viewprovisions.html", PlanilhaUsuario=yw, titulos=titulos, usuario=xx
        )
    except Exception as e:
        print (e)
        return render_template(
            "viewprovisions.html", PlanilhaUsuario="", titulos=titulos, usuario=xx
        )

@app.route('/quit')
def _quit():
    try:
        if str(current_user.id) == "1":
            os._exit(0)
        else:
            return render_template("notallowed.html")

    except:
        return render_template("notallowed.html")


@app.route("/editprovisions", methods=["GET", "POST"])
def editprovisions():
    try:
        inspector = inspect(db.engine)
        if (
            inspector.has_table(f"Provisoes_Editaveis_Usuario_{str(current_user.id)}")
            == True
        ):
            con = sqlite3.connect(
                f"app/Data_Bases_Usuarios/Provisoes_Editaveis_Usuario_{str(current_user.id)}.db"
            )
            wb = pd.ExcelFile(
                f"app/static/Excels/Excel_Provisoes_Usuarios/Provisoes_User_id_{str(current_user.id)}.xlsx"
            )
            df = pd.read_excel(
                f"app/static/Excels/Excel_Provisoes_Usuarios/Provisoes_User_id_{str(current_user.id)}.xlsx",
                sheet_name="Provisoes",
            )
            df.to_sql(
                f"Provisoes_Editaveis_Usuario_{str(current_user.id)}",
                con,
                index=False,
                if_exists="replace",
            )
            con.commit()
            con.close()
        else:
            pass

    except:
        pass

    if request.method == "POST":
        try:
            botaoLR = request.form["botaoL"]

            if botaoLR == "HVoltar":
                return redirect(url_for("home"))
            elif botaoLR == "HVerProv":
                return redirect(url_for("viewaccounts"))
            elif botaoLR == "HVerProviso":
                return redirect(url_for("viewprovisions"))
            elif botaoLR == "HEditarProv":
                return redirect(url_for("editprovisions"))
            elif botaoLR == "HCriarProv":
                return redirect(url_for("createprovissions"))
            elif botaoLR == "HPermissoes":
                return redirect(url_for("seeprovisions"))
            elif botaoLR == "HDesconectar":
                return redirect(url_for("logout"))

            try:
                if botaoLR == "HPainel":
                    return redirect(url_for("basetablesupdate"))
            except:
                pass

            else:
                pass
        except:
            pass

    if request.method == "POST":
        try:
            botaoR = request.form["botaoR"]

            if botaoR == "BRest":

                try:
                    con = sqlite3.connect(
                        f"app/Data_Bases_Usuarios/Provisoes_Editaveis_Usuario_{str(current_user.id)}.db"
                    )
                    wb = pd.ExcelFile(
                        f"app/static/Excels/Excel_Provisoes_Usuarios/Provisoes_User_id_{str(current_user.id)}.xlsx"
                    )
                    df = pd.read_excel(
                        f"app/static/Excels/Excel_Provisoes_Usuarios/Provisoes_User_id_{str(current_user.id)}.xlsx",
                        sheet_name="Provisoes",
                    )
                    df.to_sql(
                        f"Provisoes_Editaveis_Usuario_{str(current_user.id)}",
                        con,
                        index=False,
                        if_exists="replace",
                    )
                    con.commit()
                    con.close()
                except:
                    pass

                flash("Valores Restaurados")
                return redirect(url_for("editprovisions"))

            try:
                if botaoLR == "HPainel":
                    return redirect(url_for("basetablesupdate"))
            except:
                pass

            else:
                pass
        except:
            pass

    from app.models import create_models

    x = str(current_user.id)
    PlanilhaUsuario = create_models(x, x)

    try:
        from app.models import create_models

        x = str(current_user.id)
        PlanilhaUsuario = create_models(x, x)
        from app.models import PlanilhaUsuario

        yw = PlanilhaUsuario.query.all()
        # print(PlanilhaUsuario.query.all())
        # ids = []
        # for instance in db.session.query(PlanilhaUsuario):
        #     x = instance.V1
        #     ids.append(x)
        # print(f'IDS = {ids}')
    except Exception as e:
        print(e)

    try:
        wb = load_workbook(
            r"app/static/Excels/Excel_Bases/Provisoes.xlsx", data_only=True
        )
        planilha = wb["Provisoes"]

        primeira_linha = planilha["1"]

        titulos = []
        for valor in primeira_linha:
            if valor.value == "" or valor.value == "Null" or valor.value is None:
                pass
            else:
                titulos.append(valor.value)

    except:
        pass

    xx = str(current_user.id)
    try:
        return render_template(
            "editprovisions.html", PlanilhaUsuario=yw, titulos=titulos, usuario=xx
        )
    except:
        return render_template(
            "editprovisions.html", PlanilhaUsuario="", titulos=titulos, usuario=xx
        )


@app.route("/deletarlinhausuarioeditar/<int:valor>")
def deletarlinhausuarioeditar(valor):

    wb22 = load_workbook(
        f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx",
        data_only=True,
    )
    planilha2 = wb22["Modificacoes"]

    colunaD = planilha2["D"]
    valoresdacolunaD = []
    for vcelula in colunaD:
        if vcelula.value == "" or vcelula.value == "Null" or vcelula.value is None:
            pass
        else:
            valoresdacolunaD.append(vcelula.value)
    if str(valor) in valoresdacolunaD:
        flash(
            "Id Já Editado, para Editá-lo Novamente Delete a Modificação Referente a esse Id na Sessão de Status"
        )
        return redirect(url_for("editprovisions"))
    else:
        pass

    try:
        from app.models import PlanilhaUsuario

        dados_usuarios = db.session.query(PlanilhaUsuario).filter_by(V1=valor).first()
        # print(PlanilhaUsuario.query.all())
        # ids = []
        # for instance in db.session.query(PlanilhaUsuario):
        #     x = instance.V1
        #     ids.append(x)
        # print(f'IDS = {ids}')
    except:
        print("Erro")
    print(valor)

    #

    wb = load_workbook(r"app/static/Excels/Excel_Bases/Provisoes.xlsx", data_only=True)
    planilha = wb["Provisoes"]

    x1 = str(planilha["A1"].value)

    x2 = str(planilha["B1"].value)

    x3 = str(planilha["C1"].value)

    x4 = str(planilha["D1"].value)

    x5 = str(planilha["E1"].value)

    x6 = str(planilha["F1"].value)

    x7 = str(planilha["G1"].value)

    x8 = str(planilha["H1"].value)

    x9 = str(planilha["I1"].value)

    x10 = str(planilha["J1"].value)

    wb.close()

    my_file = Path(
        f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx"
    )
    if my_file.is_file():
        pass
    else:
        shutil.copyfile(
            "app/static/Excels/Excel_Modelos/Brose_Modificacoes_Gerais.xlsx",
            f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx",
        )

    wb2 = load_workbook(
        f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx",
        data_only=True,
    )
    planilha2 = wb2["Modificacoes"]

    print(planilha2["N2"].value)
    print(x1)
    planilha2["D2"].value = x1
    planilha2["E2"].value = x2
    planilha2["F2"].value = x3
    planilha2["G2"].value = x4
    planilha2["H2"].value = x5
    planilha2["I2"].value = x6
    planilha2["J2"].value = x7
    planilha2["K2"].value = x8
    planilha2["L2"].value = x9
    planilha2["M2"].value = x10

    #

    last_empty_row1 = len(list(planilha2.rows))

    ultima_linha_ativa1 = planilha2[f"A{last_empty_row1}"].value
    print(last_empty_row1)
    print(ultima_linha_ativa1)

    planilha2[f"A{last_empty_row1 + 1}"].value = "Valores Atuais"
    planilha2[f"A{last_empty_row1 + 2}"].value = "Mudanças Desejadas"

    planilha2[f"B{last_empty_row1 + 1}"].value = "Baixar"
    planilha2[f"B{last_empty_row1 + 2}"].value = "Baixar"

    planilha2[f"C{last_empty_row1 + 1}"].value = str(current_user.email)
    planilha2[f"C{last_empty_row1 + 2}"].value = str(current_user.email)

    planilha2[f"D{last_empty_row1 + 1}"].value = str(dados_usuarios.V1)
    planilha2[f"E{last_empty_row1 + 1}"].value = str(dados_usuarios.V2)
    planilha2[f"F{last_empty_row1 + 1}"].value = str(dados_usuarios.V3)
    planilha2[f"G{last_empty_row1 + 1}"].value = str(dados_usuarios.V4)
    planilha2[f"H{last_empty_row1 + 1}"].value = str(dados_usuarios.V5)
    planilha2[f"I{last_empty_row1 + 1}"].value = str(dados_usuarios.V6)
    planilha2[f"J{last_empty_row1 + 1}"].value = str(dados_usuarios.V7)
    planilha2[f"K{last_empty_row1 + 1}"].value = str(dados_usuarios.V8)
    planilha2[f"L{last_empty_row1 + 1}"].value = str(dados_usuarios.V9)
    planilha2[f"M{last_empty_row1 + 1}"].value = str(dados_usuarios.V10)

    planilha2[f"D{last_empty_row1 + 2}"].value = str(dados_usuarios.V1)
    planilha2[f"E{last_empty_row1 + 2}"].value = str(dados_usuarios.V2)
    planilha2[f"F{last_empty_row1 + 2}"].value = str(dados_usuarios.V3)
    planilha2[f"G{last_empty_row1 + 2}"].value = str(dados_usuarios.V4)
    planilha2[f"H{last_empty_row1 + 2}"].value = str(dados_usuarios.V5)
    planilha2[f"I{last_empty_row1 + 2}"].value = str(dados_usuarios.V6)
    planilha2[f"J{last_empty_row1 + 2}"].value = str(dados_usuarios.V7)
    planilha2[f"K{last_empty_row1 + 2}"].value = str(dados_usuarios.V8)
    planilha2[f"L{last_empty_row1 + 2}"].value = str(float(-(dados_usuarios.V8)))
    planilha2[f"M{last_empty_row1 + 2}"].value = 0

    planilha2[f"N{last_empty_row1 + 1}"].value = str("Pendente")
    planilha2[f"N{last_empty_row1 + 2}"].value = str("Pendente")

    planilha2[f"O{last_empty_row1 + 1}"].value = (
        1
        if planilha2[f"O{last_empty_row1}"].value == "Valor"
        else planilha2[f"O{last_empty_row1}"].value + 1
    )
    planilha2[f"O{last_empty_row1 + 2}"].value = (
        2
        if planilha2[f"O{last_empty_row1 + 1}"].value == 1
        else planilha2[f"O{last_empty_row1 + 1}"].value + 1
    )

    planilha2[f"P{last_empty_row1 + 1}"].value = str(dados_usuarios.V11)
    planilha2[f"P{last_empty_row1 + 2}"].value = str(dados_usuarios.V11)

    last_empty_row = len(list(planilha2.rows))

    ultima_linha_ativa1 = planilha2[f"A{last_empty_row}"].value
    print(last_empty_row)
    print(ultima_linha_ativa1)

    planilha2[f"A{last_empty_row + 1}"].value = "___"
    planilha2[f"B{last_empty_row + 1}"].value = "___"
    planilha2[f"C{last_empty_row + 1}"].value = str(current_user.email)
    planilha2[f"D{last_empty_row + 1}"].value = "___"
    planilha2[f"E{last_empty_row + 1}"].value = "___"
    planilha2[f"F{last_empty_row + 1}"].value = "___"
    planilha2[f"G{last_empty_row + 1}"].value = "___"
    planilha2[f"H{last_empty_row + 1}"].value = "___"
    planilha2[f"I{last_empty_row + 1}"].value = "___"
    planilha2[f"J{last_empty_row + 1}"].value = "___"
    planilha2[f"K{last_empty_row + 1}"].value = "___"
    planilha2[f"L{last_empty_row + 1}"].value = "___"
    planilha2[f"M{last_empty_row + 1}"].value = "___"
    planilha2[f"N{last_empty_row + 1}"].value = "___"
    planilha2[f"O{last_empty_row + 1}"].value = (
        int(planilha2[f"O{last_empty_row}"].value) + 1
    )
    planilha2[f"P{last_empty_row + 1}"].value = "___"

    last_empty_row2 = len(list(planilha2.rows))

    ultima_linha_ativa2 = planilha2[f"A{last_empty_row2}"].value
    print(last_empty_row2)
    print(ultima_linha_ativa2)

    wb2.save(
        f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx"
    )

    #

    db.session.delete(dados_usuarios)
    db.session.commit()
    flash(f"Provisão Deletada e Enviada para a Análise")

    return redirect(url_for("editprovisions"))


@app.route("/editarlinhausuarioeditar/<int:valor>", methods=["GET", "POST"])
def editarlinhausuarioeditar(valor):

    wb22 = load_workbook(
        f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx",
        data_only=True,
    )
    planilha2 = wb22["Modificacoes"]

    colunaD = planilha2["D"]
    valoresdacolunaD = []
    for vcelula in colunaD:
        if vcelula.value == "" or vcelula.value == "Null" or vcelula.value is None:
            pass
        else:
            valoresdacolunaD.append(vcelula.value)
    if str(valor) in valoresdacolunaD:
        flash(
            "Id Já Editado, para Editá-lo Novamente Delete a Modificação Referente a esse Id na Sessão de Status"
        )
        return redirect(url_for("editprovisions"))
    else:
        pass

    if request.method == "POST":
        try:
            botaoLR = request.form["botaoL"]

            if botaoLR == "HVoltar":
                return redirect(url_for("home"))
            elif botaoLR == "HVerProv":
                return redirect(url_for("viewaccounts"))
            elif botaoLR == "HVerProviso":
                return redirect(url_for("viewprovisions"))
            elif botaoLR == "HEditarProv":
                return redirect(url_for("editprovisions"))
            elif botaoLR == "HCriarProv":
                return redirect(url_for("createprovissions"))
            elif botaoLR == "HPermissoes":
                return redirect(url_for("seeprovisions"))
            elif botaoLR == "HDesconectar":
                return redirect(url_for("logout"))

            try:
                if botaoLR == "HPainel":
                    return redirect(url_for("basetablesupdate"))
            except:
                pass

            else:
                pass
        except:
            pass

    from app.models import create_models

    x = str(current_user.id)
    PlanilhaUsuario = create_models(x, x)

    try:
        from app.models import PlanilhaUsuario

        yw = PlanilhaUsuario.query.all()
        # print(PlanilhaUsuario.query.all())
        # ids = []
        # for instance in db.session.query(PlanilhaUsuario):
        #     x = instance.V1
        #     ids.append(x)
        # print(f'IDS = {ids}')
    except:
        print("Erro")

    try:
        from app.models import PlanilhaUsuario

        dados_usuarios = PlanilhaUsuario.query.get(valor)
        # add dados_usuarios = PlanilhaUsuario(request.form['V2'], request.form['V3'], request.form['V4'], request.form['V5'], request.form['V6'], request.form['V7'], request.form['V8'], request.form['V9'], request.form['V10'])

        # print(PlanilhaUsuario.query.all())
        # ids = []
        # for instance in db.session.query(PlanilhaUsuario):
        #     x = instance.V1
        #     ids.append(x)
        # print(f'IDS = {ids}')
    except Exception as e:
        print(e)
        pass

    if request.method == "POST":

        wb = load_workbook(
            r"app/static/Excels/Excel_Bases/Provisoes.xlsx", data_only=True
        )
        planilha = wb["Provisoes"]

        x1 = str(planilha["A1"].value)

        x2 = str(planilha["B1"].value)

        x3 = str(planilha["C1"].value)

        x4 = str(planilha["D1"].value)

        x5 = str(planilha["E1"].value)

        x6 = str(planilha["F1"].value)

        x7 = str(planilha["G1"].value)

        x8 = str(planilha["H1"].value)

        x9 = str(planilha["I1"].value)

        x10 = str(planilha["J1"].value)

        wb.close()

        my_file = Path(
            f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx"
        )
        if my_file.is_file():
            pass
        else:
            shutil.copyfile(
                "app/static/Excels/Excel_Modelos/Brose_Modificacoes_Gerais.xlsx",
                f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx",
            )

        wb2 = load_workbook(
            f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx",
            data_only=True,
        )
        planilha2 = wb2["Modificacoes"]

        planilha2["D2"].value = x1
        planilha2["E2"].value = x2
        planilha2["F2"].value = x3
        planilha2["G2"].value = x4
        planilha2["H2"].value = x5
        planilha2["I2"].value = x6
        planilha2["J2"].value = x7
        planilha2["K2"].value = x8
        planilha2["L2"].value = x9
        planilha2["M2"].value = x10

        #

        last_empty_row1 = len(list(planilha2.rows))

        ultima_linha_ativa1 = planilha2[f"A{last_empty_row1}"].value
        print(last_empty_row1)
        print(ultima_linha_ativa1)

        planilha2[f"A{last_empty_row1 + 1}"].value = "Valores Atuais"
        planilha2[f"A{last_empty_row1 + 2}"].value = "Mudanças Desejadas"

        planilha2[f"B{last_empty_row1 + 1}"].value = "Editar"
        planilha2[f"B{last_empty_row1 + 2}"].value = "Editar"

        planilha2[f"C{last_empty_row1 + 1}"].value = str(current_user.email)
        planilha2[f"C{last_empty_row1 + 2}"].value = str(current_user.email)

        planilha2[f"D{last_empty_row1 + 1}"].value = str(dados_usuarios.V1)
        planilha2[f"E{last_empty_row1 + 1}"].value = str(dados_usuarios.V2)
        planilha2[f"F{last_empty_row1 + 1}"].value = str(dados_usuarios.V3)
        planilha2[f"G{last_empty_row1 + 1}"].value = str(dados_usuarios.V4)
        planilha2[f"H{last_empty_row1 + 1}"].value = str(dados_usuarios.V5)
        planilha2[f"I{last_empty_row1 + 1}"].value = str(dados_usuarios.V6)
        planilha2[f"J{last_empty_row1 + 1}"].value = str(dados_usuarios.V7)
        planilha2[f"K{last_empty_row1 + 1}"].value = str(dados_usuarios.V8)
        planilha2[f"L{last_empty_row1 + 1}"].value = str(dados_usuarios.V9)
        planilha2[f"M{last_empty_row1 + 1}"].value = str(dados_usuarios.V10)

        planilha2[f"D{last_empty_row1 + 2}"].value = str(dados_usuarios.V1)
        planilha2[f"E{last_empty_row1 + 2}"].value = str(dados_usuarios.V2)
        planilha2[f"F{last_empty_row1 + 2}"].value = str(dados_usuarios.V3)
        planilha2[f"G{last_empty_row1 + 2}"].value = str(dados_usuarios.V4)
        planilha2[f"H{last_empty_row1 + 2}"].value = str(dados_usuarios.V5)
        planilha2[f"I{last_empty_row1 + 2}"].value = str(dados_usuarios.V6)
        planilha2[f"J{last_empty_row1 + 2}"].value = str(dados_usuarios.V7)
        planilha2[f"K{last_empty_row1 + 2}"].value = str(dados_usuarios.V8)
        try:
            planilha2[f"L{last_empty_row1 + 2}"].value = (
                str(dados_usuarios.V9)
                if request.form["V9"] == ""
                else str(float(float(request.form["V9"]) + float(dados_usuarios.V9)))
            )
        except:
            planilha2[f"L{last_empty_row1 + 2}"].value = (
                str(dados_usuarios.V9)
                if request.form["V9"] == ""
                else str(float(float(request.form["V9"]) + 0))
            )
        try:
            planilha2[f"M{last_empty_row1 + 2}"].value = (
                str(dados_usuarios.V10)
                if request.form["V9"] == ""
                else str(float(float(request.form["V9"]) + float(dados_usuarios.V10)))
            )
        except:
            planilha2[f"M{last_empty_row1 + 2}"].value = (
                str(dados_usuarios.V10)
                if request.form["V9"] == ""
                else str(float(float(request.form["V9"]) + 0))
            )

        planilha2[f"N{last_empty_row1 + 1}"].value = str("Pendente")
        planilha2[f"N{last_empty_row1 + 2}"].value = str("Pendente")

        planilha2[f"O{last_empty_row1 + 1}"].value = (
            1
            if planilha2[f"O{last_empty_row1}"].value == "Valor"
            else planilha2[f"O{last_empty_row1}"].value + 1
        )
        planilha2[f"O{last_empty_row1 + 2}"].value = (
            2
            if planilha2[f"O{last_empty_row1 + 1}"].value == 1
            else planilha2[f"O{last_empty_row1 + 1}"].value + 1
        )

        planilha2[f"P{last_empty_row1 + 1}"].value = str(dados_usuarios.V11)
        planilha2[f"P{last_empty_row1 + 2}"].value = str(dados_usuarios.V11)

        last_empty_row = len(list(planilha2.rows))

        ultima_linha_ativa1 = planilha2[f"A{last_empty_row}"].value
        print(last_empty_row)
        print(ultima_linha_ativa1)

        planilha2[f"A{last_empty_row + 1}"].value = "___"
        planilha2[f"B{last_empty_row + 1}"].value = "___"
        planilha2[f"C{last_empty_row + 1}"].value = str(current_user.email)
        planilha2[f"D{last_empty_row + 1}"].value = "___"
        planilha2[f"E{last_empty_row + 1}"].value = "___"
        planilha2[f"F{last_empty_row + 1}"].value = "___"
        planilha2[f"G{last_empty_row + 1}"].value = "___"
        planilha2[f"H{last_empty_row + 1}"].value = "___"
        planilha2[f"I{last_empty_row + 1}"].value = "___"
        planilha2[f"J{last_empty_row + 1}"].value = "___"
        planilha2[f"K{last_empty_row + 1}"].value = "___"
        planilha2[f"L{last_empty_row + 1}"].value = "___"
        planilha2[f"M{last_empty_row + 1}"].value = "___"
        planilha2[f"N{last_empty_row + 1}"].value = "___"
        planilha2[f"O{last_empty_row + 1}"].value = (
            int(planilha2[f"O{last_empty_row}"].value) + 1
        )
        planilha2[f"P{last_empty_row + 1}"].value = "___"

        last_empty_row2 = len(list(planilha2.rows))

        ultima_linha_ativa2 = planilha2[f"A{last_empty_row2}"].value
        print(last_empty_row2)
        print(ultima_linha_ativa2)

        wb2.save(
            f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx"
        )

        dados_usuarios.V2 = dados_usuarios.V2
        dados_usuarios.V3 = dados_usuarios.V3
        dados_usuarios.V4 = dados_usuarios.V4
        dados_usuarios.V5 = dados_usuarios.V5
        dados_usuarios.V6 = dados_usuarios.V6
        dados_usuarios.V7 = dados_usuarios.V7
        dados_usuarios.V8 = dados_usuarios.V8
        dados_usuarios.V9 = dados_usuarios.V9
        dados_usuarios.V10 = dados_usuarios.V10
        dados_usuarios.V11 = dados_usuarios.V11

        db.session.commit()

        flash(f"Provisão Editada e Enviada para a Análise")

        return redirect(url_for("editprovisions"))

    try:
        from app.models import PlanilhaUsuario

        valor = PlanilhaUsuario.query.get(1)
        print(valor)
    except Exception as e:
        print(e)
        pass

    try:
        wb = load_workbook(
            r"app/static/Excels/Excel_Bases/Provisoes.xlsx", data_only=True
        )
        planilha = wb["Provisoes"]

        primeira_linha = planilha["1"]

        titulos = []
        for valor in primeira_linha:
            if valor.value == "" or valor.value == "Null" or valor.value is None:
                pass
            else:
                titulos.append(valor.value)
    except:
        pass

    from datetime import datetime

    mes1 = datetime.now().month
    dia1 = datetime.now().day
    if mes1 == 1 and dia1 == 1:
        mes = "Dezembro"
    elif mes1 == 1 and dia1 != 1:
        mes = "Janeiro"

    elif mes1 == 2 and dia1 == 1:
        mes = "Janeiro"
    elif mes1 == 2 and dia1 != 1:
        mes = "Fevereiro"

    elif mes1 == 3 and dia1 == 1:
        mes = "Março"
    elif mes1 == 3 and dia1 != 1:
        mes = "Março"

    elif mes1 == 4 and dia1 == 1:
        mes = "Abril"
    elif mes1 == 4 and dia1 != 1:
        mes = "Abril"

    elif mes1 == 5 and dia1 == 1:
        mes = "Maio"
    elif mes1 == 5 and dia1 != 1:
        mes = "Maio"

    elif mes1 == 6 and dia1 == 1:
        mes = "Junho"
    elif mes1 == 6 and dia1 != 1:
        mes = "Junho"

    elif mes1 == 7 and dia1 == 1:
        mes = "Julho"
    elif mes1 == 7 and dia1 != 1:
        mes = "Julho"

    elif mes1 == 8 and dia1 == 1:
        mes = "Agosto"
    elif mes1 == 8 and dia1 != 1:
        mes = "Agosto"

    elif mes1 == 9 and dia1 == 1:
        mes = "Setembro"
    elif mes1 == 9 and dia1 != 1:
        mes = "Setembro"

    elif mes1 == 10 and dia1 == 1:
        mes = "Outubro"
    elif mes1 == 10 and dia1 != 1:
        mes = "Outubro"

    elif mes1 == 11 and dia1 == 1:
        mes = "Novembro"
    elif mes1 == 11 and dia1 != 1:
        mes = "Novembro"

    elif mes1 == 12 and dia1 == 1:
        mes = "Dezembro"
    elif mes1 == 12 and dia1 != 1:
        mes = "Dezembro"

    return render_template(
        "editarlinhausuarioeditar.html", mes=mes, titulos=titulos, dado=dados_usuarios
    )


@app.route("/createprovissions", methods=["GET", "POST"])
def createprovissions():

    if request.method == "POST":
        try:
            botaoLR = request.form["botaoL"]

            if botaoLR == "HVoltar":
                return redirect(url_for("home"))
            elif botaoLR == "HVerProv":
                return redirect(url_for("viewaccounts"))
            elif botaoLR == "HVerProviso":
                return redirect(url_for("viewprovisions"))
            elif botaoLR == "HEditarProv":
                return redirect(url_for("editprovisions"))
            elif botaoLR == "HCriarProv":
                return redirect(url_for("createprovissions"))
            elif botaoLR == "HPermissoes":
                return redirect(url_for("seeprovisions"))
            elif botaoLR == "HDesconectar":
                return redirect(url_for("logout"))

            try:
                if botaoLR == "HPainel":
                    return redirect(url_for("basetablesupdate"))
            except:
                pass

            else:
                pass
        except:
            pass

    try:
        from app.models import PlanilhaUsuario

        valor = PlanilhaUsuario.query.get(1)
        # print(valor)
    except Exception as e:
        print(e)
        pass

    try:
        wb = load_workbook(
            r"app/static/Excels/Excel_Bases/Provisoes.xlsx", data_only=True
        )
        planilha = wb["Provisoes"]

        primeira_linha = planilha["1"]

        titulos = []
        for valor in primeira_linha:
            if valor.value == "" or valor.value == "Null" or valor.value is None:
                pass
            else:
                titulos.append(valor.value)
        # print(titulos)
    except:
        pass

    if request.method == "POST":

        wb = load_workbook(
            r"app/static/Excels/Excel_Bases/Provisoes.xlsx", data_only=True
        )
        planilha = wb.active

        last_empty_row = len(list(planilha.rows))

        ultima_coluna_ativa = planilha[f"A{last_empty_row}"].value
        print("!!!!!!!!!!!!!!!!!!!!!")
        print(ultima_coluna_ativa)

        valor_do_novo_id = ultima_coluna_ativa + 1

        with open("app/static/Validar_Provisoes/ids_solicitados.json", "r") as data2:
            valoresutilizados = json.load(data2)

        if str(valor_do_novo_id) not in valoresutilizados:
            valoresutilizados.append(str(valor_do_novo_id))

            with open(
                "app/static/Validar_Provisoes/ids_solicitados.json", "w"
            ) as data1:
                json.dump(valoresutilizados, data1)

            from app.models import create_models

            x = str(current_user.id)
            PlanilhaUsuario = create_models(x, x)

            try:
                from app.models import PlanilhaUsuario

                yw = PlanilhaUsuario.query.all()
                # print(PlanilhaUsuario.query.all())
                # ids = []
                # for instance in db.session.query(PlanilhaUsuario):
                #     x = instance.V1
                #     ids.append(x)
                # print(f'IDS = {ids}')
            except:
                print("Erro")

            try:
                V66 = "-" if request.form["V6"] == "" else request.form["V6"]
            except:
                V66 = "-"

            dados_usuarios = PlanilhaUsuario(
                V1=int(valor_do_novo_id),
                V2=request.form["V2"],
                V3=request.form["V3"],
                V4=request.form["V4"],
                V5=request.form["V5"],
                V6=V66,
                V7=str(f"{current_user.name}"),
                V8="0",
                V9=request.form["V9"],
                V10=request.form["V9"],
                V11=request.form["V10"],
            )

            #

            wb = load_workbook(
                r"app/static/Excels/Excel_Bases/Provisoes.xlsx", data_only=True
            )
            planilha = wb["Provisoes"]

            x1 = str(planilha["A1"].value)

            x2 = str(planilha["B1"].value)

            x3 = str(planilha["C1"].value)

            x4 = str(planilha["D1"].value)

            x5 = str(planilha["E1"].value)

            x6 = str(planilha["F1"].value)

            x7 = str(planilha["G1"].value)

            x8 = str(planilha["H1"].value)

            x9 = str(planilha["I1"].value)

            x10 = str(planilha["J1"].value)

            wb.close()

            my_file = Path(
                f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx"
            )
            if my_file.is_file():
                pass
            else:
                shutil.copyfile(
                    "app/static/Excels/Excel_Modelos/Brose_Modificacoes_Gerais.xlsx",
                    f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx",
                )

            wb2 = load_workbook(
                f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx",
                data_only=True,
            )
            planilha2 = wb2["Modificacoes"]

            # print(planilha2['N2'].value)
            # print(x1)
            planilha2["D2"].value = x1
            planilha2["E2"].value = x2
            planilha2["F2"].value = x3
            planilha2["G2"].value = x4
            planilha2["H2"].value = x5
            planilha2["I2"].value = x6
            planilha2["J2"].value = x7
            planilha2["K2"].value = x8
            planilha2["L2"].value = x9
            planilha2["M2"].value = x10

            #

            last_empty_row1 = len(list(planilha2.rows))

            ultima_linha_ativa1 = planilha2[f"A{last_empty_row1}"].value
            # print(last_empty_row1)
            # print(ultima_linha_ativa1)

            planilha2[f"A{last_empty_row1 + 1}"].value = "Valores Atuais"
            planilha2[f"A{last_empty_row1 + 2}"].value = "Mudanças Desejadas"

            planilha2[f"B{last_empty_row1 + 1}"].value = "Adicionar"
            planilha2[f"B{last_empty_row1 + 2}"].value = "Adicionar"

            planilha2[f"C{last_empty_row1 + 1}"].value = str(current_user.email)
            planilha2[f"C{last_empty_row1 + 2}"].value = str(current_user.email)

            planilha2[f"D{last_empty_row1 + 1}"].value = str(valor_do_novo_id)
            planilha2[f"E{last_empty_row1 + 1}"].value = str("-")
            planilha2[f"F{last_empty_row1 + 1}"].value = str("-")
            planilha2[f"G{last_empty_row1 + 1}"].value = str("-")
            planilha2[f"H{last_empty_row1 + 1}"].value = str("-")
            planilha2[f"I{last_empty_row1 + 1}"].value = str("-")
            planilha2[f"J{last_empty_row1 + 1}"].value = str("-")
            planilha2[f"K{last_empty_row1 + 1}"].value = str("-")
            planilha2[f"L{last_empty_row1 + 1}"].value = str("-")
            planilha2[f"M{last_empty_row1 + 1}"].value = str("-")

            planilha2[f"D{last_empty_row1 + 2}"].value = str(valor_do_novo_id)
            planilha2[f"E{last_empty_row1 + 2}"].value = str(request.form["V2"])
            planilha2[f"F{last_empty_row1 + 2}"].value = str(request.form["V3"])
            planilha2[f"G{last_empty_row1 + 2}"].value = str(request.form["V4"])
            planilha2[f"H{last_empty_row1 + 2}"].value = str(request.form["V5"])
            planilha2[f"I{last_empty_row1 + 2}"].value = V66
            planilha2[f"J{last_empty_row1 + 2}"].value = str(current_user.name)
            planilha2[f"K{last_empty_row1 + 2}"].value = str("-")
            planilha2[f"L{last_empty_row1 + 2}"].value = str(request.form["V9"])
            planilha2[f"M{last_empty_row1 + 2}"].value = str(request.form["V9"])

            planilha2[f"N{last_empty_row1 + 1}"].value = str("Pendente")
            planilha2[f"N{last_empty_row1 + 2}"].value = str("Pendente")

            planilha2[f"O{last_empty_row1 + 1}"].value = (
                1
                if planilha2[f"O{last_empty_row1}"].value == "Valor"
                else planilha2[f"O{last_empty_row1}"].value + 1
            )
            planilha2[f"O{last_empty_row1 + 2}"].value = (
                2
                if planilha2[f"O{last_empty_row1 + 1}"].value == 1
                else planilha2[f"O{last_empty_row1 + 1}"].value + 1
            )

            planilha2[f"P{last_empty_row1 + 1}"].value = str("-")
            planilha2[f"P{last_empty_row1 + 2}"].value = str(request.form["V11"])

            last_empty_row = len(list(planilha2.rows))

            ultima_linha_ativa1 = planilha2[f"A{last_empty_row}"].value
            # print(last_empty_row)
            # print(ultima_linha_ativa1)

            planilha2[f"A{last_empty_row + 1}"].value = "___"
            planilha2[f"B{last_empty_row + 1}"].value = "___"
            planilha2[f"C{last_empty_row + 1}"].value = str(current_user.email)
            planilha2[f"D{last_empty_row + 1}"].value = "___"
            planilha2[f"E{last_empty_row + 1}"].value = "___"
            planilha2[f"F{last_empty_row + 1}"].value = "___"
            planilha2[f"G{last_empty_row + 1}"].value = "___"
            planilha2[f"H{last_empty_row + 1}"].value = "___"
            planilha2[f"I{last_empty_row + 1}"].value = "___"
            planilha2[f"J{last_empty_row + 1}"].value = "___"
            planilha2[f"K{last_empty_row + 1}"].value = "___"
            planilha2[f"L{last_empty_row + 1}"].value = "___"
            planilha2[f"M{last_empty_row + 1}"].value = "___"
            planilha2[f"N{last_empty_row + 1}"].value = "___"
            planilha2[f"O{last_empty_row + 1}"].value = (
                int(planilha2[f"O{last_empty_row}"].value) + 1
            )
            planilha2[f"P{last_empty_row + 1}"].value = "___"

            last_empty_row2 = len(list(planilha2.rows))

            ultima_linha_ativa2 = planilha2[f"A{last_empty_row2}"].value
            # print(last_empty_row2)
            # print(ultima_linha_ativa2)

            wb2.save(
                f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx"
            )

            #

            db.session.add(dados_usuarios)
            db.session.commit()

            flash(f"Provisão Criada e Enviada para a Análise")

            return redirect(url_for("createprovissions"))

        else:

            ultimovalordalista = int(max(valoresutilizados)) + 1

            print("!!!!!!!!!!!!!!!!!!!!!sdasd")
            print(ultimovalordalista)

            valoresutilizados.append(str(ultimovalordalista))

            with open(
                "app/static/Validar_Provisoes/ids_solicitados.json", "w"
            ) as data1:
                json.dump(valoresutilizados, data1)

            from app.models import create_models

            x = str(current_user.id)
            PlanilhaUsuario = create_models(x, x)

            try:
                from app.models import PlanilhaUsuario

                yw = PlanilhaUsuario.query.all()
                # print(PlanilhaUsuario.query.all())
                # ids = []
                # for instance in db.session.query(PlanilhaUsuario):
                #     x = instance.V1
                #     ids.append(x)
                # print(f'IDS = {ids}')
            except:
                print("Erro")

            try:
                V66 = "-" if request.form["V6"] == "" else request.form["V6"]
            except:
                V66 = "-"

            dados_usuarios = PlanilhaUsuario(
                V1=int(ultimovalordalista),
                V2=request.form["V2"],
                V3=request.form["V3"],
                V4=request.form["V4"],
                V5=request.form["V5"],
                V6=V66,
                V7=str(f"{current_user.name}"),
                V8="0",
                V9=request.form["V9"],
                V10=request.form["V9"],
                V11=request.form["V10"],
            )

            #

            wb = load_workbook(
                r"app/static/Excels/Excel_Bases/Provisoes.xlsx", data_only=True
            )
            planilha = wb["Provisoes"]

            x1 = str(planilha["A1"].value)

            x2 = str(planilha["B1"].value)

            x3 = str(planilha["C1"].value)

            x4 = str(planilha["D1"].value)

            x5 = str(planilha["E1"].value)

            x6 = str(planilha["F1"].value)

            x7 = str(planilha["G1"].value)

            x8 = str(planilha["H1"].value)

            x9 = str(planilha["I1"].value)

            x10 = str(planilha["J1"].value)

            wb.close()

            my_file = Path(
                f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx"
            )
            if my_file.is_file():
                pass
            else:
                shutil.copyfile(
                    "app/static/Excels/Excel_Modelos/Brose_Modificacoes_Gerais.xlsx",
                    f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx",
                )

            wb2 = load_workbook(
                f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx",
                data_only=True,
            )
            planilha2 = wb2["Modificacoes"]

            # print(planilha2['N2'].value)
            # print(x1)
            planilha2["D2"].value = x1
            planilha2["E2"].value = x2
            planilha2["F2"].value = x3
            planilha2["G2"].value = x4
            planilha2["H2"].value = x5
            planilha2["I2"].value = x6
            planilha2["J2"].value = x7
            planilha2["K2"].value = x8
            planilha2["L2"].value = x9
            planilha2["M2"].value = x10

            #

            last_empty_row1 = len(list(planilha2.rows))

            ultima_linha_ativa1 = planilha2[f"A{last_empty_row1}"].value
            # print(last_empty_row1)
            # print(ultima_linha_ativa1)

            planilha2[f"A{last_empty_row1 + 1}"].value = "Valores Atuais"
            planilha2[f"A{last_empty_row1 + 2}"].value = "Mudanças Desejadas"

            planilha2[f"B{last_empty_row1 + 1}"].value = "Adicionar"
            planilha2[f"B{last_empty_row1 + 2}"].value = "Adicionar"

            planilha2[f"C{last_empty_row1 + 1}"].value = str(current_user.email)
            planilha2[f"C{last_empty_row1 + 2}"].value = str(current_user.email)

            planilha2[f"D{last_empty_row1 + 1}"].value = str("-")
            planilha2[f"E{last_empty_row1 + 1}"].value = str("-")
            planilha2[f"F{last_empty_row1 + 1}"].value = str("-")
            planilha2[f"G{last_empty_row1 + 1}"].value = str("-")
            planilha2[f"H{last_empty_row1 + 1}"].value = str("-")
            planilha2[f"I{last_empty_row1 + 1}"].value = str("-")
            planilha2[f"J{last_empty_row1 + 1}"].value = str("-")
            planilha2[f"K{last_empty_row1 + 1}"].value = str("-")
            planilha2[f"L{last_empty_row1 + 1}"].value = str("-")
            planilha2[f"M{last_empty_row1 + 1}"].value = str("-")

            planilha2[f"D{last_empty_row1 + 2}"].value = str(ultimovalordalista)
            planilha2[f"E{last_empty_row1 + 2}"].value = str(request.form["V2"])
            planilha2[f"F{last_empty_row1 + 2}"].value = str(request.form["V3"])
            planilha2[f"G{last_empty_row1 + 2}"].value = str(request.form["V4"])
            planilha2[f"H{last_empty_row1 + 2}"].value = str(request.form["V5"])
            planilha2[f"I{last_empty_row1 + 2}"].value = V66
            planilha2[f"J{last_empty_row1 + 2}"].value = str(current_user.name)
            planilha2[f"K{last_empty_row1 + 2}"].value = str("-")
            planilha2[f"L{last_empty_row1 + 2}"].value = str(request.form["V9"])
            planilha2[f"M{last_empty_row1 + 2}"].value = str(request.form["V9"])

            planilha2[f"N{last_empty_row1 + 1}"].value = str("Pendente")
            planilha2[f"N{last_empty_row1 + 2}"].value = str("Pendente")

            planilha2[f"O{last_empty_row1 + 1}"].value = (
                1
                if planilha2[f"O{last_empty_row1}"].value == "Valor"
                else planilha2[f"O{last_empty_row1}"].value + 1
            )
            planilha2[f"O{last_empty_row1 + 2}"].value = (
                2
                if planilha2[f"O{last_empty_row1 + 1}"].value == 1
                else planilha2[f"O{last_empty_row1 + 1}"].value + 1
            )

            planilha2[f"P{last_empty_row1 + 1}"].value = str("-")
            planilha2[f"P{last_empty_row1 + 2}"].value = str(request.form["V11"])

            last_empty_row = len(list(planilha2.rows))

            ultima_linha_ativa1 = planilha2[f"A{last_empty_row}"].value
            # print(last_empty_row)
            # print(ultima_linha_ativa1)

            planilha2[f"A{last_empty_row + 1}"].value = "___"
            planilha2[f"B{last_empty_row + 1}"].value = "___"
            planilha2[f"C{last_empty_row + 1}"].value = str(current_user.email)
            planilha2[f"D{last_empty_row + 1}"].value = "___"
            planilha2[f"E{last_empty_row + 1}"].value = "___"
            planilha2[f"F{last_empty_row + 1}"].value = "___"
            planilha2[f"G{last_empty_row + 1}"].value = "___"
            planilha2[f"H{last_empty_row + 1}"].value = "___"
            planilha2[f"I{last_empty_row + 1}"].value = "___"
            planilha2[f"J{last_empty_row + 1}"].value = "___"
            planilha2[f"K{last_empty_row + 1}"].value = "___"
            planilha2[f"L{last_empty_row + 1}"].value = "___"
            planilha2[f"M{last_empty_row + 1}"].value = "___"
            planilha2[f"N{last_empty_row + 1}"].value = "___"
            planilha2[f"O{last_empty_row + 1}"].value = (
                int(planilha2[f"O{last_empty_row}"].value) + 1
            )
            planilha2[f"P{last_empty_row + 1}"].value = "___"

            last_empty_row2 = len(list(planilha2.rows))

            ultima_linha_ativa2 = planilha2[f"A{last_empty_row2}"].value
            # print(last_empty_row2)
            # print(ultima_linha_ativa2)

            wb2.save(
                f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx"
            )

            # 'f'app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_{str(current_user.id)}.xlsx'

            #

            db.session.add(dados_usuarios)
            db.session.commit()

            flash(f"Provisão Criada e Enviada para a Análise")

            return redirect(url_for("createprovissions"))

    from datetime import datetime

    mes1 = datetime.now().month
    dia1 = datetime.now().day
    if mes1 == 1 and dia1 == 1:
        mes = "Dezembro"
    elif mes1 == 1 and dia1 != 1:
        mes = "Janeiro"

    elif mes1 == 2 and dia1 == 1:
        mes = "Janeiro"
    elif mes1 == 2 and dia1 != 1:
        mes = "Fevereiro"

    elif mes1 == 3 and dia1 == 1:
        mes = "Março"
    elif mes1 == 3 and dia1 != 1:
        mes = "Março"

    elif mes1 == 4 and dia1 == 1:
        mes = "Abril"
    elif mes1 == 4 and dia1 != 1:
        mes = "Abril"

    elif mes1 == 5 and dia1 == 1:
        mes = "Maio"
    elif mes1 == 5 and dia1 != 1:
        mes = "Maio"

    elif mes1 == 6 and dia1 == 1:
        mes = "Junho"
    elif mes1 == 6 and dia1 != 1:
        mes = "Junho"

    elif mes1 == 7 and dia1 == 1:
        mes = "Julho"
    elif mes1 == 7 and dia1 != 1:
        mes = "Julho"

    elif mes1 == 8 and dia1 == 1:
        mes = "Agosto"
    elif mes1 == 8 and dia1 != 1:
        mes = "Agosto"

    elif mes1 == 9 and dia1 == 1:
        mes = "Setembro"
    elif mes1 == 9 and dia1 != 1:
        mes = "Setembro"

    elif mes1 == 10 and dia1 == 1:
        mes = "Outubro"
    elif mes1 == 10 and dia1 != 1:
        mes = "Outubro"

    elif mes1 == 11 and dia1 == 1:
        mes = "Novembro"
    elif mes1 == 11 and dia1 != 1:
        mes = "Novembro"

    elif mes1 == 12 and dia1 == 1:
        mes = "Dezembro"
    elif mes1 == 12 and dia1 != 1:
        mes = "Dezembro"

    return render_template("createprovissions.html", mes=mes, titulos=titulos)


@app.route("/seeprovisions", methods=["GET", "POST"])
def seeprovisions():

    if request.method == "POST":
        try:
            botaoAtu = request.form["botaoAtu"]

            if botaoAtu == "AtuProv":
                wb1 = load_workbook(
                    f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx",
                    data_only=True,
                )
                planilha1 = wb1["Modificacoes"]

                colunaN = planilha1["N"]
                colunaI = planilha1["I"]

                listadeconferencia = []
                for valordacelula0 in colunaN:
                    if valordacelula0.value == "Pendente":
                        listadeconferencia.append("Pendente")
                    else:
                        pass
                    
                listadeconferencia1 = []
                for valordacelula1 in colunaI:
                    if (
                        valordacelula1.value == "-"
                        and planilha1[f"A{valordacelula1.row}"].value
                        != "Valores Atuais"
                        and planilha1[f"B{valordacelula1.row}"].value == "Adicionar"
                        and planilha1[f"N{valordacelula1.row}"].value == "Aprovado"
                    ):
                        listadeconferencia1.append("-")
                    else:
                        pass
                
                import datetime

                today = datetime.datetime.now()
                prev_month = today.month - 1 if today.month > 1 else 12
                prev_year = today.year - 1 if prev_month == 12 else today.year

                mesnum = '{:02d}/{:02d}'.format(prev_month, prev_year % 100)
                mestext = '{}/{:02d}'.format(datetime.date(1900, prev_month, 1).strftime('%B'), prev_year % 100)

                # Abre o arquivo "Brose_Configuracoes.xlsx"
                wb = load_workbook('app/static/Excels/Excel_Bases/Brose_Configuracoes.xlsx')

                # Seleciona a planilha "Configs"
                sheet = wb['Configs']

                # Atribui o valor da célula B2 à variável respfin
                respfin = sheet['B2'].value

                # Atribui o valor da célula B3 à variável respsup
                respsup = sheet['B3'].value

                # Fecha o arquivo
                wb.close()

                # Imprime os valores das variáveis respfin e respsup
                print(respfin)
                print(respsup)

                fromaddr = "historicostatusprovisoes"
                toaddr = respfin
                msg = MIMEMultipart()
                msg["From"] = fromaddr
                msg["To"] = toaddr
                msg["Subject"] = f"Provisões Brose - Atualização Status de Provisões ({mesnum})"

                body = f'Prezado(a) administrador,\n\nSegue em anexo o arquivo de status de provisões referente a data de {mestext}.\n\nAtenciosamente,\nEquipe Automatizada Brose Provisões - Financeiro Brasil'
                msg.attach(MIMEText(body, "plain"))

                # File
                filename = "Brose_Modificacoes_Solicitacoes.xlsx"
                attachment = open(f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx","rb",)
                p = MIMEBase('application', 'octet-stream')
                p.set_payload((attachment).read())
                encoders.encode_base64(p)
                p.add_header('Content-Disposition', "attachment; filename= %s" % filename)
                msg.attach(p)

                # Send
                text = msg.as_string()
                # smtp1 = smtplib.SMTP("127.0.0.1")
                # smtp1.sendmail(fromaddr, toaddr, text)
                # smtp1.quit()
                with smtplib.SMTP("127.0.0.1") as smtp1:
                    smtp1.sendmail(fromaddr, toaddr, text)

                for valordacelulaNNN in colunaN:
                    if valordacelulaNNN.value == "Negado" and planilha1[f"A{valordacelulaNNN.row}"].value != "Valores Atuais":
                        print("Negado")
                        print(planilha1[f"D{valordacelulaNNN.row}"].value) # ID
                        print(planilha1[f"E{valordacelulaNNN.row}"].value) # Descrição
                        print(planilha1[f"F{valordacelulaNNN.row}"].value) # Planta
                        print(planilha1[f"G{valordacelulaNNN.row}"].value) # CC
                        print(planilha1[f"H{valordacelulaNNN.row}"].value) # Conta de Resultado
                        print(planilha1[f"L{valordacelulaNNN.row}"].value) # Valor Solicitado
                        print("Negado")

                        fromaddr2 = "statusprovisoes"
                        toaddr2 = f'({planilha1[f"J{valordacelulaNNN.row}"].value})'
                        msg2 = MIMEMultipart()
                        msg2["From"] = fromaddr2
                        msg2["To"] = toaddr2
                        msg2["Subject"] = f'Provisões Brose - Negada - Resultado da Provisão de ID {planilha1[f"D{valordacelulaNNN.row}"].value}'

                        body2 = f'Prezado(a) usuário {(planilha1[f"J{valordacelulaNNN.row}"].value).replace("@brose.com","")},\n\nInformamos que a provisão {planilha1[f"D{valordacelulaNNN.row}"].value} que apresenta as seguintes características:\n\nItem/Descrição: {planilha1[f"E{valordacelulaNNN.row}"].value}\nPlanta: {planilha1[f"F{valordacelulaNNN.row}"].value}\nCentro de Custo: {planilha1[f"G{valordacelulaNNN.row}"].value}\nConta de Resultado: {planilha1[f"H{valordacelulaNNN.row}"].value}\nValor: {planilha1[f"L{valordacelulaNNN.row}"].value}\n\nFoi Negada!\nPela Justificativa: {planilha1[f"I{valordacelulaNNN.row}"].value}\n\nPara dúvidas entre em contato com o Suporte Da Plataforma\n\nAtenciosamente,\nEquipe Automatizada Brose Provisões Brasil'
                        msg2.attach(MIMEText(body2, "plain"))

                        text2 = msg2.as_string()
                        # smtp2 = smtplib.SMTP("127.0.0.1")
                        # smtp2.sendmail(fromaddr2, toaddr2, text2)
                        # smtp2.quit()
                        with smtplib.SMTP("127.0.0.1") as smtp1:
                            smtp1.sendmail(fromaddr, toaddr, text2)

                    elif valordacelulaNNN.value == "Aprovado" and planilha1[f"A{valordacelulaNNN.row}"].value != "Valores Atuais":
                        
                        

                        fromaddr3 = "statusprovisoes"
                        toaddr3 = f'({planilha1[f"J{valordacelulaNNN.row}"].value})'
                        msg3 = MIMEMultipart()
                        msg3["From"] = fromaddr3
                        msg3["To"] = toaddr3
                        msg3["Subject"] = f'Provisões Brose - Aprovada - Resultado da Provisão de ID {planilha1[f"D{valordacelulaNNN.row}"].value}'

                        body3 = f'Prezado(a) usuário {(planilha1[f"J{valordacelulaNNN.row}"].value).replace("@brose.com","")},\n\nInformamos que a provisão {planilha1[f"D{valordacelulaNNN.row}"].value} que apresenta as seguintes características:\n\nItem/Descrição: {planilha1[f"E{valordacelulaNNN.row}"].value}\nPlanta: {planilha1[f"F{valordacelulaNNN.row}"].value}\nCentro de Custo: {planilha1[f"G{valordacelulaNNN.row}"].value}\nConta de Resultado: {planilha1[f"H{valordacelulaNNN.row}"].value}\nValor: {planilha1[f"L{valordacelulaNNN.row}"].value}\n\nFoi Aprovada!\n\nPara dúvidas entre em contato com o Suporte Da Plataforma\n\nAtenciosamente,\nEquipe Automatizada Brose Provisões Brasil'
                        msg3.attach(MIMEText(body3, "plain"))

                        text3 = msg3.as_string()
                        # smtp3 = smtplib.SMTP("127.0.0.1")
                        # smtp3.sendmail(fromaddr3, toaddr3, text3)
                        # smtp3.quit()
                        with smtplib.SMTP("127.0.0.1") as smtp1:
                            smtp1.sendmail(fromaddr, toaddr, text3)
                        

                    else:
                        pass

                colunaB = planilha1["B"]

                if "Pendente" in listadeconferencia:
                    flash("Erro: Status Pendentes Encontrados")
                elif "-" in listadeconferencia1:
                    flash("Valores da Conta Passivo Não Preenchidos")
                else:
                    for valordacelula in colunaB:
                        if (
                            valordacelula.value == "Baixar"
                            and planilha1[f"A{valordacelula.row}"].value
                            != "Valores Atuais"
                            and planilha1[f"N{valordacelula.row}"].value == "Aprovado"
                        ):

                            # print(valordacelula.row)
                            # print(valordacelula.column_letter)

                            idexcluir = planilha1[f"D{valordacelula.row}"].value

                            wb2 = load_workbook(
                                r"app/static/Excels/Excel_Bases/Provisoes.xlsx"
                            )
                            planilha2 = wb2["Provisoes Fracionadas"]

                            from datetime import datetime

                            mes1 = datetime.now().month
                            if mes1 == 1:
                                mes = "T"
                            elif mes1 == 2:
                                mes = "I"
                            elif mes1 == 3:
                                mes = "J"
                            elif mes1 == 4:
                                mes = "K"
                            elif mes1 == 5:
                                mes = "L"
                            elif mes1 == 6:
                                mes = "M"
                            elif mes1 == 7:
                                mes = "N"
                            elif mes1 == 8:
                                mes = "O"
                            elif mes1 == 9:
                                mes = "P"
                            elif mes1 == 10:
                                mes = "Q"
                            elif mes1 == 11:
                                mes = "R"
                            elif mes1 == 12:
                                mes = "S"

                            colunaA = planilha2["A"]

                            # print(idexcluir)

                            for valordacelula2 in colunaA:

                                if valordacelula2.value == int(
                                    idexcluir
                                ) or valordacelula2.value == str(idexcluir):

                                    A = planilha2[f"I{valordacelula2.row}"].value
                                    B = planilha2[f"J{valordacelula2.row}"].value
                                    C = planilha2[f"K{valordacelula2.row}"].value
                                    D = planilha2[f"L{valordacelula2.row}"].value
                                    E = planilha2[f"M{valordacelula2.row}"].value
                                    F = planilha2[f"N{valordacelula2.row}"].value
                                    G = planilha2[f"O{valordacelula2.row}"].value
                                    H = planilha2[f"P{valordacelula2.row}"].value
                                    I = planilha2[f"Q{valordacelula2.row}"].value
                                    J = planilha2[f"R{valordacelula2.row}"].value
                                    K = planilha2[f"S{valordacelula2.row}"].value
                                    L = planilha2[f"T{valordacelula2.row}"].value

                                    try:
                                        A1 = float(A)
                                    except:
                                        A1 = 0
                                    try:
                                        B1 = float(B)
                                    except:
                                        B1 = 0
                                    try:
                                        C1 = float(C)
                                    except:
                                        C1 = 0
                                    try:
                                        D1 = float(D)
                                    except:
                                        D1 = 0
                                    try:
                                        E1 = float(E)
                                    except:
                                        E1 = 0
                                    try:
                                        F1 = float(F)
                                    except:
                                        F1 = 0
                                    try:
                                        G1 = float(G)
                                    except:
                                        G1 = 0
                                    try:
                                        H1 = float(H)
                                    except:
                                        H1 = 0
                                    try:
                                        I1 = float(I)
                                    except:
                                        I1 = 0
                                    try:
                                        J1 = float(J)
                                    except:
                                        J1 = 0
                                    try:
                                        K1 = float(K)
                                    except:
                                        K1 = 0
                                    try:
                                        L1 = float(L)
                                    except:
                                        L1 = 0

                                    # -5.900,00

                                    somatotal = (
                                        A1
                                        + B1
                                        + C1
                                        + D1
                                        + E1
                                        + F1
                                        + G1
                                        + H1
                                        + I1
                                        + J1
                                        + K1
                                        + L1
                                    )

                                    TC = float(
                                        planilha2[f"H{valordacelula2.row}"].value
                                    )

                                    Valor = float(-(TC + somatotal))

                                    print(TC)
                                    print(somatotal)
                                    print(Valor)

                                    planilha2[
                                        f"{mes}{valordacelula2.row}"
                                    ].value = Valor

                                    # print(valordacelula2.row)
                                    # print(valordacelula2.column_letter)

                                    planilha3 = wb2["Provisoes"]

                                    colunaA = planilha3["A"]

                                    # print(idexcluir)

                                    for valordacelula3 in colunaA:

                                        if valordacelula3.value == int(
                                            idexcluir
                                        ) or valordacelula3.value == str(idexcluir):
                                            planilha3[
                                                f"I{valordacelula3.row}"
                                            ].value = (somatotal + Valor)
                                            planilha3[
                                                f"J{valordacelula3.row}"
                                            ].value = (
                                                planilha3[
                                                    f"H{valordacelula3.row}"
                                                ].value
                                                + Valor
                                            )

                                    wb2.save(
                                        f"app/static/Excels/Excel_Bases/Provisoes.xlsx"
                                    )

                        elif (
                            valordacelula.value == "Editar"
                            and planilha1[f"A{valordacelula.row}"].value
                            != "Valores Atuais"
                            and planilha1[f"N{valordacelula.row}"].value == "Aprovado"
                        ):

                            ideditar = planilha1[f"D{valordacelula.row}"].value

                            wb2 = load_workbook(
                                r"app/static/Excels/Excel_Bases/Provisoes.xlsx"
                            )
                            planilha2 = wb2["Provisoes Fracionadas"]

                            from datetime import datetime

                            mes1 = datetime.now().month
                            if mes1 == 1:
                                mes = "T"
                            elif mes1 == 2:
                                mes = "I"
                            elif mes1 == 3:
                                mes = "J"
                            elif mes1 == 4:
                                mes = "K"
                            elif mes1 == 5:
                                mes = "L"
                            elif mes1 == 6:
                                mes = "M"
                            elif mes1 == 7:
                                mes = "N"
                            elif mes1 == 8:
                                mes = "O"
                            elif mes1 == 9:
                                mes = "P"
                            elif mes1 == 10:
                                mes = "Q"
                            elif mes1 == 11:
                                mes = "R"
                            elif mes1 == 12:
                                mes = "S"

                            colunaA = planilha2["A"]

                            # print(idexcluir)

                            for valordacelula2 in colunaA:

                                if valordacelula2.value == int(
                                    ideditar
                                ) or valordacelula2.value == str(ideditar):

                                    planilha2[
                                        f"F{valordacelula2.row}"
                                    ].value = planilha1[f"I{valordacelula.row}"].value

                                    A = planilha2[f"I{valordacelula2.row}"].value
                                    B = planilha2[f"J{valordacelula2.row}"].value
                                    C = planilha2[f"K{valordacelula2.row}"].value
                                    D = planilha2[f"L{valordacelula2.row}"].value
                                    E = planilha2[f"M{valordacelula2.row}"].value
                                    F = planilha2[f"N{valordacelula2.row}"].value
                                    G = planilha2[f"O{valordacelula2.row}"].value
                                    H = planilha2[f"P{valordacelula2.row}"].value
                                    I = planilha2[f"Q{valordacelula2.row}"].value
                                    J = planilha2[f"R{valordacelula2.row}"].value
                                    K = planilha2[f"S{valordacelula2.row}"].value
                                    L = planilha2[f"T{valordacelula2.row}"].value

                                    try:
                                        A1 = float(A)
                                    except:
                                        A1 = 0
                                    try:
                                        B1 = float(B)
                                    except:
                                        B1 = 0
                                    try:
                                        C1 = float(C)
                                    except:
                                        C1 = 0
                                    try:
                                        D1 = float(D)
                                    except:
                                        D1 = 0
                                    try:
                                        E1 = float(E)
                                    except:
                                        E1 = 0
                                    try:
                                        F1 = float(F)
                                    except:
                                        F1 = 0
                                    try:
                                        G1 = float(G)
                                    except:
                                        G1 = 0
                                    try:
                                        H1 = float(H)
                                    except:
                                        H1 = 0
                                    try:
                                        I1 = float(I)
                                    except:
                                        I1 = 0
                                    try:
                                        J1 = float(J)
                                    except:
                                        J1 = 0
                                    try:
                                        K1 = float(K)
                                    except:
                                        K1 = 0
                                    try:
                                        L1 = float(L)
                                    except:
                                        L1 = 0

                                    # -5.900,00

                                    somatotal = (
                                        A1
                                        + B1
                                        + C1
                                        + D1
                                        + E1
                                        + F1
                                        + G1
                                        + H1
                                        + I1
                                        + J1
                                        + K1
                                        + L1
                                    )

                                    TC = float(
                                        planilha2[f"H{valordacelula2.row}"].value
                                    )

                                    Valor = float(
                                        -(
                                            somatotal
                                            - float(
                                                planilha1[f"L{valordacelula.row}"].value
                                            )
                                        )
                                    )

                                    print(TC)
                                    print(somatotal)
                                    print(Valor)

                                    justeditar = planilha1[
                                        f"P{valordacelula.row}"
                                    ].value

                                    planilha2[
                                        f"{mes}{valordacelula2.row}"
                                    ].value = Valor

                                    planilha2[
                                        f"W{valordacelula2.row}"
                                    ].value = justeditar

                                    planilha3 = wb2["Provisoes"]

                                    colunaA = planilha3["A"]

                                    # print(idexcluir)

                                    for valordacelula3 in colunaA:

                                        if valordacelula3.value == int(
                                            ideditar
                                        ) or valordacelula3.value == str(ideditar):
                                            planilha3[
                                                f"I{valordacelula3.row}"
                                            ].value = (somatotal + Valor)
                                            planilha3[
                                                f"J{valordacelula3.row}"
                                            ].value = (
                                                planilha3[
                                                    f"H{valordacelula3.row}"
                                                ].value
                                                + Valor
                                            )
                                            planilha3[
                                                f"K{valordacelula3.row}"
                                            ].value = justeditar

                                    wb2.save(
                                        f"app/static/Excels/Excel_Bases/Provisoes.xlsx"
                                    )

                        elif (
                            valordacelula.value == "Adicionar"
                            and planilha1[f"A{valordacelula.row}"].value
                            != "Valores Atuais"
                            and planilha1[f"N{valordacelula.row}"].value == "Aprovado"
                        ):

                            from datetime import datetime

                            mes1 = datetime.now().month
                            if mes1 == 1:
                                mes = "T"
                            elif mes1 == 2:
                                mes = "I"
                            elif mes1 == 3:
                                mes = "J"
                            elif mes1 == 4:
                                mes = "K"
                            elif mes1 == 5:
                                mes = "L"
                            elif mes1 == 6:
                                mes = "M"
                            elif mes1 == 7:
                                mes = "N"
                            elif mes1 == 8:
                                mes = "O"
                            elif mes1 == 9:
                                mes = "P"
                            elif mes1 == 10:
                                mes = "Q"
                            elif mes1 == 11:
                                mes = "R"
                            elif mes1 == 12:
                                mes = "S"

                            wb2 = load_workbook(
                                r"app/static/Excels/Excel_Bases/Provisoes.xlsx"
                            )
                            planilha2 = wb2["Provisoes Fracionadas"]

                            last_empty_row = len(list(planilha2.rows))

                            # print(f'Ultima Linha Ativa + 1: {last_empty_row + 1}')

                            linhaparaadicionar = int(last_empty_row + 1)

                            planilha2[
                                f"I{linhaparaadicionar}"
                            ].number_format = (
                                r'_-* #,##0.00_-;\-* #,##0.00_-;_-* "-"??_-;_-@_-'
                            )
                            planilha2[
                                f"J{linhaparaadicionar}"
                            ].number_format = (
                                r'_-* #,##0.00_-;\-* #,##0.00_-;_-* "-"??_-;_-@_-'
                            )
                            planilha2[
                                f"K{linhaparaadicionar}"
                            ].number_format = (
                                r'_-* #,##0.00_-;\-* #,##0.00_-;_-* "-"??_-;_-@_-'
                            )
                            planilha2[
                                f"L{linhaparaadicionar}"
                            ].number_format = (
                                r'_-* #,##0.00_-;\-* #,##0.00_-;_-* "-"??_-;_-@_-'
                            )
                            planilha2[
                                f"M{linhaparaadicionar}"
                            ].number_format = (
                                r'_-* #,##0.00_-;\-* #,##0.00_-;_-* "-"??_-;_-@_-'
                            )
                            planilha2[
                                f"N{linhaparaadicionar}"
                            ].number_format = (
                                r'_-* #,##0.00_-;\-* #,##0.00_-;_-* "-"??_-;_-@_-'
                            )
                            planilha2[
                                f"O{linhaparaadicionar}"
                            ].number_format = (
                                r'_-* #,##0.00_-;\-* #,##0.00_-;_-* "-"??_-;_-@_-'
                            )
                            planilha2[
                                f"P{linhaparaadicionar}"
                            ].number_format = (
                                r'_-* #,##0.00_-;\-* #,##0.00_-;_-* "-"??_-;_-@_-'
                            )
                            planilha2[
                                f"Q{linhaparaadicionar}"
                            ].number_format = (
                                r'_-* #,##0.00_-;\-* #,##0.00_-;_-* "-"??_-;_-@_-'
                            )
                            planilha2[
                                f"R{linhaparaadicionar}"
                            ].number_format = (
                                r'_-* #,##0.00_-;\-* #,##0.00_-;_-* "-"??_-;_-@_-'
                            )
                            planilha2[
                                f"S{linhaparaadicionar}"
                            ].number_format = (
                                r'_-* #,##0.00_-;\-* #,##0.00_-;_-* "-"??_-;_-@_-'
                            )
                            planilha2[
                                f"T{linhaparaadicionar}"
                            ].number_format = (
                                r'_-* #,##0.00_-;\-* #,##0.00_-;_-* "-"??_-;_-@_-'
                            )
                            planilha2[
                                f"U{linhaparaadicionar}"
                            ].number_format = (
                                r'_-* #,##0.00_-;\-* #,##0.00_-;_-* "-"??_-;_-@_-'
                            )
                            planilha2[
                                f"V{linhaparaadicionar}"
                            ].number_format = (
                                r'_-* #,##0.00_-;\-* #,##0.00_-;_-* "-"??_-;_-@_-'
                            )

                            planilha2[f"A{linhaparaadicionar}"].value = int(
                                planilha2[f"A{linhaparaadicionar-1}"].value + 1
                            )
                            planilha2[f"B{linhaparaadicionar}"].value = str(
                                planilha1[f"E{valordacelula.row}"].value
                            )
                            planilha2[f"C{linhaparaadicionar}"].value = str(
                                planilha1[f"F{valordacelula.row}"].value
                            )
                            planilha2[f"D{linhaparaadicionar}"].value = str(
                                planilha1[f"G{valordacelula.row}"].value
                            )
                            planilha2[f"E{linhaparaadicionar}"].value = str(
                                planilha1[f"H{valordacelula.row}"].value
                            )
                            planilha2[f"F{linhaparaadicionar}"].value = str(
                                planilha1[f"I{valordacelula.row}"].value
                            )
                            planilha2[f"G{linhaparaadicionar}"].value = str(
                                planilha1[f"J{valordacelula.row}"].value
                            )
                            planilha2[f"H{linhaparaadicionar}"].value = float(0)
                            planilha2[f"I{linhaparaadicionar}"].value = float(0)
                            planilha2[f"J{linhaparaadicionar}"].value = float(0)
                            planilha2[f"K{linhaparaadicionar}"].value = float(0)
                            planilha2[f"L{linhaparaadicionar}"].value = float(0)
                            planilha2[f"M{linhaparaadicionar}"].value = float(0)
                            planilha2[f"N{linhaparaadicionar}"].value = float(0)
                            planilha2[f"O{linhaparaadicionar}"].value = float(0)
                            planilha2[f"P{linhaparaadicionar}"].value = float(0)
                            planilha2[f"Q{linhaparaadicionar}"].value = float(0)
                            planilha2[f"R{linhaparaadicionar}"].value = float(0)
                            planilha2[f"S{linhaparaadicionar}"].value = float(0)
                            planilha2[f"T{linhaparaadicionar}"].value = float(0)
                            planilha2[f"{mes}{linhaparaadicionar}"].value = float(
                                planilha1[f"L{valordacelula.row}"].value
                            )
                            planilha2[
                                f"U{linhaparaadicionar}"
                            ].value = (
                                f"=SUM(I{linhaparaadicionar}:T{linhaparaadicionar})"
                            )
                            planilha2[
                                f"V{linhaparaadicionar}"
                            ].value = f"=U{linhaparaadicionar}+H{linhaparaadicionar}"
                            planilha2[f"W{linhaparaadicionar}"].value = str(
                                planilha1[f"P{valordacelula.row}"].value
                            )

                            planilha3 = wb2["Provisoes"]

                            planilha3[
                                f"H{linhaparaadicionar}"
                            ].number_format = (
                                r'_-* #,##0.00_-;\-* #,##0.00_-;_-* "-"??_-;_-@_-'
                            )
                            planilha3[
                                f"I{linhaparaadicionar}"
                            ].number_format = (
                                r'_-* #,##0.00_-;\-* #,##0.00_-;_-* "-"??_-;_-@_-'
                            )
                            planilha3[
                                f"J{linhaparaadicionar}"
                            ].number_format = (
                                r'_-* #,##0.00_-;\-* #,##0.00_-;_-* "-"??_-;_-@_-'
                            )

                            planilha3[f"A{linhaparaadicionar}"].value = int(
                                planilha3[f"A{linhaparaadicionar - 1}"].value + 1
                            )
                            planilha3[f"B{linhaparaadicionar}"].value = str(
                                planilha1[f"E{valordacelula.row}"].value
                            )
                            planilha3[f"C{linhaparaadicionar}"].value = str(
                                planilha1[f"F{valordacelula.row}"].value
                            )
                            planilha3[f"D{linhaparaadicionar}"].value = str(
                                planilha1[f"G{valordacelula.row}"].value
                            )
                            planilha3[f"E{linhaparaadicionar}"].value = str(
                                planilha1[f"H{valordacelula.row}"].value
                            )
                            planilha3[f"F{linhaparaadicionar}"].value = str(
                                planilha1[f"I{valordacelula.row}"].value
                            )
                            planilha3[f"G{linhaparaadicionar}"].value = str(
                                planilha1[f"J{valordacelula.row}"].value
                            )
                            planilha3[f"H{linhaparaadicionar}"].value = float(0)
                            planilha3[f"I{linhaparaadicionar}"].value = float(
                                planilha1[f"L{valordacelula.row}"].value
                            )
                            planilha3[f"J{linhaparaadicionar}"].value = float(
                                planilha1[f"L{valordacelula.row}"].value
                            )
                            planilha3[f"K{linhaparaadicionar}"].value = str(
                                planilha1[f"P{valordacelula.row}"].value
                            )

                            wb2.save(f"app/static/Excels/Excel_Bases/Provisoes.xlsx")

                    #
                    #
                    #
                    #######

                    path = "app/static/Excels"

                    source = "Excel_Modelos/Brose_Modificacoes_Gerais.xlsx"
                    destination = (
                        "Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx"
                    )

                    sourcePath = path + "/" + source
                    destinationPath = path + "/" + destination

                    if os.path.isdir(destinationPath + "/" + source):
                        print(source, "exists in the destination path!")
                        shutil.rmtree(destinationPath + "/" + source)

                    elif os.path.isfile(destinationPath + "/" + source):
                        os.remove(destinationPath + "/" + source)
                        print(source, "deleted in", destination)

                    dest = shutil.copyfile(sourcePath, destinationPath)

                    #

                    wb = load_workbook(
                        r"app/static/Excels/Excel_Bases/Provisoes.xlsx", data_only=True
                    )
                    planilha = wb["Provisoes"]

                    x1 = str(planilha["A1"].value)

                    x2 = str(planilha["B1"].value)

                    x3 = str(planilha["C1"].value)

                    x4 = str(planilha["D1"].value)

                    x5 = str(planilha["E1"].value)

                    x6 = str(planilha["F1"].value)

                    x7 = str(planilha["G1"].value)

                    x8 = str(planilha["H1"].value)

                    x9 = str(planilha["I1"].value)

                    x10 = str(planilha["J1"].value)

                    wb.close()

                    my_file = Path(
                        f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx"
                    )
                    if my_file.is_file():
                        pass
                    else:
                        shutil.copyfile(
                            "app/static/Excels/Excel_Modelos/Brose_Modificacoes_Gerais.xlsx",
                            f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx",
                        )

                    wb2 = load_workbook(
                        f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx",
                        data_only=True,
                    )
                    planilha2 = wb2["Modificacoes"]

                    print(planilha2["N2"].value)
                    print(x1)
                    planilha2["D2"].value = x1
                    planilha2["E2"].value = x2
                    planilha2["F2"].value = x3
                    planilha2["G2"].value = x4
                    planilha2["H2"].value = x5
                    planilha2["I2"].value = x6
                    planilha2["J2"].value = x7
                    planilha2["K2"].value = x8
                    planilha2["L2"].value = x9
                    planilha2["M2"].value = x10

                    wb2.save(
                        "app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx"
                    )
                    wb2.close()

                    #
                    #
                    #
                    #######

                    emailsss = []
                    for instance in db.session.query(User):
                        x = instance.email
                        emailsss.append(x)
                    # print(emails)

                    for email in emailsss:

                        wb = load_workbook(
                            r"app/static/Excels/Excel_Bases/Provisoes.xlsx",
                            data_only=True,
                        )
                        planilha = wb["Provisoes"]

                        for cell in planilha["G"][1:]:
                            # print(cell.value)
                            if str(cell.value) != email:
                                planilha.delete_rows(cell.row)

                        usuario = db.session.query(User).filter_by(email=email).first()
                        print(usuario)
                        wb.save(
                            f"app/static/Excels/Excel_Provisoes_Usuarios/Provisoes_User_id_{str(usuario.id)}.xlsx"
                        )

                    ids = []
                    for instance in db.session.query(User):
                        x = instance.id
                        ids.append(x)
                        # print(x)
                    # print(id)

                    for ide in ids:

                        if (
                            ide == 1
                            or ide == 2
                            or ide == 3
                            or ide == "1"
                            or ide == "2"
                            or ide == "3"
                        ):
                            con = sqlite3.connect(
                                f"app/Data_Bases_Usuarios/Provisoes_Editaveis_Usuario_{ide}.db"
                            )
                            df = pd.read_excel(
                                f"app/static/Excels/Excel_Bases/Provisoes.xlsx",
                                sheet_name="Provisoes",
                            )
                            df.to_sql(
                                f"Provisoes_Editaveis_Usuario_{ide}",
                                con,
                                index=False,
                                if_exists="replace",
                            )
                            con.commit()
                            con.close()
                        else:
                            con = sqlite3.connect(
                                f"app/Data_Bases_Usuarios/Provisoes_Editaveis_Usuario_{ide}.db"
                            )
                            df = pd.read_excel(
                                f"app/static/Excels/Excel_Provisoes_Usuarios/Provisoes_User_id_{ide}.xlsx",
                                sheet_name="Provisoes",
                            )
                            df.to_sql(
                                f"Provisoes_Editaveis_Usuario_{ide}",
                                con,
                                index=False,
                                if_exists="replace",
                            )
                            con.commit()
                            con.close()

                    flash("Novas Provisões Adicionadas ao Arquivo Base")
                return redirect(url_for("seeprovisions"))
        except Exception as e:
            print(e)

    if request.method == "POST":

        try:

            uploaded_file = request.files["arquivo0"]
            filename = uploaded_file.filename

            if filename == "" and request.files["arquivo0"] != "":
                flash("Selecione Um Arquivo")
            elif filename != "" and request.files["arquivo0"] != "":
                file_ext = os.path.splitext(filename)[1]
                if (
                    file_ext not in app.config["UPLOAD_EXTENSIONS"]
                    or filename != "Brose_Modificacoes_Solicitacoes.xlsx"
                ):
                    flash(
                        "Formate o Excel com o nome Brose_Modificacoes_Solicitacoes.xlsx"
                    )
                else:
                    uploaded_file.save(
                        os.path.join(
                            os.path.join(
                                app.config["UPLOAD_FOLDER"],
                                secure_filename(uploaded_file.filename),
                            )
                        )
                    )  # Contas

                    path = "app/static/Excels"

                    source = "Excel_Bases/Brose_Modificacoes_Solicitacoes.xlsx"
                    destination = (
                        "Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx"
                    )

                    sourcePath = path + "/" + source
                    destinationPath = path + "/" + destination

                    if os.path.isdir(destinationPath + "/" + source):
                        print(source, "exists in the destination path!")
                        shutil.rmtree(destinationPath + "/" + source)

                    elif os.path.isfile(destinationPath + "/" + source):
                        os.remove(destinationPath + "/" + source)
                        print(source, "deleted in", destination)

                    dest = shutil.copyfile(sourcePath, destinationPath)

                    flash("Arquivo Cadastrado")
        except:
            pass

    if request.method == "POST":
        try:
            botaoLR = request.form["botaoL"]

            if botaoLR == "HVoltar":
                return redirect(url_for("home"))
            elif botaoLR == "HVerProv":
                return redirect(url_for("viewaccounts"))
            elif botaoLR == "HVerProviso":
                return redirect(url_for("viewprovisions"))
            elif botaoLR == "HEditarProv":
                return redirect(url_for("editprovisions"))
            elif botaoLR == "HCriarProv":
                return redirect(url_for("createprovissions"))
            elif botaoLR == "HPermissoes":
                return redirect(url_for("seeprovisions"))
            elif botaoLR == "HDesconectar":
                return redirect(url_for("logout"))

            try:
                if botaoLR == "HPainel":
                    return redirect(url_for("basetablesupdate"))
            except:
                pass

            else:
                pass
        except:
            pass

    my_file = Path(
        f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx"
    )
    if my_file.is_file():
        ide = str(current_user.id)
        con = sqlite3.connect(
            f"app/Data_Bases_Usuarios/Provisoes_Editaveis_Usuario_{ide}.db"
        )
        wb = pd.ExcelFile(
            f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx"
        )
        for sheet in wb.sheet_names:
            df = pd.read_excel(
                f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx",
                sheet_name=sheet,
            )
            df.to_sql(
                f"Provisoes_Visualizar_Usuario_{ide}",
                con,
                index=False,
                if_exists="replace",
            )
        con.commit()
        con.close()
    else:
        pass

    from app.models import create_models2

    x = str(current_user.id)
    PlanilhaUsuario2 = create_models2(x, x)

    try:
        from app.models import create_models2

        x = str(current_user.id)
        PlanilhaUsuario2 = create_models2(x, x)
        from app.models import PlanilhaUsuario2

        yw = PlanilhaUsuario2.query.all()

        yww = PlanilhaUsuario2.query.filter_by(V3=str(current_user.email)).all()

        # print(PlanilhaUsuario.query.all())
        # ids = []
        # for instance in db.session.query(PlanilhaUsuario):
        #     x = instance.V1
        #     ids.append(x)
        # print(f'IDS = {ids}')
    except Exception as e:
        print(e)

    xx = str(current_user.id)
    # return render_template('editprovisions.html', PlanilhaUsuario=yw, usuario=xx)
    return render_template(
        "seeprovisions.html", PlanilhaUsuario3=yww, PlanilhaUsuario2=yw, usuario=xx
    )


@app.route("/aceitar/<int:valor>", methods=["GET", "POST"])
def aceitar(valor):

    from app.models import create_models2

    x = str(current_user.id)
    PlanilhaUsuario2 = create_models2(x, x)

    try:
        from app.models import PlanilhaUsuario2

        yw = PlanilhaUsuario2.query.all()
        # print(PlanilhaUsuario.query.all())
        # ids = []
        # for instance in db.session.query(PlanilhaUsuario):
        #     x = instance.V1
        #     ids.append(x)
        # print(f'IDS = {ids}')
    except:
        print("Erro")

    try:
        from app.models import PlanilhaUsuario2

        dados_usuarios = PlanilhaUsuario2.query.get(valor)
        # add dados_usuarios = PlanilhaUsuario(request.form['V2'], request.form['V3'], request.form['V4'], request.form['V5'], request.form['V6'], request.form['V7'], request.form['V8'], request.form['V9'], request.form['V10'])

        # print(PlanilhaUsuario.query.all())
        # ids = []
        # for instance in db.session.query(PlanilhaUsuario):
        #     x = instance.V1
        #     ids.append(x)
        # print(f'IDS = {ids}')
    except Exception as e:
        print(e)
        pass

    wb2 = load_workbook(
        f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx",
        data_only=True,
    )
    planilha2 = wb2["Modificacoes"]

    # print(dados_usuarios.V14)

    coluna_15 = planilha2["O"]

    for linha in coluna_15:
        if linha.value == int(f"{valor}"):
            linha1 = int(linha.row) - 1
            linha2 = int(linha.row)
            # print(linha.row)
            # print(linha.column_letter)
            dados_usuarios.V14 = "Aprovado"
            planilha2[f"N{linha1}"] = "Aprovado"
            planilha2[f"N{linha2}"] = "Aprovado"
        else:
            pass

    wb2.save(
        f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx"
    )

    flash(f"Provisão Aceita")

    return redirect(url_for("seeprovisions"))


@app.route("/negar/<int:valor>", methods=["GET", "POST"])
def negar(valor):

    from app.models import create_models2

    x = str(current_user.id)
    PlanilhaUsuario2 = create_models2(x, x)

    try:
        from app.models import PlanilhaUsuario2

        yw = PlanilhaUsuario2.query.all()
        # print(PlanilhaUsuario.query.all())
        # ids = []
        # for instance in db.session.query(PlanilhaUsuario):
        #     x = instance.V1
        #     ids.append(x)
        # print(f'IDS = {ids}')
    except:
        print("Erro")

    try:
        from app.models import PlanilhaUsuario2

        dados_usuarios = PlanilhaUsuario2.query.get(valor)
        # add dados_usuarios = PlanilhaUsuario(request.form['V2'], request.form['V3'], request.form['V4'], request.form['V5'], request.form['V6'], request.form['V7'], request.form['V8'], request.form['V9'], request.form['V10'])

        # print(PlanilhaUsuario.query.all())
        # ids = []
        # for instance in db.session.query(PlanilhaUsuario):
        #     x = instance.V1
        #     ids.append(x)
        # print(f'IDS = {ids}')
    except Exception as e:
        print(e)
        pass

    wb2 = load_workbook(
        f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx",
        data_only=True,
    )
    planilha2 = wb2["Modificacoes"]

    # print(dados_usuarios.V14)

    coluna_15 = planilha2["O"]

    for linha in coluna_15:
        if linha.value == int(f"{valor}"):
            linha1 = int(linha.row) - 1
            linha2 = int(linha.row)
            # print(linha.row)
            # print(linha.column_letter)
            dados_usuarios.V14 = "Aprovado"
            planilha2[f"N{linha1}"] = "Negado"
            planilha2[f"N{linha2}"] = "Negado"
        else:
            pass

    wb2.save(
        f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx"
    )

    flash(f"Provisão Negada")

    return redirect(url_for("seeprovisions"))


@app.route("/motivoadm/<int:valor>", methods=["GET", "POST"])
def motivoadm(valor):

    if request.method == "POST":
        try:
            botaoLR = request.form["botaoL"]

            if botaoLR == "HVoltar":
                return redirect(url_for("home"))
            elif botaoLR == "HVerProv":
                return redirect(url_for("viewaccounts"))
            elif botaoLR == "HVerProviso":
                return redirect(url_for("viewprovisions"))
            elif botaoLR == "HEditarProv":
                return redirect(url_for("editprovisions"))
            elif botaoLR == "HCriarProv":
                return redirect(url_for("createprovissions"))
            elif botaoLR == "HPermissoes":
                return redirect(url_for("seeprovisions"))
            elif botaoLR == "HDesconectar":
                return redirect(url_for("logout"))

            try:
                if botaoLR == "HPainel":
                    return redirect(url_for("basetablesupdate"))
            except:
                pass

            else:
                pass
        except:
            pass

    from app.models import create_models2

    x = str(current_user.id)
    PlanilhaUsuario2 = create_models2(x, x)

    try:
        from app.models import PlanilhaUsuario2

        yw = PlanilhaUsuario2.query.all()
        # print(PlanilhaUsuario.query.all())
        # ids = []
        # for instance in db.session.query(PlanilhaUsuario):
        #     x = instance.V1
        #     ids.append(x)
        # print(f'IDS = {ids}')
    except:
        print("Erro")

    try:
        from app.models import PlanilhaUsuario2

        dados_usuarios = PlanilhaUsuario2.query.get(valor)
        # add dados_usuarios = PlanilhaUsuario(request.form['V2'], request.form['V3'], request.form['V4'], request.form['V5'], request.form['V6'], request.form['V7'], request.form['V8'], request.form['V9'], request.form['V10'])

        # print(PlanilhaUsuario.query.all())
        # ids = []
        # for instance in db.session.query(PlanilhaUsuario):
        #     x = instance.V1
        #     ids.append(x)
        # print(f'IDS = {ids}')
    except Exception as e:
        print(e)
        pass

    if request.method == "POST":
        from app.models import create_models2

        x = str(current_user.id)
        PlanilhaUsuario2 = create_models2(x, x)

        try:
            from app.models import PlanilhaUsuario2

            yw = PlanilhaUsuario2.query.all()
            # print(PlanilhaUsuario.query.all())
            # ids = []
            # for instance in db.session.query(PlanilhaUsuario):
            #     x = instance.V1
            #     ids.append(x)
            # print(f'IDS = {ids}')
        except:
            print("Erro")

        try:
            from app.models import PlanilhaUsuario2

            dados_usuarios = PlanilhaUsuario2.query.get(valor)
            # add dados_usuarios = PlanilhaUsuario(request.form['V2'], request.form['V3'], request.form['V4'], request.form['V5'], request.form['V6'], request.form['V7'], request.form['V8'], request.form['V9'], request.form['V10'])

            # print(PlanilhaUsuario.query.all())
            # ids = []
            # for instance in db.session.query(PlanilhaUsuario):
            #     x = instance.V1
            #     ids.append(x)
            # print(f'IDS = {ids}')
        except Exception as e:
            print(e)
            pass

        wb2 = load_workbook(
            f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx",
            data_only=True,
        )
        planilha2 = wb2["Modificacoes"]

        # print(dados_usuarios.V14)

        coluna_15 = planilha2["O"]

        for linha in coluna_15:
            if linha.value == int(f"{valor}"):
                linha1 = int(linha.row) - 1
                linha2 = int(linha.row)
                # print(linha.row)
                # print(linha.column_letter)

                planilha2[f"E{linha2}"] = (
                    dados_usuarios.V5
                    if request.form["V5"] == ""
                    else request.form["V5"]
                )
                planilha2[f"F{linha2}"] = (
                    dados_usuarios.V6
                    if request.form["V6"] == ""
                    else request.form["V6"]
                )
                planilha2[f"G{linha2}"] = (
                    dados_usuarios.V7
                    if request.form["V7"] == ""
                    else request.form["V7"]
                )
                planilha2[f"H{linha2}"] = (
                    dados_usuarios.V8
                    if request.form["V8"] == ""
                    else request.form["V8"]
                )
                planilha2[f"I{linha2}"] = (
                    dados_usuarios.V9
                    if request.form["V9"] == ""
                    else request.form["V9"]
                )  ###
                planilha2[f"J{linha2}"] = (
                    dados_usuarios.V10
                    if request.form["V10"] == ""
                    else request.form["V10"]
                )
                planilha2[f"K{linha2}"] = (
                    dados_usuarios.V11
                    if request.form["V11"] == ""
                    else request.form["V11"]
                )
                planilha2[f"L{linha2}"] = (
                    str(dados_usuarios.V12)
                    if request.form["V12"] == ""
                    else str(request.form["V12"])
                )
                planilha2[f"M{linha2}"] = (
                    dados_usuarios.V13
                    if request.form["V12"] == ""
                    else str(
                        float(float(request.form["V12"]) + float(dados_usuarios.V11))
                    )
                )
                planilha2[f"P{linha2}"] = (
                    dados_usuarios.V14
                    if request.form["V14"] == ""
                    else str(request.form["V14"])
                )
            else:
                pass

        wb2.save(
            f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx"
        )

        flash(f"Provisão Editada")

        return redirect(url_for("seeprovisions"))

    try:
        from app.models import PlanilhaUsuario

        valor = PlanilhaUsuario.query.get(1)
        print(valor)
    except Exception as e:
        print(e)
        pass

    try:
        wb = load_workbook(
            r"app/static/Excels/Excel_Bases/Provisoes.xlsx", data_only=True
        )
        planilha = wb["Provisoes"]

        primeira_linha = planilha["1"]

        titulos = []
        for valor in primeira_linha:
            if valor.value == "" or valor.value == "Null" or valor.value is None:
                pass
            else:
                titulos.append(valor.value)
    except:
        pass

    return render_template("motivoadm.html", titulos=titulos, dado=dados_usuarios)


@app.route("/editadm/<int:valor>", methods=["GET", "POST"])
def editadm(valor):

    if request.method == "POST":
        try:
            botaoLR = request.form["botaoL"]

            if botaoLR == "HVoltar":
                return redirect(url_for("home"))
            elif botaoLR == "HVerProv":
                return redirect(url_for("viewaccounts"))
            elif botaoLR == "HVerProviso":
                return redirect(url_for("viewprovisions"))
            elif botaoLR == "HEditarProv":
                return redirect(url_for("editprovisions"))
            elif botaoLR == "HCriarProv":
                return redirect(url_for("createprovissions"))
            elif botaoLR == "HPermissoes":
                return redirect(url_for("seeprovisions"))
            elif botaoLR == "HDesconectar":
                return redirect(url_for("logout"))

            try:
                if botaoLR == "HPainel":
                    return redirect(url_for("basetablesupdate"))
            except:
                pass

            else:
                pass
        except:
            pass

    from app.models import create_models2

    x = str(current_user.id)
    PlanilhaUsuario2 = create_models2(x, x)

    try:
        from app.models import PlanilhaUsuario2

        yw = PlanilhaUsuario2.query.all()
        # print(PlanilhaUsuario.query.all())
        # ids = []
        # for instance in db.session.query(PlanilhaUsuario):
        #     x = instance.V1
        #     ids.append(x)
        # print(f'IDS = {ids}')
    except:
        print("Erro")

    try:
        from app.models import PlanilhaUsuario2

        dados_usuarios = PlanilhaUsuario2.query.get(valor)
        # add dados_usuarios = PlanilhaUsuario(request.form['V2'], request.form['V3'], request.form['V4'], request.form['V5'], request.form['V6'], request.form['V7'], request.form['V8'], request.form['V9'], request.form['V10'])

        # print(PlanilhaUsuario.query.all())
        # ids = []
        # for instance in db.session.query(PlanilhaUsuario):
        #     x = instance.V1
        #     ids.append(x)
        # print(f'IDS = {ids}')
    except Exception as e:
        print(e)
        pass

    if request.method == "POST":
        from app.models import create_models2

        x = str(current_user.id)
        PlanilhaUsuario2 = create_models2(x, x)

        try:
            from app.models import PlanilhaUsuario2

            yw = PlanilhaUsuario2.query.all()
            # print(PlanilhaUsuario.query.all())
            # ids = []
            # for instance in db.session.query(PlanilhaUsuario):
            #     x = instance.V1
            #     ids.append(x)
            # print(f'IDS = {ids}')
        except:
            print("Erro")

        try:
            from app.models import PlanilhaUsuario2

            dados_usuarios = PlanilhaUsuario2.query.get(valor)
            # add dados_usuarios = PlanilhaUsuario(request.form['V2'], request.form['V3'], request.form['V4'], request.form['V5'], request.form['V6'], request.form['V7'], request.form['V8'], request.form['V9'], request.form['V10'])

            # print(PlanilhaUsuario.query.all())
            # ids = []
            # for instance in db.session.query(PlanilhaUsuario):
            #     x = instance.V1
            #     ids.append(x)
            # print(f'IDS = {ids}')
        except Exception as e:
            print(e)
            pass

        wb2 = load_workbook(
            f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx",
            data_only=True,
        )
        planilha2 = wb2["Modificacoes"]

        # print(dados_usuarios.V14)

        coluna_15 = planilha2["O"]

        for linha in coluna_15:
            if linha.value == int(f"{valor}"):
                linha1 = int(linha.row) - 1
                linha2 = int(linha.row)
                # print(linha.row)
                # print(linha.column_letter)

                try:
                    V99 = (
                        dados_usuarios.V9
                        if request.form["V9"] == ""
                        else request.form["V9"]
                    )
                except:
                    V99 = dados_usuarios.V9

                planilha2[f"E{linha2}"] = (
                    dados_usuarios.V5
                    if request.form["V5"] == ""
                    else request.form["V5"]
                )
                planilha2[f"F{linha2}"] = (
                    dados_usuarios.V6
                    if request.form["V6"] == ""
                    else request.form["V6"]
                )
                planilha2[f"G{linha2}"] = (
                    dados_usuarios.V7
                    if request.form["V7"] == ""
                    else request.form["V7"]
                )
                planilha2[f"H{linha2}"] = (
                    dados_usuarios.V8
                    if request.form["V8"] == ""
                    else request.form["V8"]
                )
                planilha2[f"I{linha2}"] = V99
                planilha2[f"J{linha2}"] = (
                    dados_usuarios.V10
                    if request.form["V10"] == ""
                    else request.form["V10"]
                )
                planilha2[f"K{linha2}"] = (
                    dados_usuarios.V11
                    if request.form["V11"] == ""
                    else request.form["V11"]
                )
                planilha2[f"L{linha2}"] = (
                    str(dados_usuarios.V12)
                    if request.form["V12"] == ""
                    else str(request.form["V12"])
                )
                planilha2[f"M{linha2}"] = (
                    str(dados_usuarios.V12)
                    if request.form["V12"] == ""
                    else str(request.form["V12"])
                )
                planilha2[f"P{linha2}"] = (
                    dados_usuarios.V16
                    if request.form["V14"] == ""
                    else str(request.form["V14"])
                )
            else:
                pass

        wb2.save(
            f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx"
        )

        flash(f"Provisão Editada")

        return redirect(url_for("seeprovisions"))

    try:
        from app.models import PlanilhaUsuario

        valor = PlanilhaUsuario.query.get(1)
        print(valor)
    except Exception as e:
        print(e)
        pass

    try:
        wb = load_workbook(
            r"app/static/Excels/Excel_Bases/Provisoes.xlsx", data_only=True
        )
        planilha = wb["Provisoes"]

        primeira_linha = planilha["1"]

        titulos = []
        for valor in primeira_linha:
            if valor.value == "" or valor.value == "Null" or valor.value is None:
                pass
            else:
                titulos.append(valor.value)
    except:
        pass

    return render_template("editadm.html", titulos=titulos, dado=dados_usuarios)


@app.route("/deletar/<int:valor>", methods=["GET", "POST"])
def deletar(valor):
    if request.method == "POST":
        try:
            botaoLR = request.form["botaoL"]

            if botaoLR == "HVoltar":
                return redirect(url_for("home"))
            elif botaoLR == "HVerProv":
                return redirect(url_for("viewaccounts"))
            elif botaoLR == "HVerProviso":
                return redirect(url_for("viewprovisions"))
            elif botaoLR == "HEditarProv":
                return redirect(url_for("editprovisions"))
            elif botaoLR == "HCriarProv":
                return redirect(url_for("createprovissions"))
            elif botaoLR == "HPermissoes":
                return redirect(url_for("seeprovisions"))
            elif botaoLR == "HDesconectar":
                return redirect(url_for("logout"))

            try:
                if botaoLR == "HPainel":
                    return redirect(url_for("basetablesupdate"))
            except:
                pass

            else:
                pass
        except:
            pass

    from app.models import create_models2

    x = str(current_user.id)
    PlanilhaUsuario2 = create_models2(x, x)

    try:
        from app.models import PlanilhaUsuario2

        yw = PlanilhaUsuario2.query.all()
        # print(PlanilhaUsuario.query.all())
        # ids = []
        # for instance in db.session.query(PlanilhaUsuario):
        #     x = instance.V1
        #     ids.append(x)
        # print(f'IDS = {ids}')
    except:
        print("Erro")

    try:
        from app.models import PlanilhaUsuario2

        dados_usuarios = PlanilhaUsuario2.query.get(valor)
        # add dados_usuarios = PlanilhaUsuario(request.form['V2'], request.form['V3'], request.form['V4'], request.form['V5'], request.form['V6'], request.form['V7'], request.form['V8'], request.form['V9'], request.form['V10'])

        # print(PlanilhaUsuario.query.all())
        # ids = []
        # for instance in db.session.query(PlanilhaUsuario):
        #     x = instance.V1
        #     ids.append(x)
        # print(f'IDS = {ids}')
    except Exception as e:
        print(e)
        pass

    from app.models import create_models2

    x = str(current_user.id)
    PlanilhaUsuario2 = create_models2(x, x)

    try:
        from app.models import PlanilhaUsuario2

        yw = PlanilhaUsuario2.query.all()
        # print(PlanilhaUsuario.query.all())
        # ids = []
        # for instance in db.session.query(PlanilhaUsuario):
        #     x = instance.V1
        #     ids.append(x)
        # print(f'IDS = {ids}')
    except:
        print("Erro")

    try:
        from app.models import PlanilhaUsuario2

        dados_usuarios = PlanilhaUsuario2.query.get(valor)
        # add dados_usuarios = PlanilhaUsuario(request.form['V2'], request.form['V3'], request.form['V4'], request.form['V5'], request.form['V6'], request.form['V7'], request.form['V8'], request.form['V9'], request.form['V10'])

        # print(PlanilhaUsuario.query.all())
        # ids = []
        # for instance in db.session.query(PlanilhaUsuario):
        #     x = instance.V1
        #     ids.append(x)
        # print(f'IDS = {ids}')
    except Exception as e:
        print(e)
        pass

    wb2 = load_workbook(
        f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx",
        data_only=True,
    )
    planilha2 = wb2["Modificacoes"]

    # print(dados_usuarios.V14)

    coluna_15 = planilha2["O"]

    for linha in coluna_15:
        if linha.value == int(f"{valor}"):
            linha1 = int(linha.row) - 1
            linha2 = int(linha.row)
            # print(linha.row)
            # print(linha.column_letter)

            planilha2[f"A{linha2}"] = "DELETED"
            planilha2[f"B{linha2}"] = "DELETED"
            planilha2[f"C{linha2}"] = "DELETED"
            planilha2[f"D{linha2}"] = "DELETED"
            planilha2[f"E{linha2}"] = "DELETED"
            planilha2[f"F{linha2}"] = "DELETED"
            planilha2[f"G{linha2}"] = "DELETED"
            planilha2[f"H{linha2}"] = "DELETED"
            planilha2[f"I{linha2}"] = "DELETED"
            planilha2[f"J{linha2}"] = "DELETED"
            planilha2[f"K{linha2}"] = "DELETED"
            planilha2[f"L{linha2}"] = "DELETED"
            planilha2[f"M{linha2}"] = "DELETED"
            planilha2[f"N{linha2}"] = "DELETED"
            planilha2[f"P{linha2}"] = "DELETED"

            planilha2[f"A{linha2 -1}"] = "DELETED"
            planilha2[f"B{linha2 -1}"] = "DELETED"
            planilha2[f"C{linha2 -1}"] = "DELETED"
            planilha2[f"D{linha2 -1}"] = "DELETED"
            planilha2[f"E{linha2 -1}"] = "DELETED"
            planilha2[f"F{linha2 -1}"] = "DELETED"
            planilha2[f"G{linha2 -1}"] = "DELETED"
            planilha2[f"H{linha2 -1}"] = "DELETED"
            planilha2[f"I{linha2 -1}"] = "DELETED"
            planilha2[f"J{linha2 -1}"] = "DELETED"
            planilha2[f"K{linha2 -1}"] = "DELETED"
            planilha2[f"L{linha2 -1}"] = "DELETED"
            planilha2[f"M{linha2 -1}"] = "DELETED"
            planilha2[f"N{linha2 -1}"] = "DELETED"
            planilha2[f"P{linha2 -1}"] = "DELETED"

        else:
            pass

    wb2.save(
        f"app/static/Excels/Excel_Modificacoes/Brose_Modificacoes_Solicitacoes.xlsx"
    )

    flash(f"Provisão Editada")

    return redirect(url_for("seeprovisions"))


@app.route("/t", methods=["GET", "POST"])
def t():

    con = sqlite3.connect(
        f"app/Data_Bases_Usuarios/Provisoes_Editaveis_Usuario_{str(current_user.id)}.db"
    )
    wb = pd.ExcelFile(
        f"app/static/Excels/Excel_Provisoes_Usuarios/Provisoes_User_id_{str(current_user.id)}.xlsx"
    )
    df = pd.read_excel(
        f"app/static/Excels/Excel_Provisoes_Usuarios/Provisoes_User_id_{str(current_user.id)}.xlsx",
        sheet_name="Provisoes",
    )
    df.to_sql(
        f"Provisoes_Editaveis_Usuario_{str(current_user.id)}",
        con,
        index=False,
        if_exists="replace",
    )
    con.commit()
    con.close()

    return "Hello"


if __name__ == "__main__":
    excel.init_excel(app)
    
    app.run()