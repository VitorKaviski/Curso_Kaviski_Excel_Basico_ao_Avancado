from flask import Flask,  session
from flask_login import LoginManager
from flask_sqlalchemy import SQLAlchemy
from flask_paranoid import Paranoid
import flask_excel as excel
from openpyxl import load_workbook
from os.path import join, dirname, realpath
from pathlib import Path

app = Flask(__name__)

db_name = 'registros.db'

dicionariodeusuarios = {}

wb = load_workbook(r'app/static/Excels/Excel_Registros/Brose_Registros_Usuarios.xlsx')
planilha = wb["Usuarios"]
primeira_coluna = planilha['A']

for valor in primeira_coluna[1:]:
    if valor.value == "" or valor.value == "Null" or valor.value is None:
        pass
    else:
        # print(valor.value)
        id = str(valor.row-1)
        dicionariodeusuarios[f"Provisoes_Editaveis_Usuario_{id}"] = f'sqlite:///Data_Bases_Usuarios/Provisoes_Editaveis_Usuario_{id}.db'
        my_file = Path(f"app/Data_Bases_Usuarios/Provisoes_Editaveis_Usuario_{id}.db")
        if my_file.is_file():
            pass
        else:
            with open(f'app/Data_Bases_Usuarios/Provisoes_Editaveis_Usuario_{id}.db', 'w') as f:
                f.close()

# print(dicionariodeusuarios)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + db_name
app.config['SQLALCHEMY_BINDS'] = dicionariodeusuarios
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False


app.config['SECRET_KEY'] = 'secret'
app.config['UPLOAD_FOLDER'] = join(dirname(realpath(__file__)), 'static/Excels/Excel_Bases')
app.config['UPLOAD_EXTENSIONS'] = ['.xlsx']

login_manager = LoginManager(app)
db = SQLAlchemy(app)
excel.init_excel(app)

SESSION_COOKIE_SECURE = True
REMEMBER_COOKIE_SECURE = True
SESSION_COOKIE_HTTPONLY = True
REMEMBER_COOKIE_HTTPONLY = True
paranoid = Paranoid(app)
paranoid.redirect_view = '/'

