
// Tira a mensagem de sucesso depois de 5 segundos

setTimeout(() => {
  document.querySelector('#alerta').style.display = 'none';
}, 5000)