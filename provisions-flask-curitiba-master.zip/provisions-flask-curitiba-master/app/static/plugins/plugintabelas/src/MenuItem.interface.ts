interface MenuItem {
    column: number;
    row: number;
    value: string;
    selected: boolean;
}
