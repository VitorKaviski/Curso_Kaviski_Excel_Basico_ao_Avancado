from app import db, login_manager
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin, current_user
from openpyxl import load_workbook

@login_manager.user_loader
def get_user(user_id):
    return User.query.filter_by(id=user_id).first()

class User(db.Model, UserMixin):
    __tablename__ = 'users'
    id = db.Column(db.Integer, autoincrement=True, primary_key=True)
    name = db.Column(db.String(86), nullable=False)
    email = db.Column(db.String(84), nullable=False, unique=True)
    password = db.Column(db.String(128), nullable=False)


    def __init__(self, name, email, password):
        self.name = name
        self.email = email
        self.password = generate_password_hash(password)

    def verify_password(self, pwd):
        return check_password_hash(self.password, pwd)

class Center(db.Model):
    __tablename__ = 'centers'
    id = db.Column(db.Integer, autoincrement=True, primary_key=True)
    center = db.Column(db.String(86), nullable=False, unique=True)

    def __init__(self, center):
        self.center = center

class Account(db.Model):
    __tablename__ = 'accounts'
    id = db.Column(db.Integer, autoincrement=True, primary_key=True)
    account = db.Column(db.String(86), nullable=False, unique=True)

    def __init__(self, account):
        self.account = account

def create_models(self, x):
    # print(f"User1 = {x}")
    class PlanilhaUsuario(db.Model):
        # print(f"User2 = {x}")
        @property
        def is_active(self):
            print(11)
            return True

        @property
        def is_authenticated(self):
            print(22)
            return True

        @login_manager.user_loader
        def get_user(user_id):
            return User.query.filter_by(id=user_id).first()

        __bind_key__ = f'Provisoes_Editaveis_Usuario_{x}'
        __tablename__ = f'Provisoes_Editaveis_Usuario_{x}'
        __table_args__ = {'extend_existing': True}

        wb = load_workbook(r'app/static/Excels/Excel_Bases/Provisoes.xlsx', data_only=True)
        planilha = wb["Provisoes"]

        V1 = db.Column(f"{planilha['A1'].value}",db.Integer, primary_key=True)
        V2 = db.Column(f"{planilha['B1'].value}",db.String(100))
        V3 = db.Column(f"{planilha['C1'].value}",db.String(100))
        V4 = db.Column(f"{planilha['D1'].value}",db.String(100))
        V5 = db.Column(f"{planilha['E1'].value}",db.String(100))
        V6 = db.Column(f"{planilha['F1'].value}",db.String(100))
        V7 = db.Column(f"{planilha['G1'].value}",db.String(100))
        V8 = db.Column(f"{planilha['H1'].value}",db.String(100))
        V9 = db.Column(f"{planilha['I1'].value}",db.String(100))
        V10 = db.Column(f"{planilha['J1'].value}",db.String(100))
        V11 = db.Column(f"{planilha['K1'].value}", db.String(100))

        def __int__(self, V1, V2, V3, V4, V5, V6, V7, V8, V9, V10, V11):
            print('fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff')
            self.V1 = V1
            self.V2 = V2
            self.V3 = V3
            self.V4 = V4
            self.V5 = V5
            self.V6 = V6
            self.V7 = V7
            self.V8 = V8
            self.V9 = V9
            self.V10 = V10
            self.V11 = V11

    globals().update(locals())

def create_models1(self, x):
    # print(f"User1 = {x}")
    class PlanilhaUsuario1(db.Model):
        # print(f"User2 = {x}")
        @property
        def is_active(self):
            print(11)
            return True

        @property
        def is_authenticated(self):
            print(22)
            return True

        @login_manager.user_loader
        def get_user(user_id):
            return User.query.filter_by(id=user_id).first()

        __bind_key__ = f'Provisoes_Editaveis_Usuario_{x}'
        __tablename__ = f'Contas_FBL3N_Usuario_{x}'
        __table_args__ = {'extend_existing': True}

        wb = load_workbook(r'app/static/Excels/Excel_Bases/Resumo_Contas.xlsx', data_only=True)
        planilha = wb["Geral"]

        V1 = db.Column(f"{planilha['A1'].value}",db.Integer, primary_key=True)
        V2 = db.Column(f"{planilha['B1'].value}",db.String(100))
        V3 = db.Column(f"{planilha['C1'].value}",db.String(100))
        V4 = db.Column(f"{planilha['D1'].value}",db.String(100))
        V5 = db.Column(f"{planilha['E1'].value}",db.String(100))
        V6 = db.Column(f"{planilha['F1'].value}",db.String(100))

        def __int__(self, V1, V2, V3, V4, V5, V6):

            self.V1 = V1
            self.V2 = V2
            self.V3 = V3
            self.V4 = V4
            self.V5 = V5
            self.V6 = V6

    globals().update(locals())

def create_models2(self, x):
    # print(f"User1 = {x}")
    class PlanilhaUsuario2(db.Model):
        # print(f"User2 = {x}")
        @property
        def is_active(self):
            print(11)
            return True

        @property
        def is_authenticated(self):
            print(22)
            return True

        @login_manager.user_loader
        def get_user(user_id):
            return User.query.filter_by(id=user_id).first()

        __bind_key__ = f'Provisoes_Editaveis_Usuario_{x}'
        __tablename__ = f'Provisoes_Visualizar_Usuario_{x}'
        __table_args__ = {'extend_existing': True}

        V1 = db.Column('Modificações', db.String(100))
        V2 = db.Column('Especificação dos Dados', db.String(100))
        V3 = db.Column('Unnamed: 2', db.String(100))
        V4 = db.Column('Títulos das Colunas', db.String(100))
        V5 = db.Column('Unnamed: 4', db.String(100))
        V6 = db.Column('Unnamed: 5', db.String(100))
        V7 = db.Column('Unnamed: 6', db.String(100))
        V8 = db.Column('Unnamed: 7', db.String(100))
        V9 = db.Column('Unnamed: 8', db.String(100))
        V10 = db.Column('Unnamed: 9', db.String(100))
        V11 = db.Column('Unnamed: 10', db.String(100))
        V12 = db.Column('Unnamed: 11', db.String(100))
        V13 = db.Column('Unnamed: 12', db.String(100))
        V14 = db.Column('Situação', db.String(100))
        V15 = db.Column('ID', db.Integer, autoincrement=True, primary_key=True)
        V16 = db.Column('Motivo', db.String(100))

        def __int__(self, V1, V2, V3, V4, V5, V6, V7, V8, V9, V10, V11, V12, V13, V14, V15, V16):
            print('fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff')
            self.V1 = V1
            self.V2 = V2
            self.V3 = V3
            self.V4 = V4
            self.V5 = V5
            self.V6 = V6
            self.V7 = V7
            self.V8 = V8
            self.V9 = V9
            self.V10 = V10
            self.V10 = V11
            self.V10 = V12
            self.V10 = V13
            self.V10 = V14
            self.V10 = V15
            self.V10 = V16

    globals().update(locals())