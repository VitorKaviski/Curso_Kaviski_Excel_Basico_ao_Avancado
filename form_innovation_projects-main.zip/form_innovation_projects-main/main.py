from flask import Flask,render_template, request, flash
import pptx
from datetime import datetime
from pptx.util import Pt
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os

app = Flask(__name__)
app.secret_key = 'hpcqucpcrqtbfcfe'

@app.route("/", methods=["GET", "POST"])
def home():

    if request.method == "POST":
        try:
            botao = request.form["botao"]

            if botao == "Enviar":

                try:
                    folder_path = app.root_path + f'/Apresentation/Apresentations/'

                    # Itera sobre todos os arquivos na pasta
                    for filename in os.listdir(folder_path):
                        # Verifica se o arquivo tem a extensão .pptx
                        if filename.endswith(".pptx"):
                            # Cria o caminho completo para o arquivo
                            filepath = os.path.join(folder_path, filename)
                            # Remove o arquivo
                            os.remove(filepath)
                            print(f"O arquivo '{filename}' foi removido com sucesso!")
                except:
                    pass

                title = request.form["Project's Title"]
                leader = request.form["Project's Leader"]
                duration = request.form["Expected Duration"]
                classification = request.form["Classification"]
                budget = request.form["Budget"]
                hours = request.form["Project Hours"]
                motivation = request.form["Project's Motivation"]
                solution = request.form["State of art solution"]
                member_1 = request.form["Project Member 1"]
                try:
                    member_2 = request.form["Project Member 2"]
                except:
                    pass
                try:
                    member_3 = request.form["Project Member 3"]
                except:
                    pass
                try:
                    member_4 = request.form["Project Member 4"]
                except:
                    pass
                try:
                    member_5 = request.form["Project Member 5"]
                except:
                    pass
                Quantitative_1 = request.form["Quantitative Current"]
                Quantitative_2 = request.form["Quantitative Future"]
                Qualitative_1 = request.form["Qualitative Current"]
                Qualitative_2 = request.form["Qualitative Future"]


                # Create a presentation

                # Abra o arquivo de slide PPTX
                prs = pptx.Presentation(app.root_path + '/Apresentation/Apresentation_Model/Modelo.pptx')

                # Obtenha o primeiro slide
                slide = prs.slides[1]

                # Obtenha todas as formas do slide
                formas = slide.shapes

                # Percorra todas as formas do slide
                for forma in formas:
                    # Verifique se a forma é uma caixa de texto
                    if forma.has_text_frame:
                        print(forma.text_frame.text)

                        if "PAIN" in classification.upper():
                            if forma.text_frame.text == "X":
                                forma.text_frame.text = "X"
                            if forma.text_frame.text == "U":
                                forma.text_frame.text = ""
                        else:
                            if forma.text_frame.text == "X":
                                forma.text_frame.text = ""
                            if forma.text_frame.text == "U":
                                forma.text_frame.text = "X"

                        if forma.text_frame.text == "Title":
                            forma.text_frame.text = title
                        elif forma.text_frame.text == "Motivation":
                            forma.text_frame.text = motivation
                        elif forma.text_frame.text == "T1":
                            forma.text_frame.text = member_1
                        elif forma.text_frame.text == "Leader":
                            forma.text_frame.text = leader
                        elif forma.text_frame.text == "Duration":
                            forma.text_frame.text = duration
                        elif forma.text_frame.text == "Budget":
                            forma.text_frame.text = budget
                        elif forma.text_frame.text == "Hours":
                            forma.text_frame.text = hours
                        elif forma.text_frame.text == "Solution":
                            forma.text_frame.text = solution
                        elif forma.text_frame.text == "QQC":
                            forma.text_frame.text = Quantitative_1
                        elif forma.text_frame.text == "QQF":
                            forma.text_frame.text = Quantitative_2
                        elif forma.text_frame.text == "QAC":
                            forma.text_frame.text = Qualitative_1
                        elif forma.text_frame.text == "QAF":
                            forma.text_frame.text = Qualitative_2

                        try:
                            if forma.text_frame.text == "T2":
                                forma.text_frame.text = member_2
                        except:
                            pass
                        try:
                            if forma.text_frame.text == "T3":
                                forma.text_frame.text = member_3
                        except:
                            pass
                        try:
                            if forma.text_frame.text == "T4":
                                forma.text_frame.text = member_4
                        except:
                            pass
                        try:
                            if forma.text_frame.text == "T5":
                                forma.text_frame.text = member_5
                        except:
                            pass

                for shape in slide.shapes:
                    if shape.has_text_frame:
                        text_frame = shape.text_frame
                        if text_frame.text == "X":
                            for paragraph in text_frame.paragraphs:
                                for run in paragraph.runs:
                                    run.font.size = Pt(20)
                                    run.font.bold = True
                        elif text_frame.text == "U":
                            for paragraph in text_frame.paragraphs:
                                for run in paragraph.runs:
                                    run.font.size = Pt(20)
                                    run.font.bold = True
                        elif "Innovation ProjectsProject Charter – Step 1" not in text_frame.text or "X" not in text_frame.text or "U" not in text_frame.text:
                            for paragraph in text_frame.paragraphs:
                                for run in paragraph.runs:
                                    run.font.bold = False
                                    run.font.size = Pt(12)

                data = datetime.now().strftime('%d-%m-%Y_%H-%M-%S')
                print('111')
                prs.save(app.root_path + f'/Apresentation/Apresentations/Innovation Projects - Project Charter - {data}.pptx')
                print('222')
                fromaddr = "cadastronovainovationidea"
                toaddr = 'inovabrasil@brose.com'
                msg = MIMEMultipart()

                msg["From"] = fromaddr
                msg["To"] = toaddr
                msg['Subject'] = f"Cadastro de um novo Innovation Projects Realizado"
                body = f"Segue em anexo, arquivo pptx com os dados do Innovation Project cadastrado por {leader} na data de ({data}), com o título: '{title}'."
                msg.attach(MIMEText(body, 'plain'))
                filename = f'Innovation Projects - Project Charter - {data}.pptx'
                attachment = open(app.root_path + f'/Apresentation/Apresentations/Innovation Projects - Project Charter - {data}.pptx', "rb")
                p = MIMEBase('application', 'octet-stream')
                p.set_payload((attachment).read())
                encoders.encode_base64(p)
                p.add_header('Content-Disposition', "attachment; filename= %s" % filename)
                msg.attach(p)
                text = msg.as_string()
                print('333')

                # smtp1 = smtplib.SMTP("127.0.0.1")
                # smtp1.sendmail(fromaddr, toaddr, text)
                # smtp1.quit()

                with smtplib.SMTP("127.0.0.1") as smtp1:
                    smtp1.sendmail(fromaddr, toaddr, text)

                print('333')
                flash("Cadastro Realizado")


            else:
                pass
        except Exception as e:
            flash("Tente Novamente ;)")
            print(e)
            pass

    return render_template("index.html")

if __name__ == "__main__":
    app.run()
